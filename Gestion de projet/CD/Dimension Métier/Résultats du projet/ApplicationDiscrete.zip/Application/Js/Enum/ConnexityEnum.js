// LICENCE /////////////////////////////////////////////////////////////////////


// TODO


// CODE ////////////////////////////////////////////////////////////////////////



/**
 * @enum
 * TODO
 */
var ConnexityEnum = {
	/// values
	NULL : 0,
	C26  : 1,
	C18  : 2,
	C6   : 4,
	ALL  : 7
};



if (Object.freeze)
	ConnexityEnum = Object.freeze (ConnexityEnum);
