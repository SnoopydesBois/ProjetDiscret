/**
 * CurveViewer.js
 * 
 * author : biscui
 * created : Wed, 23 Dec 2015 10:22:16 +0100
 * modified : Wed, 23 Dec 2015 10:22:16 +0100
 */



	  ///////////////////
	 /// constructor ///
	///////////////////



CurveViewer.prototype = new GenericStructure ();
CurveViewer.prototype.constructor = CurveViewer;

function CurveViewer () {
	
};


