/// LICENCE ////////////////////////////////////////////////////////////////////

// TODO

/// CODE ///////////////////////////////////////////////////////////////////////


/**
 * TODO
 */
var ConnexityEnum = {
	C26 : 0,
	C18 : 1,
	C6  : 2
};


/**
 * Allows the Enumeration to be constant.
 */
if (Object.freeze) {
	Object.freeze (ConnexityEnum);
}


