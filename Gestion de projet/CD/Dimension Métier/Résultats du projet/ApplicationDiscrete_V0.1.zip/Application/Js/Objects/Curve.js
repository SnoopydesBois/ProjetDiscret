Curve.prototype.constructor = Curve;

function Curve(){}

Curve.prototype.computePoints = function(){
	throw "Curve.computePoints.ErrorNotImplementedInAbstractClass";
};