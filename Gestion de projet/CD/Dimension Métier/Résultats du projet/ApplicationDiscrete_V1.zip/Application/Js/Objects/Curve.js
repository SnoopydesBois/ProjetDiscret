// TODO



Curve.prototype.constructor = Curve;

function Curve () {}


//==============================================================================
Curve.prototype.computePoints = function (ranX, ranY){
	throw "Curve.computePoints.ErrorNotImplementedInAbstractClass";
};
