/**
 * globalParameter.js
 * 
 * author : biscui
 * created : Mon, 18 Jan 2016 20:47:23 +0100
 * modified : Mon, 18 Jan 2016 20:47:23 +0100
 */


var globalParam = {
	
	/**
	 * TODO
	 */
	cubeColorDebug : false,
	
	/**
	 * TODO
	 */
	perspectiveView : true
};
