/**
 * DrawnCurve.js
 * 
 * author : abisutti
 * created : Wed, 20 Jan 2016 09:23:38 +0100
 * modified : Wed, 20 Jan 2016 09:23:38 +0100
 */


/**
 * @classdesc 
 */



DrawnCurve.prototype.constructor = DrawnCurve;



//##############################################################################
//	Constructor
//##############################################################################



/**
 * @constructor
 * 
 */
function DrawnCurve () {
	
};



//##############################################################################
//	Accessors and Mutators
//##############################################################################







//##############################################################################
//	Other methods
//##############################################################################


//==============================================================================
DrawnCurve.prototype.setParameter = function(parameter, value){
	throw "DrawnCurve.setParameter.ErrorCannotModifyParameterOnDrawnCurve";
}

