Batman.prototype = new ImplicitCurve;
Batman.prototype.constructor = Batman;

//==============================================================================
/**
* @constructor {Equation} the equation of the curve
*/
function Batman() {
	
};