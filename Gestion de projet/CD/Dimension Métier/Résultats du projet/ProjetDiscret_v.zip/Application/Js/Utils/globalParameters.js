/**
 * TODO
 */


var globalParam = {
	
	/**
	 * TODO
	 */
	cubeColorDebug : false,
	
	/**
	 * TODO
	 */
	perspectiveView : true
};
