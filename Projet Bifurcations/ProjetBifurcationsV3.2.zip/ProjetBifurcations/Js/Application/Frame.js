/*
 * Frame.js
 * 
 * author : abisutti
 * created : Tue, 26 May 2015 16:55:30 +0200
 * modified : Tue, 26 May 2015 16:55:30 +0200
 */



/**
 * @classdesc Abstract class.
 */



	  ///////////////////
	 /// Constructor ///
	///////////////////



Frame.prototype.constructor = Frame;


/**
 * @constructor
 */
function Frame (application) {
	/**
	 * Current width.
	 */
	this.width = 0;
	
	/**
	 * Current height.
	 */
	this.height = 0;
	this.appli = application;
	//console.log ("Frame constructor : "+ this.appli);
	/**
	 * 
	 */
	this.htmlSrc = "";
	
	/**
	 * id of the iFrame tag in which the frame is
	 */
	this.idIFrame = "";
	
	
	/**
	* Path to access the frame.
	* @example
	* If the frame is inside another frame it will be 
	* document.getElementById (this.idIFrame).contentWindow.document;
	*/
	this.frameDocument = null;
}



	  //////////////////////////////
	 /// Accessors and Mutators ///
	//////////////////////////////



/**
 * @return {int} the width of the frame
 */
Frame.prototype.getWidth = function () {
	return this.width;
};


//==============================================================================
/**
 * Set the width of the frame.
 * @param {int/string} the width. If the parameter is lower than 0, 0 is set.
 * @return {void}
 */
Frame.prototype.setWidth = function (width) {
	var w = width;
	if (parseInt (width) < 0)
		w = 0;
	this.width = w;
};


//==============================================================================
/**
 * @return {int} the height of the frame
 */
Frame.prototype.getHeight = function () {
	return this.height;
};


//==============================================================================
/**
 * Set the height of the frame.
 * @param {int/string} the height. If the parameter is lower than 0, 0 is set.
 * @return {void}
 */
Frame.prototype.setHeight = function (height) {
	var h = height;
	if (parseInt (height) < 0)
		h = 0;
	this.height = h;
};


//==============================================================================
/**
 * @return {String} the id in the iFrame tag of this frame
 */
Frame.prototype.getIdIFrame = function () {
	return this.idIFrame;
};


//==============================================================================
/**
 * @return {HTMLElement} the contentWindow.document of the Frame
 */
Frame.prototype.getFrameDocument = function () {	
	return this.frameDocument;
}



	  /////////////////////
	 /// Other methods ///
	/////////////////////



/**
 * Set the size of the frame
 * @param {int} width - The new width to set
 * @param {int} height - The new height to set
 * @return {void}
 */
Frame.prototype.setSize = function (width, height) {
	this.setWidth (width);
	this.setHeight (height);
};


//==============================================================================
/**
 * @return {String} Path of the file which contain the html code for this frame.
 */
Frame.prototype.getHtmlSrc = function () {
	return this.htmlSrc;
};


//==============================================================================
/**
 * Prepare the frame when it is put in an iFrame tag. This method is called 
 * every time the frame is load/reload.
 * 
 * MUST BE OVERLOAD IN DAUGHTER CLASSES
 * @param {String} idIFrame - the id in the iFrame tag of this frame
 * @param {HTMLElement} doc - Path to access the frame.
 */
Frame.prototype.prepare = function (idIFrame, doc) {};


//==============================================================================
/**
 * Update the frame display and it's content
 * MUST BE OVERLOAD IN DAUGHTER CLASSES
 */
Frame.prototype.update = function () {};



	  /////////////
	 /// Event ///
	/////////////



Frame.prototype.onMouseClick = function (event) {};
Frame.prototype.onMouseDblClick = function (event) {};
Frame.prototype.onMousePressed = function (event) {};
Frame.prototype.onMouseReleased = function (event) {};
Frame.prototype.onMouseMove = function (event) {};
Frame.prototype.onResize = function (event) {};
Frame.prototype.onBlur = function (event) {};
Frame.prototype.onFocus = function (event) {};
Frame.prototype.onKeyUp = function (event) {};
Frame.prototype.onKeyDown = function (event) {};
Frame.prototype.onKeyPressed = function (event) {};




