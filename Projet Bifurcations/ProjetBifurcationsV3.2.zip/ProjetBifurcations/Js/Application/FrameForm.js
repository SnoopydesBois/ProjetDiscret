/// LICENCE ////////////////////////////////////////////////////////////////////

/* Copyright (juin 2015)
 * Auteur : BENOIST Thomas, BISUTTI Adrien, DESPLEBAIN Tanguy, LAURET Karl
 * 
 * benoist.thomas@hotmail.fr
 * biscui_86@hotmail.fr
 * tanguy.desplebain@gmail.com
 * lauret.karl@hotmail.fr
 * 
 * Ce logiciel est un programme informatique servant à modéliser des
 * structures 3D voxellisées. 
 * 
 * Ce logiciel est régi par la licence CeCILL soumise au droit français et
 * respectant les principes de diffusion des logiciels libres. Vous pouvez
 * utiliser, modifier et/ou redistribuer ce programme sous les conditions
 * de la licence CeCILL telle que diffusée par le CEA, le CNRS et l'INRIA 
 * sur le site "http://www.cecill.info".
 * 
 * En contrepartie de l'accessibilité au code source et des droits de copie,
 * de modification et de redistribution accordés par cette licence, il n'est
 * offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
 * seule une responsabilité restreinte pèse sur l'auteur du programme,  le
 * titulaire des droits patrimoniaux et les concédants successifs.
 * 
 * A cet égard  l'attention de l'utilisateur est attirée sur les risques
 * associés au chargement,  à l'utilisation,  à la modification et/ou au
 * développement et à la reproduction du logiciel par l'utilisateur étant 
 * donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
 * manipuler et qui le réserve donc à des développeurs et des professionnels
 * avertis possédant  des  connaissances  informatiques approfondies.  Les
 * utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
 * logiciel à leurs besoins dans des conditions permettant d'assurer la
 * sécurité de leurs systèmes et ou de leurs données et, plus généralement, 
 * à l'utiliser et l'exploiter dans les mêmes conditions de sécurité. 
 * 
 * Le fait que vous puissiez accéder à cet en-tête signifie que vous avez 
 * pris connaissance de la licence CeCILL, et que vous en avez accepté les
 * termes.
 */

/// INDEX //////////////////////////////////////////////////////////////////////

/* constructor (frame3D : Frame3D, application : Application)
 * prepare (idIFrame : int) : void
 * setAppli (appli : Application) : void
 * setSelectedModel (model : ModelController[]) : void
 * saveModel () : void
 * saveStructure (model : ModelController,
 *                id : String,
 *                data : HTMLElement) : String
 * saveData (model : ModelController, id : String, data : HTMLElement) : String
 * loadModel (url : String) : void
 * exportAsSvg (id, cubeSize) : void
 * getAllSVG (axis : XXX, width : XXX) : String
 * getSVG (axis : AxisEnum, grid : int, width : int) : String
 */

/// CODE ///////////////////////////////////////////////////////////////////////



	  ///////////////////
	 /// Constructor ///
	///////////////////


FrameForm.prototype = new Frame ();
FrameForm.prototype.constructor = FrameForm;


/**
 * @constructor
 * @param {Frame3D} frame3D - The frame to use to display for the preview
 * @param {Application} application - The application to send signal to
 */
function FrameForm (frame3D, application) {
//	console.log ("FrameForm.constructor");
	Frame.call (this, application);
	
	this.htmlSrc = "Frame/iFrameForm.html";
	
	/**
	 * {Frame3D} The frame to use to display for the preview
	 */
	this.frame3D = frame3D;
	
	/**
	 * {ModelController[]} A reference on the list of selected models
	 */
	this.selectedModel = [];
};


	  /////////////////////
	 /// Other methods ///
	/////////////////////


/**
 * Prepare for drawing
 * @param {int} idIFrame - The workspace where to put the frame.
 * @return {void}
 */
FrameForm.prototype.prepare = function (idIFrame) {
//	console.log ("FrameForm.prepare");
	if (!idIFrame)
		throw "FrameForm.prepare : invalid iframe id (" + idIFrame + ")";
	// handle id container
	this.idIFrame = idIFrame;
	
	this.frameDocument = document.getElementById (
			this.idIFrame).contentWindow.document;
	document.getElementById("i_file").addEventListener(
			"onchange", this.loadModel.bind(this),false);
			
	if (this.selectedModel.length != 0) {
		this.frameDocument.getElementById(
			"id").setAttribute("value", this.selectedModel[0].getId());
		this.frameDocument.getElementById(
			"Description").innerHTML = this.selectedModel[0].getDescription();		
		this.frameDocument.getElementById(
			"Creator").setAttribute("value", this.selectedModel[0].getCreator());
			
	}	
		
	// Prepare of the 3D frame for the preview	
	this.frame3D.prepare(this.idIFrame, this.frameDocument.getElementById(
			"workSpace").contentWindow.document);
	this.frame3D.onResize();
};


	  //////////////////////////////
	 /// Accessors and Mutators ///
	//////////////////////////////


/**
 * Set the application to allow communication.
 * @param {Application} appli - The application to which the FrameForm
 * communicates.
 * @return {void}
 */
FrameForm.prototype.setAppli = function (appli) {
//	console.log ("FrameForm.setAppli");
	this.appli = appli;
};


//==============================================================================
/**
 * Set the selected Model list.
 * @param {ModelController[]} model - the selected models.
 * @return {void}
 */
FrameForm.prototype.setSelectedModel = function (model) {
//	console.log ("FrameForm.setSelectedModel");
	this.selectedModel = model;
};


	  /////////////////////
	 /// Other methods ///
	/////////////////////


/**
 * Save a model.
 * The files are placed into a directory.
 * 3 files are generated :
 *    - 1 containing the model data used to load the model;
 *    - 1 contain a preview // Currently not implemented;
 *    - 1 contain data information (such as the creator, ...).
 * The files saved are retrieve by the user by downloading the zip in which
 * they are placed.
 * @return {void}
 */
FrameForm.prototype.saveModel = function () {
//	console.log ("FrameForm.saveModel");
	
	var data = this.frameDocument.getElementsByClassName("fetchData");
	
	var id = data[0].value;
	var model = this.selectedModel[0];
	
	if (model == undefined || model == null) {
		alert("Le modèle nexiste plus.");
		return;
	}
	
	if (this.selectedModel.length>1) {
		alert("Vous ne pouvez enregistrer qu'un seul modèle à la fois.");
		return;
	}
	
	var modelName;
	if (id.length != 0) {
		modelName = model.getNbCube() + "." + id + "." + model.getName();
	}
	else {
		modelName = model.getNbCube() + "." + model.getName();
	}
	
	// Zip creation
	var zip = new JSZip();
	
	// Folder containing 3 files
	var modelFolder = zip.folder(modelName);
	
	// Model data
	modelFolder.file(modelName + "Matrix.js", 
			this.saveStructure(model, id, data));
	
	
	// Preview creation
	var pixels = [];
	pixels = this.frame3D.getImgData();
	
	var canvas = this.frameDocument.createElement('canvas');
	canvas.width = this.frame3D.getCanvasWidth();
	canvas.height = this.frame3D.getCanvasHeight();
	var context = canvas.getContext("2d");
	
	var imageData = context.createImageData(canvas.width, canvas.height);
	imageData.data.set(pixels);
	context.putImageData(imageData, 0, 0);
	
	var img = new Image();
	img.src = canvas.toDataURL();
	
	modelFolder.file(modelName + "Preview.png", 
			img.src.substr(img.src.indexOf(",") + 1), {base64: true});
	
	
	// Model information
	modelFolder.file(model.getName() + "Data.txt", 
			this.saveData(model, id, data));
	var content = zip.generate({type:"blob"});
	
	// see FileSaver.js
	
	window.saveAs(content, modelName +".zip");
};


//==============================================================================
/**
 * Save the data of the model into a string
 * @param {ModelController} model - The model to save the data from
 * @param {String} id - The id of the model
 * @param {HTMLElement} data - The form where the information are written
 * @return {String} The whole file in string
 */
FrameForm.prototype.saveStructure = function (model, id, data) {
//	console.log ("FrameForm.saveStructure");
	var texte = "";
	var nomModel = '_' + id + '_' + model.getName();
	
	texte += "var _modelId = '" + id + "';\n"; 
	texte += "var _modelName = '" + nomModel + "';\n"; 
	for (var i = 1; i < data.length; i++) { // 1 to skip the id field
		var txttemp = data[i].value;
		var txt = "";
		var indicetxt = 0;
		for (var j = 0; j < txttemp.length; j++) {
			if (txttemp[j] != "'") {
				txt += txttemp[j];
			}
			else {
				txt += "\\'";
			}
		}		
		texte += "var _model" + data[i].id + " = '" + txt + "';\n";
	}
	
	if (model.getCreationDate() == null) {
		var currentDate = new Date();
		texte += "var _modelCreationDate = '" + currentDate.toString() + "';\n";
	}
	else {
		texte += "var _modelCreationDate = '" +model.getCreationDate() + "';\n";
	}
	
	var size = model.getSize();
	
	// Fill the tab data
	texte += "var _modelTab = [\n";
	for (var z = 0; z < size.m[0]; ++z) {
		texte += "\t// Couche z = " + z + "\n";
		for (var y = 0; y < size.m[1]; ++y) {
			texte += '\t' + (y == 0 ? "[[" : " [");
			for (var x = 0; x < size.m[2]; ++x) {
				texte += (model.getCube(x, y, z) != null ? '1' : '0');
				texte += (x == size.m[2] - 1 ? "]" : ", ");
			}
			if (y == size.m[1] - 1) {
				texte += "\n\t]";
			}
			texte += ",\n";
		} // end for y
	} // end for z
	texte += "];\n"
	
	return texte;
};


//==============================================================================
/**
 * Save the data of the model into a string
 * @param {ModelController} model - The model to save the data from
 * @param {String} id - The id of the model
 * @param {HTMLElement} data - The form where the information are written
 * @return {String} The whole file in string
 */
FrameForm.prototype.saveData = function (model, id, data) {
//	console.log ("FrameForm.saveData");
	var texte = "Données du modèle\n";
	var nomModel = id + '.' + model.getName();
	
	texte += "Nom du modèle : " + nomModel + "\n"; 
	texte += "Nombre de cubes du modèle : " + model.getNbCube() + "\n";
	for (var i = 1; i < data.length; i++) { // 1 to skip the id field
		var txttemp = data[i].value;
		var txt = "";
		var indicetxt = 0;
		for (var j = 0; j < txttemp.length; j++) {
			if (txttemp[j] != "'") {
				txt += txttemp[j];
			}
			else {
				txt += "\\'";
			}
		}
		texte += data[i].name + " : " + txt + "\n";
	}
	
	texte += "Date de création : " + model.getCreationDate() + "\n";
	var currentDate = new Date();
	texte += "Date de dernière modification : " + currentDate.toString() + "\n";
	var size = model.getSize();
	
	return texte;
};


//==============================================================================
/**
 * Load a model from a file
 * @param {String} url - The path of the file to load from
 * @return {void}
 */
FrameForm.prototype.loadModel = function (url) {
//	console.log ("FrameForm.loadModel");
	$.get(url, function (data, textStatus, jqxhr) {
		appli.addModel(_modelName,_modelTab,_modelCreator,
				_modelCreationDate,_modelDescription,_modelId);
		URL.revokeObjectURL(url);// delete the objectUrl
	});
};


//==============================================================================
/**
 * Export SVG files of the 2D views
 * @param {int} id - the numero of the slice
 * @param {int} cubeSize - the size of the cube to draw in mm
 * @return {void}
 */
FrameForm.prototype.exportAsSvg = function (id, cubeSize) {
//	console.log ("FrameForm.exportAsSvg");
	if (this.selectedModel[0] == null || this.selectedModel.length!=1) {
		alert ("Vous devez sélectionner un modèle");
		return;
	}
	var model = this.selectedModel[0];
	
	model.setId(id);
	var name = id+'.'+model.getName()+'SVG';
	var zip = new JSZip();
	var folder = zip.folder(name);
	var tmp = this.getAllSVG();
	
	width = parseInt(cubeSize);
	for (var i = 0; i< 3; i++) {
		var folderInFolder = folder.folder(id+'.'+model.getName()
				+'_'+AxisEnum.properties[i].name);
		
		for (var j = 0; j < model.getSize().m[i]; j++) {
			folderInFolder.file(id+'.'+model.getName()+'_'
					+AxisEnum.properties[i].name+(j+1)
					+'.svg',this.getSVG(i,j,width));
		}
		
		folderInFolder.file(id + '.' + model.getName() + '_'
				+ AxisEnum.properties[i].name+'.svg', this.getAllSVG(i,width));
	}
	var content = zip.generate({type : "blob"});
	window.saveAs(content, name + ".zip");
};


//==============================================================================
/**
 * Export SVG files of the 2D views for the given axis.
 * @param {AxisEnum} axis - Axis on which are the grid to export.
 * @param {int} width - size of a cube in millimeter.
 * @return {String} the svg data.
 */
FrameForm.prototype.getAllSVG = function (axis, width) {
//	console.log ("FrameForm.getAllSVG");
	tab =  this.selectedModel[0].getModel();
	if (tab != null) {
		var tmp='<svg width="'+(width*25)+'mm" height="'+(width*25)*25+'mm">';
		for (var x = 0; x < 25; x++) {
			tmp+='<line x1="0" y1="'+(x*(width*25))+'mm" x2="1000" y2="'
					+(x*(width*25))+'mm" stroke="blue" stroke-width="5"/>';
			for (var y = 0; y < 25; y++) {
				for (var z = 0; z < 25; z++) {
					if (tab.getCube(x,y,z) != null) {
						if (axis == 0) {
							tmp+='<rect x="'+((y)*(width))+'mm" y="'
									+((24-z)*(width)+(x*(width*25)))
									+'mm" width="'+(width)+'mm" height="'
									+(width)+'mm"/>';
						}
						else if (axis == 1) {
							tmp+='<rect x="'+((x)*(width))+'mm" y="'
									+((24-z)*(width)+(y*(width*25)))
									+'mm" width="'+(width)+'mm" height="'
									+(width)+'mm"/>';
						}
						else if (axis == 2) {
							tmp+='<rect x="'+((x)*(width))+'mm" y="'
									+((24-y)*(width)+(z*(width*25)))
									+'mm" width="'+(width)+'mm" height="'
									+(width)+'mm"/>';
						}
					} // end if
				} // end for z
			} // end for y
		} // end for x
		tmp += "</svg>";
		return tmp;
	}
	return "modèle vide"
};


//==============================================================================
/**
 * Export SVG files of the 2D views for a given axis and grid number.
 * @param {AxisEnum} axis - the axis of slice we are exporting.
 * @param {int} grid - the id of the grid.
 * @param {int} width - size of a cube in millimeter.
 * @return {String} the svg data.
 */
FrameForm.prototype.getSVG = function (axis, grid, width) {
//	console.log ("FrameForm.getSVG");
	var model = this.selectedModel[0];
	var tab =  model.getModel();
	var tmp='<svg width="'+(width*25)+'mm" height="'+(width*25)+'mm">';
	if (tab != null) {
		
		switch (axis) {
		case 0 :
			for (var i=0; i<model.getSize().m[1]; ++i) {
				for (var j=0; j<model.getSize().m[2]; ++j) {
					if (model.getModel().getCube(
							grid,i,j) != null) {
						tmp+='<rect x="'+((i)*(width))+'mm" y="'
								+((24-j)*(width))+'mm" width="'+(width)
								+'mm" height="'+(width)+'mm"/>';
					}
				}
			}
			break;
		case 1 :
			for (var i=0; i<model.getSize().m[0]; ++i) {
				for (var j=0; j<model.getSize().m[2]; ++j) {
					if (model.getModel().getCube(
							i,grid,j) != null) {
						tmp+='<rect x="'+((i)*(width))+'mm" y="'
								+((24-j)*(width))+'mm" width="'+(width)
								+'mm" height="'+(width)+'mm"/>';
					}
				}
			}
			break;
		case 2 :
			for (var i=0; i<model.getSize().m[0]; ++i) {
				for (var j=0; j<model.getSize().m[1]; ++j) {
					if (model.getModel().getCube(
							i,j,grid) != null) {
						tmp+='<rect x="'+((i)*(width))+'mm" y="'
								+((24-j)*(width))+'mm" width="'+(width)
								+'mm" height="'+(width)+'mm"/>';
					}
				}
			}
			break;
		} // end switch
		tmp += "</svg>";
		return tmp;
	} // end if
	
	return "modèle vide";
};


