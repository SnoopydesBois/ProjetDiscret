/*
 * FrameList.js
 * 
 * author : abisutti
 * created : Thu, 28 May 2015 15:50:00 +0200
 */


	  ///////////////////
	 /// Constructor ///
	///////////////////

FrameList.prototype = new Frame ();
FrameList.prototype.constructor = FrameList;


/**
 * @constructor
 * @param {Application} application - The application to send signal to
 */
function FrameList (application) {
	Frame.call (this,application);
	this.htmlSrc = "Frame/iFrameList.html";
	this.idIFrameContent = null;
	
	this.listModel = null;
	this.selectedModel = null;
	
	this.listModelVisible3D = new Array();
	this.listModelVisible2D = new Array();
	
	this.funcs = [];
	this.funcs.push(new ControllerListAdd(this, "ControllerListAdd",
			this.appli));
	this.funcs.push(new ControllerListRemove(this, "ControllerListRemove",
			this.appli));
			
	for (var i in this.funcs) {
		this.appli.addFunctionality (this.funcs[i]);
	}
};



	  //////////////////////////////
	 /// Accessors and Mutators ///
	//////////////////////////////



/**
 * Set the list of models
 * @param {ModelController[]} list - The list of models
 * @return {void}
 */
FrameList.prototype.setList = function (list) {
	this.listModel = list;
};


//==============================================================================
/**
 * Set the application to which we send information
 * @param {Application} appli 
 * @return {void}
 */
FrameList.prototype.setAppli = function (appli) {
	this.appli = appli;
};


//==============================================================================
/**
 * Set a reference to the attribute "SelectedModel" from the application
 * @param {ModelController} model 
 * @return {void}
 */
FrameList.prototype.setSelectedModel = function (model) {
	this.selectedModel = model;
};


//==============================================================================
/**
 * @param {HTMLElement} elem - The element.
 * @return {ModelController} the model connected to the element
 * on which the event occurs 
 */
FrameList.prototype.getModelSelected = function (elem) {
	
	for (var i in this.listModel) {
		if (elem.title == this.listModel[i].getName()) { 			
			return this.listModel[i];
		}
	}
	return null;
};


//==============================================================================
/**
 * @return {ModelController[]} - The list of model visible in 3D
 */
FrameList.prototype.getListModelVisible3D = function () {
	return this.listModelVisible3D;
};



//==============================================================================
/**
 * @return {ModelController[]} - The list of model visible in 2D
 */
FrameList.prototype.getListModelVisible2D = function () {
	return this.listModelVisible2D;
};



	  /////////////////////
	 /// Other methods ///
	/////////////////////

/**
 * Send a new signal to the application to update 2D view
 * @return {void}
 */
FrameList.prototype.signal2D = function () {
    this.appli.alertChange (new Signal(SignalEnum.LIST_MODEL_2D_CHANGE));
};



//==============================================================================
/**
 * Send a new signal to the application to update 3D view
 * @return {void}
 */
FrameList.prototype.signal3D = function () { 
	this.appli.alertChange (new Signal(SignalEnum.LIST_MODEL_3D_CHANGE));
};



//==============================================================================
/**
 * Send signals to the application to update 2D and 3D view
 * @return {void}
 */
FrameList.prototype.signal2D3D = function () {
	this.signal2D();
    this.signal3D();
};



//==============================================================================
/**
 * Preparation of the frame
 * @param {int} idIFrame
 * @return {void}
 */
FrameList.prototype.prepare = function (idIFrame,doc) {
	if (!idIFrame)
		throw "FrameList.prepare : invalid iframe id (" + idIFrame + ")";
	
	// handle id container
	this.idIFrame = idIFrame;
	this.frameDocument = doc;
	this.idIFrameContent = document.getElementById (
		this.idIFrame).contentWindow.document;
};


//==============================================================================
/**
 * Add a button to the list for a new model
 * @param {ModelController} model - The ModelController to link the button 
 * and checkboxes with
 * @param {boolean} undoRedo - indicates if the function is called from an 
 * undo/redo action
 * @return {void}
 */
FrameList.prototype.addModel = function (model, undoRedo) {
	
	for (var i in this.listModel) {
		if (model.getName() == this.listModel[i].getName()) {
			this.appli.alertMessage ("Ce nom existe déjà" 
				+ ", impossible de l'ajouter", 4000);
			return;
		}
	}
	
	this.listModel.push (model);
	this.emptyList(this.listModelVisible2D, "2D");
	this.emptyList(this.listModelVisible3D, "3D");
	this.addModelToList(this.listModelVisible2D, model);
	this.addModelToList(this.listModelVisible3D, model);
	
	var insert = -1 // -1 to insert at the end, 0 to insert at the beginning
	
    // Creation of the div to put the button
    var content =  this.idIFrameContent.getElementById("modelList");
    content.setAttribute("class","modelElements");
    
    
    var row = content.insertRow(insert);// at the end of the table
        row.setAttribute("id", model.getName() + "Row");
    
    // ====================== Add the checkboxSelect
    var cell = row.insertCell(insert);
    cell.setAttribute("class", "selectModel");
    var checkBox = document.createElement("INPUT");
    
    checkBox.setAttribute("type","checkBox");
    checkBox.setAttribute("id", model.getName() + "Selected");
    checkBox.setAttribute("title", model.getName());
    
    //put the fonction that will be called
    checkBox.addEventListener("mousedown",this.selectModel.bind(this));
    
    checkBox.checked = true;
    checkBox.innerHTML = model.getName() + "Selected";
    

    cell.appendChild(checkBox);
    
    //this.emptyList(this.selectedModel, "Selected");
    this.selectedModel.splice(0, 0, model);
    
    
    // ====================== Add the button
    // Creation of the button
    var cell = row.insertCell(insert);
    
    cell.setAttribute("class", "nameModel");
    var button = document.createElement("span");
    
    button.setAttribute("id", model.getName());
    button.setAttribute("class","model");
    button.setAttribute("title", model.getName());
    
    //put the fonction that will be called
    cell.addEventListener("mousedown", this.check.bind(this));
    		    
    button.innerHTML = model.getName();
    
    // Add the button
    cell.appendChild(button);
    
    
    // ====================== Add the checkbox3D
    cell = row.insertCell(insert);
    cell.setAttribute("class", "checkbox3D active");

    checkBox = document.createElement("INPUT");
    
    checkBox.setAttribute("type","checkBox");
    checkBox.setAttribute("id", model.getName() + "3D");
    checkBox.setAttribute("title", model.getName());

    //put the fonction that will be called
    //checkBox.addEventListener("click",this.showModel3D.bind(this));
	checkBox.checked = true;
	checkBox.innerHTML = model.getName() + "3D";
	cell.addEventListener("click", this.appli.switchActive);   
	// Add the checkbox to the div	    
	cell.appendChild(checkBox);
	cell.addEventListener("click", this.showModel3D.bind(this));
	cell.addEventListener("click", this.appli.switchActive);
	cell.addEventListener("click", function (e) {
								e.stopPropagation();
						});    
	
	
	// ====================== Add the checkbox2D   
    cell = row.insertCell(insert);
    cell.setAttribute("class", "checkbox2D active");
	
    checkBox = document.createElement("INPUT");
    checkBox.setAttribute("type","checkBox");
    checkBox.setAttribute("id", model.getName() + "2D");
    checkBox.setAttribute("title", model.getName());
    checkBox.checked = true;

    //put the fonction that will be called
    //checkBox2.addEventListener("mousedown",this.showModel2D.bind(this));
    		
	checkBox.innerHTML = model.getName() + "2D";

	// Add the checkbox to the div	
	cell.appendChild(checkBox);
	cell.addEventListener("click", this.showModel2D.bind(this));
	cell.addEventListener("click", this.appli.switchActive);
	cell.addEventListener("click", function (e) {
								e.stopPropagation();
						});
	
	// ====================== Add the removeButton
	cell = row.insertCell(insert);
    cell.setAttribute("class", "removeModel");
    var checkBox = document.createElement("button");
    
    checkBox.setAttribute("id", model.getName() + "Remove");
    checkBox.setAttribute("class", "ButtonRemove");
    checkBox.setAttribute("title", model.getName());

    //put the fonction that will be called
    checkBox.addEventListener("mousedown",this.deleteModel.bind(this));
    checkBox.checked = true;
    checkBox.innerHTML = "x";
    
    // Add the checkbox to the div	    
    cell.appendChild(checkBox);
   
    // Add the div to the IFrame
    
    this.signal2D3D();	
	//console.log (undoRedo);
	if (undoRedo == undefined) {
		this.appli.addAction(new Action("ControllerListAdd",model));
    }
	this.scrollWidthAdjust();
	
	
};


//==============================================================================
/**
 * Remove model from the list of object
 * @param {ModelController} model - The ModelController to remove from the list
 * @param {boolean} undoRedo - indicates if the function is called from an 
 * undo/redo action
 * @return {void}
 */
FrameList.prototype.removeModel = function (name, undoRedo) {
	var indice = -1;
	var model;
	
	// Get the model from the list based on it's name
	for (var i in this.listModel) {
		if (name == this.listModel[i].getName()) {
			indice = i;
			model = this.listModel[i];
			break;
		}
	}
	if (indice == -1) {
		this.appli.alertMessage("Ce modèle n'existe pas", 4000);
		return;
	}
	
	// Remove model from the 2D/3D space if needed
	if (this.idIFrameContent.getElementById(
			name + "3D").checked) {
		this.removeModelFromList(this.listModelVisible3D, model);
		this.signal3D();
	}
	if (this.idIFrameContent.getElementById(
			name + "2D").checked) {
		this.removeModelFromList(this.listModelVisible2D, model);
		this.signal2D();
	}
	
	// Remove the elements from the list
	this.idIFrameContent.getElementById(name).remove(); 
    this.idIFrameContent.getElementById(name + "3D").remove();
    this.idIFrameContent.getElementById(name + "2D").remove();
    this.idIFrameContent.getElementById(name + "Remove").remove();
    this.idIFrameContent.getElementById(name + "Selected").remove();
	this.idIFrameContent.getElementById(name + "Row").remove();
    
	this.listModel.splice(indice, 1);
	this.removeModelFromList(this.selectedModel, model);
	if (undoRedo == undefined) {
		//console.log ("undo dans if");
		this.appli.addAction(new Action("ControllerListRemove",model));
    }
	this.scrollWidthAdjust();
};


//==============================================================================
/**
 * Merge models from the list of object
 * @return {Array} the array of cubes of the new model 
 */
FrameList.prototype.fusionModel = function () {
	if (this.selectedModel.length < 2) {
		//console.log (this.selectedModel.length);
		this.appli.alertMessage("Pas de modèles à fusionner", 4000);
		return null;
	}
	
	// Allocate the matrix
	var newModel = new Array();
	var size = this.selectedModel[0].getSize();
	for (var x=0; x<size.m[2]; ++x) {
		newModel.push(new Array());
		for (var y=0; y<size.m[1]; ++y) {
			newModel[x].push(new Array());
			for (var z=0; z<size.m[0]; ++z) {
				newModel[x][y].push(false);
			}
		}
	}
	
	// Fill the matrix
	for (var i in this.selectedModel) {
		var tmpModel = this.selectedModel[i];
		for (var x=0; x<size.m[2]; ++x) {
			for (var y=0; y<size.m[1]; ++y) {
				for (var z=0; z<size.m[0]; ++z) {
					if (tmpModel.getCube(x,y,z)!=null) {
						newModel[z][y][x] = true;
					}
				}
			}
		}
	}
	return newModel;
};


//==============================================================================
/**
 * Delete a model by a click on the cross button
 * @param {MouseEvent} event - the mouse click
 * @return {void}
 */
FrameList.prototype.deleteModel = function (event) {
	var model = null;
	var elem = this.idIFrameContent.getElementById(
			event.target.getAttribute("id"));
			
	model = this.getModelSelected(elem);
	
	if (model != null) {
		
		this.removeModel(model.getName());
	}
	
};

//==============================================================================
/**
 * Remove a model from a list
 * @param {ModelController[]} list - The list to remove from
 * @param {ModelController} model - The model to remove
 * @return {void}
 */
FrameList.prototype.removeModelFromList = function (list, model) {
	for (var i in list) {
		if (model == list[i]) { 
			list.splice (i, 1);
			return;
		}
	}
};


//==============================================================================
/**
 * Remove a model from a list
 * @param {ModelController[]} list - The list to remove from
 * @param {ModelController} model - The model to remove
 * @return {void}
 */
FrameList.prototype.emptyList = function (list, type) {
	for (var i = 0; i < list.length; i++) {
		this.idIFrameContent.getElementById(list[i].getName() + type).checked = false;
		this.appli.setActiveClass(
				this.idIFrameContent.getElementById(
				list[i].getName() + type).parentElement,
				false);
		
	}
	list.splice (0, list.length);
};


//==============================================================================
/**
 * Remove a model from a list
 * @param {MouseEvent} element -  The element
 * @param {ModelController[]} list - The list to modify
 * @return {void}
 */
FrameList.prototype.removeModelSelected = function (element, list) {
	var model = this.getModelSelected(element);
	this.removeModelFromList (list, model);
};


//==============================================================================
/**
 * Add a model to a list
 * Does not accept multiple instance of the same model
 * @param {ModelController[]} list - the list to modify
 * @param {ModelController} model - the model to add
 * @return {void}
 */
FrameList.prototype.addModelToList = function (list, model) {
	for (var i = 0; i < list.length; i++) {
		if (list[i] == model) {
			return;
		}
	}
	list.push(model);
};


//==============================================================================
/**
 * Call by a button pressed
 * Check the checkbox and select the model clicked
 * @param {MouseEvent} event - the mouse click
 * @return {void}
 */
FrameList.prototype.selectModel = function (event) {
	var model = this.getModelSelected(event.target);
	if (model == null) { // Should not occur
		return;
	}
	
	// Remove from the views
	if (this.idIFrameContent.getElementById(
			event.target.getAttribute("id")).checked) {
		this.removeModelFromList(this.selectedModel, model);
		this.removeModelFromList(this.listModelVisible3D, model);
		this.removeModelFromList(this.listModelVisible2D, model);
		this.idIFrameContent.getElementById(
				model.getName() + "3D").checked = false;
		this.idIFrameContent.getElementById(
				model.getName() + "2D").checked = false;
	}
	// Add to the views
	else {
		this.addModelToList(this.selectedModel, model);
		this.addModelToList(this.listModelVisible3D, model);
		this.addModelToList(this.listModelVisible2D, model);
		this.idIFrameContent.getElementById(
				model.getName() + "3D").checked = true;
		this.idIFrameContent.getElementById(
				model.getName() + "2D").checked = true;
	}
	this.signal2D3D();
	this.appli.setActiveClass(this.idIFrameContent.getElementById(
				model.getName() + "2D").parentElement,
				!this.idIFrameContent.getElementById(
			event.target.getAttribute("id")).checked);
	this.appli.setActiveClass(this.idIFrameContent.getElementById(
				model.getName() + "3D").parentElement,
				!this.idIFrameContent.getElementById(
			event.target.getAttribute("id")).checked);

};



//==============================================================================
/**
 * Call by a button pressed
 * Check the checkboxes if they are not else, unchecked them
 * @param {MouseEvent} event - the mouse click
 * @return {void}
 */
FrameList.prototype.check = function (event) {
	
	// Prevents the checkboxes to be checked then unchecked
	var checked = false;
	var model = this.getModelSelected(event.target);
	// 3D Checkbox check
	if (!this.idIFrameContent.getElementById(
			event.target.getAttribute("id") + "3D").checked) {
			this.listModelVisible3D.push(this.getModelSelected(event.target));
		this.idIFrameContent.getElementById(
				event.target.getAttribute("id") + "3D").checked = true;
				
		this.addModelToList(this.listModelVisible3D, model);
		
		this.signal3D();
		this.appli.switchActive(this.idIFrameContent.getElementById(
			event.target.getAttribute("id") + "3D").parentElement);
		checked = true;
	}
	// 2D Checkbox check
	if (!this.idIFrameContent.getElementById(
			event.target.getAttribute("id") + "2D").checked)
	{
		this.idIFrameContent.getElementById(
				event.target.getAttribute("id") + "2D").checked = true;
		//console.log ("check::AddModel2D");
		this.addModelToList(this.listModelVisible2D, 
				this.getModelSelected(event.target));

		this.signal2D();
		this.appli.switchActive(this.idIFrameContent.getElementById(
			event.target.getAttribute("id") + "2D").parentElement);
		checked = true;
	}
	// 2D & 3D Checboxes uncheck
	if (!checked 
			&& this.idIFrameContent.getElementById(
			event.target.getAttribute("id") + "3D").checked
			&& this.idIFrameContent.getElementById(
			event.target.getAttribute("id") + "2D").checked) {
			
		this.idIFrameContent.getElementById(
				event.target.getAttribute("id") + "3D").checked = false;
		this.idIFrameContent.getElementById(
				event.target.getAttribute("id") + "2D").checked = false;

		this.removeModelSelected(event.target, this.listModelVisible3D);
		this.removeModelSelected(event.target, this.listModelVisible2D);
		
		this.signal2D3D();
		this.appli.switchActive(this.idIFrameContent.getElementById(
			event.target.getAttribute("id") + "3D").parentElement);
		this.appli.switchActive(this.idIFrameContent.getElementById(
			event.target.getAttribute("id") + "2D").parentElement);
	}
};


//==============================================================================
/**
 * Call the 3D view methods
 * @param {MouseEvent} event - the mouse click
 * @return {void}
 */
FrameList.prototype.showModel3D = function (event) {
	// Depending on the state of the checkbox, we call add or remove Model
	
	var target = event.target.firstElementChild;
	var tmpChecked = target.checked;
	if (tmpChecked) {		
		this.removeModelSelected(target, this.listModelVisible3D);
	}
	else {
		this.addModelToList(
			this.listModelVisible3D, this.getModelSelected(target));
	}
	target.checked = !tmpChecked;
	this.appli.switchActive(event.target);
	this.signal3D();
};


//==============================================================================
/**
 * Call the 2D view methods
 * @param {MouseEvent} event - the mouse click
 * @return {void}
 */
FrameList.prototype.showModel2D = function (event) {
	// Depending on the state of the checkbox, we call add or remove Model	
	
	var target = event.target.firstElementChild;
	var tmpChecked = target.checked;
	if (tmpChecked) {		
		this.removeModelSelected(target, this.listModelVisible2D);
	}
	else {
		this.addModelToList(
			this.listModelVisible2D, this.getModelSelected(target));
	}
	target.checked = !tmpChecked;
	this.appli.switchActive(event.target);
	this.signal2D();
};


//==============================================================================
/**
 * Call the 2D view methods
 * @param {MouseEvent} event - the mouse click
 * @return {void}
 */
 FrameList.prototype.scrollWidthAdjust = function () {
	var inside = this.idIFrameContent.getElementById('modelList');
	var outside = this.idIFrameContent.getElementById('table-warpper');
	if ($(inside).height()>$(outside).height()) {
		var scroll= this.getScrollBarWidth();
		$(inside).width($(inside).width()-scroll);
		
	}else {
		//console.log ("scrollWidthAdjust : Scroll not  present");
		$(inside).css("width","100%");
	}
 }
 
 
 //==============================================================================
/**
 * Give the width of the scroll bar
 * @return {int} the width of the scroll bar
 */
FrameList.prototype.getScrollBarWidth = function () {
    var $outer = $('<div>').css({visibility: 'hidden', 
			width: 100, overflow: 'scroll'}).appendTo('body'),
        widthWithScroll = $('<div>').css({
					width: '100%'}).appendTo($outer).outerWidth();
    $outer.remove();
    return 100 - widthWithScroll;

};
