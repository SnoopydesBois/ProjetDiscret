/*
 * ToolStateEnum.js
 * 
 * created : Thu, 28 May 2015 15:38:56 +0200
 * modified : Thu, 28 May 2015 15:38:56 +0200
 */



var ToolStateEnum = {
	ACTIVE : 0,
	ACCESSIBLE : 1,
	INACCESSIBLE : 2,
	properties : {
		0 : {htmlClass : "activeTool"},
		1 : {htmlClass : ""},
		2 : {htmlClass : "inaccessible"}
	}
};



/**
 * Allows the enumeration to be constant
 */
if (Object.freeze)
	Object.freeze (ToolStateEnum);

