/// LICENCE ////////////////////////////////////////////////////////////////////

/* Copyright (juin 2015)
 * Auteur : BENOIST Thomas, BISUTTI Adrien, DESPLEBAIN Tanguy, LAURET Karl
 * 
 * benoist.thomas@hotmail.fr
 * biscui_86@hotmail.fr
 * tanguy.desplebain@gmail.com
 * lauret.karl@hotmail.fr
 * 
 * Ce logiciel est un programme informatique servant à modéliser des
 * structures 3D voxellisées. 
 * 
 * Ce logiciel est régi par la licence CeCILL soumise au droit français et
 * respectant les principes de diffusion des logiciels libres. Vous pouvez
 * utiliser, modifier et/ou redistribuer ce programme sous les conditions
 * de la licence CeCILL telle que diffusée par le CEA, le CNRS et l'INRIA 
 * sur le site "http://www.cecill.info".
 * 
 * En contrepartie de l'accessibilité au code source et des droits de copie,
 * de modification et de redistribution accordés par cette licence, il n'est
 * offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
 * seule une responsabilité restreinte pèse sur l'auteur du programme,  le
 * titulaire des droits patrimoniaux et les concédants successifs.
 * 
 * A cet égard  l'attention de l'utilisateur est attirée sur les risques
 * associés au chargement,  à l'utilisation,  à la modification et/ou au
 * développement et à la reproduction du logiciel par l'utilisateur étant 
 * donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
 * manipuler et qui le réserve donc à des développeurs et des professionnels
 * avertis possédant  des  connaissances  informatiques approfondies.  Les
 * utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
 * logiciel à leurs besoins dans des conditions permettant d'assurer la
 * sécurité de leurs systèmes et ou de leurs données et, plus généralement, 
 * à l'utiliser et l'exploiter dans les mêmes conditions de sécurité. 
 * 
 * Le fait que vous puissiez accéder à cet en-tête signifie que vous avez 
 * pris connaissance de la licence CeCILL, et que vous en avez accepté les
 * termes.
 */

/// INDEX //////////////////////////////////////////////////////////////////////

/* constructor (controllerName : String, action : mixed)
 * getControllerName () : String
 * getAction () : mixed
 * isValidAction () : boolean
 * dump () : void
 * toString () : String
 */

/// CODE ///////////////////////////////////////////////////////////////////////



	  ///////////////////
	 /// Constructor ///
	///////////////////


Action.prototype.constructor = Action;

/**
 * @constructor Build an action with the name of the controller which create 
 * this action and an object which contain the data action. 
 * @param {String} controllerName - the controller name.
 * @param {mixed} action - data action.
 */
function Action (controllerName, action) {
//	console.log ("Action.constructor")
	
	if (controllerName === "" || action === null) {
		console.error ("Action.constructor : bad parameter in constructor");
		return;
	}
	
	/**
	 * {String} The controller name which execute this action.
	 */
	this.controllerName = controllerName;
	
	/**
	 * {mixed} The action. It's an object writen by the controller. Only it can
	 * read this action.
	 */
	this.action = action;
	
};


	  /////////////////
	 /// Accessors ///
	/////////////////



/**
 * @return {String} the controller name.
 */
Action.prototype.getControllerName = function () {
//	console.log ("Action.getControllerName");
	return this.controllerName;
};



//==============================================================================
/**
 * @return {mixed} the action.
 */
Action.prototype.getAction = function () {
//	console.log ("Action.getAction");
	return this.action;
};


	  /////////////////////
	 /// Other methods ///
	/////////////////////


/**
 * Check if the action was correctly constructed.
 * @return {boolean} true if valid, false otherwise.
 */
Action.prototype.isValidAction = function () {
//	console.log ("Action.isValidAction");
	return (this.controllerName != undefined && this.action != undefined);
};



//==============================================================================
/**
 * Dump all members in the console.
 * @return {void}
 */
Action.prototype.dump = function () {
//	console.log ("Action.dump");
	console.log ("------- Action.dump -------");
	console.log ("controller name : " + this.controllerName);
	console.log ("action : vvv");
	console.log (this.action);
	console.log ("---------------------------");
};



//==============================================================================
/**
 * @return {String} a string representation of the action.
 */
Action.prototype.toString = function () {
//	console.log ("Action.toString");
	return "Action : " + this.controllerName + ", " + this.action;
};


