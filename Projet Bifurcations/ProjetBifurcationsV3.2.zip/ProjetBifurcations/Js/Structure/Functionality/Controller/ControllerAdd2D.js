/// LICENCE ////////////////////////////////////////////////////////////////////


/* Copyright (juin 2015)
 * Auteur : BENOIST Thomas, BISUTTI Adrien, DESPLEBAIN Tanguy, LAURET Karl
 * 
 * benoist.thomas@hotmail.fr
 * biscui_86@hotmail.fr
 * tanguy.desplebain@gmail.com
 * lauret.karl@hotmail.fr
 * 
 * Ce logiciel est un programme informatique servant à modéliser des
 * structures 3D voxellisées.
 * 
 * Ce logiciel est régi par la licence CeCILL soumise au droit français et
 * respectant les principes de diffusion des logiciels libres. Vous pouvez
 * utiliser, modifier et/ou redistribuer ce programme sous les conditions
 * de la licence CeCILL telle que diffusée par le CEA, le CNRS et l'INRIA
 * sur le site "http://www.cecill.info".
 * 
 * En contrepartie de l'accessibilité au code source et des droits de copie,
 * de modification et de redistribution accordés par cette licence, il n'est
 * offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
 * seule une responsabilité restreinte pèse sur l'auteur du programme,  le
 * titulaire des droits patrimoniaux et les concédants successifs.
 * 
 * A cet égard  l'attention de l'utilisateur est attirée sur les risques
 * associés au chargement,  à l'utilisation,  à la modification et/ou au
 * développement et à la reproduction du logiciel par l'utilisateur étant
 * donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
 * manipuler et qui le réserve donc à des développeurs et des professionnels
 * avertis possédant  des  connaissances  informatiques approfondies.  Les
 * utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
 * logiciel à leurs besoins dans des conditions permettant d'assurer la
 * sécurité de leurs systèmes et ou de leurs données et, plus généralement,
 * à l'utiliser et l'exploiter dans les mêmes conditions de sécurité.
 * 
 * Le fait que vous puissiez accéder à cet en-tête signifie que vous avez
 * pris connaissance de la licence CeCILL, et que vous en avez accepté les
 * termes.
 */

/// INDEX //////////////////////////////////////////////////////////////////////


/*
 * kernel : KernelAdd2D
 * kernelRemove : KernelRemove2D
 * isDown : false
 * model : ModelController
 * faces : Array
 * 
 * ControllerAdd2D (frame : Frame, name : string, application : Application)
 * mouseDown (event : WindowEvent, face : Facet) : void
 * mouseUp (event : WindowEvent, face : Facet) : void
 * mouseMouv (event : WindowEvent, face : Facet) : void
 * addCube (face : Facet) : void
 * undo (object : Action) : void
 * redo (object : Action) : void
 */

/// CODE ///////////////////////////////////////////////////////////////////////



ControllerAdd2D.prototype = new Controller ();
ControllerAdd2D.prototype.constructor = ControllerAdd2D;


/**
 * @constructor
 * @param {Frame} frame - The frame associated with the controller.
 * @param {String} name - The name of the controller.
 * @param {Application} application - the application.
 */
function ControllerAdd2D (frame, name, application) {
//	console.log ("ControllerAdd2D.constructor");
	Controller.call (this,frame, name, application);
	
	/**
	 * {KernelAdd2D} 
	 */
	this.kernel = new KernelAdd2D ();
	
	/**
	 * {KernelAdd2D} 
	 */
	this.kernelRemove = new KernelRemove2D ();
	
	/**
	 * {boolean} 
	 */
	this.isDown = false;
	
	/**
	 * {ModelController} 
	 */
	this.model = null;
	
	/**
	 * {Array} 
	 */
	this.faces = [];
};


//==============================================================================
/**
 * Down a button of the mouse.
 * @param {WindowEvent} event - event captured by the window.
 * @param {Facet} face - face overflown by the mouse.
 * @return {void}
 */
ControllerAdd2D.prototype.mouseDown = function (event, face) {
//	console.log ("ControllerAdd2D.mouseDown");
	this.model = this.frame.getCurentModel();
	if (this.actif && this.model != null) {
		this.addCube(face);
	}
	//this.addCube(event, face);
	this.isDown =true;
};


//==============================================================================
/**
 * Release the mouse button.
 * @param {WindowEvent} event - event captured by the window.
 * @param {Facet} face - face overflown by the mouse.
 * @return {void}
 */
ControllerAdd2D.prototype.mouseUp = function (event, face) {
	//console.log ("ControllerAdd2D.mouseUp");
	if (typeof event != "object") {
		console.error ("ERROR - Controller.mouseUp : bad type of parameter");
	}

	if (this.faces.length != 0) {
		var object = { model : this.model, facet : this.faces};
		this.appli.addAction(new Action(this.getName(),object));
	}
	this.faces = [];
	this.isDown =false;
};


//==============================================================================
/**
 * Move the mouse.
 * @param {WindowEvent} event - event captured by the window.
 * @param {Facet} face - face overflown by the mouse.
 * @return {void}
 */
ControllerAdd2D.prototype.mouseMouv = function (event, face) {
	//console.log ("ControllerAdd2D.mouseMouv");
	if (typeof event != "object") {
		console.error ("ERROR - Controller.mouseMouv : bad type of parameter");
	}
	// --------------------------------------
	if (this.isDown) {
		this.addCube(face);
	}
};


//==============================================================================
/**
 * Action common to at least 2 event.
 * @param {Facet} face - face overflown by the mouse.
 * @return {void}
 */
ControllerAdd2D.prototype.addCube = function (face) {
//	console.log ("ControllerAdd2D.addCube");
	this.model = this.frame.getCurentModel ();
	if (this.actif && this.model != null) {
		if (this.model.getModel().getCube (
			face.getCube().m[0],
			face.getCube().m[1],
			face.getCube().m[2]) == null)
		{
			this.kernel.add (this.model, face);
			this.faces.push (face);
			this.model.alert (new Signal (SignalEnum.ADD_REMOVE_CUBES, face));
		}
	}	
};


//==============================================================================
/**
 * Undo the add action.
 * @param {Action} object - the undo/redo object.
 * @return {void}
 */
ControllerAdd2D.prototype.undo = function (object) {
//	console.log ("ControllerAdd2D.undo");
	if (object.model != null) {
		var sign = new Signal (SignalEnum.ADD_REMOVE_CUBES);
		for (var i = 0; i < object.facet.length; i++) {
			this.kernelRemove.remove(object.model, object.facet[i]);
			sign.addCubes (object.facet[i]);
		}
		object.model.alert (sign);
	}
};


//==============================================================================
/**
 * Redo the add action, after the undo action.
 * @param {Action} object - the undo/redo object.
 * @return {void}
 */
ControllerAdd2D.prototype.redo = function (object) {
//	console.log ("ControllerAdd2D.redo");
	if (object.model != null) {
		var sign = new Signal (SignalEnum.ADD_REMOVE_CUBES);
		for (var i = 0; i < object.facet.length; i++) {
			this.kernel.add(object.model, object.facet[i]);
			sign.addCubes(object.facet[i]);
		}
		object.model.alert (sign);
	}
};


