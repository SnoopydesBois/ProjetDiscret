/// LICENCE ////////////////////////////////////////////////////////////////////

/* Copyright (juin 2015)
 * Auteur : BENOIST Thomas, BISUTTI Adrien, DESPLEBAIN Tanguy, LAURET Karl
 * 
 * benoist.thomas@hotmail.fr
 * biscui_86@hotmail.fr
 * tanguy.desplebain@gmail.com
 * lauret.karl@hotmail.fr
 * 
 * Ce logiciel est un programme informatique servant � mod�liser des
 * structures 3D voxellis�es.
 * 
 * Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
 * respectant les principes de diffusion des logiciels libres. Vous pouvez
 * utiliser, modifier et/ou redistribuer ce programme sous les conditions
 * de la licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA
 * sur le site "http://www.cecill.info".
 * 
 * En contrepartie de l'accessibilit� au code source et des droits de copie,
 * de modification et de redistribution accord�s par cette licence, il n'est
 * offert aux utilisateurs qu'une garantie limit�e.  Pour les m�mes raisons,
 * seule une responsabilit� restreinte p�se sur l'auteur du programme,  le
 * titulaire des droits patrimoniaux et les conc�dants successifs.
 * 
 * A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
 * associ�s au chargement,  � l'utilisation,  � la modification et/ou au
 * d�veloppement et � la reproduction du logiciel par l'utilisateur �tant
 * donn� sa sp�cificit� de logiciel libre, qui peut le rendre complexe � 
 * manipuler et qui le r�serve donc � des d�veloppeurs et des professionnels
 * avertis poss�dant  des  connaissances  informatiques approfondies.  Les
 * utilisateurs sont donc invit�s � charger  et  tester  l'ad�quation  du
 * logiciel � leurs besoins dans des conditions permettant d'assurer la
 * s�curit� de leurs syst�mes et ou de leurs donn�es et, plus g�n�ralement,
 * � l'utiliser et l'exploiter dans les m�mes conditions de s�curit�.
 * 
 * Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez
 * pris connaissance de la licence CeCILL, et que vous en avez accept� les
 * termes.
 */

/// INDEX //////////////////////////////////////////////////////////////////////

/*
 * kernel : KernelCopy
 * 
 * ControllerCopy (frame : Frame, name : String)
 * pressKey (event) : void
 */

/// CODE ///////////////////////////////////////////////////////////////////////


ControllerCopy.prototype = new Controller ();
ControllerCopy.prototype.constructor = ControllerCopy;


/**
 * @constructor
 * @param {Frame} frame - The frame associated with the controller.
 * @param {String} name - The name of the controller.
 */
function ControllerCopy (frame, name) {
//	console.log ("ControllerCopy.constructor");
	// --------------------------------------
	Controller.call (this, frame, name);
	
	/**
	 * {KernelCopy}. The kernel.
	 */
	this.kernel = new KernelCopy ();
};


//==============================================================================
/**
 * Button of the keyboard has been activated.
 * @param {WindowEvent} event - event captured by the window.
 * @return {void}
 */
ControllerCopy.prototype.pressKey = function (event) {
//	console.log ("ControllerCopy.pressKey");
	if (typeof event != "object") {
		console.error ("ERROR - ControllerCopy.pressKey : bad type of "
			+ "parameter");
	}
	// --------------------------------------
	var model = this.frame.getCurentModel();
	if (this.actif && model != null) {
		if (event.key == 'm') {
			this.kernel.CopyCubeSelected(model);
		}
	}
};


