/// LICENCE ////////////////////////////////////////////////////////////////////

/* Copyright (juin 2015)
 * Auteur : BENOIST Thomas, BISUTTI Adrien, DESPLEBAIN Tanguy, LAURET Karl
 * 
 * benoist.thomas@hotmail.fr
 * biscui_86@hotmail.fr
 * tanguy.desplebain@gmail.com
 * lauret.karl@hotmail.fr
 * 
 * Ce logiciel est un programme informatique servant à modéliser des
 * structures 3D voxellisées.
 * 
 * Ce logiciel est régi par la licence CeCILL soumise au droit français et
 * respectant les principes de diffusion des logiciels libres. Vous pouvez
 * utiliser, modifier et/ou redistribuer ce programme sous les conditions
 * de la licence CeCILL telle que diffusée par le CEA, le CNRS et l'INRIA
 * sur le site "http://www.cecill.info".
 * 
 * En contrepartie de l'accessibilité au code source et des droits de copie,
 * de modification et de redistribution accordés par cette licence, il n'est
 * offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
 * seule une responsabilité restreinte pèse sur l'auteur du programme,  le
 * titulaire des droits patrimoniaux et les concédants successifs.
 * 
 * A cet égard  l'attention de l'utilisateur est attirée sur les risques
 * associés au chargement,  à l'utilisation,  à la modification et/ou au
 * développement et à la reproduction du logiciel par l'utilisateur étant
 * donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
 * manipuler et qui le réserve donc à des développeurs et des professionnels
 * avertis possédant  des  connaissances  informatiques approfondies.  Les
 * utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
 * logiciel à leurs besoins dans des conditions permettant d'assurer la
 * sécurité de leurs systèmes et ou de leurs données et, plus généralement,
 * à l'utiliser et l'exploiter dans les mêmes conditions de sécurité.
 * 
 * Le fait que vous puissiez accéder à cet en-tête signifie que vous avez
 * pris connaissance de la licence CeCILL, et que vous en avez accepté les
 * termes.
 */

/// INDEX //////////////////////////////////////////////////////////////////////


/*
 * kernelextr : KernelExtrusion
 * kerneladd : KernelAdd
 * kernelremove : KernelRemove
 * modelIntern : ModelControllerExtrut
 * nbExtrud : int
 * coordoMouse : int[2]
 * mouseLeft : boolean
 * possif : boolean
 *
 * ControllerExtrusion (frame : Frame,
 *                      name : String,
 *                      modelContrExtrusion : ModelController,
 *                      possif : boolean,
 *                      application : Application)
 * mouseDown (event : WindowEvent, face : Facet) : void
 * mouseUp (event : WindowEvent, face : Facet) : void
 * mouseMouv (event : WindowEvent, face : Facet) : void
 * disactivate () : void
 * undo (object : Action) : void
 * redo (object : Action) : void
 */

/// CODE ///////////////////////////////////////////////////////////////////////

ControllerExtrusion.prototype = new Controller ();
ControllerExtrusion.prototype.constructor = ControllerExtrusion;


/**
 * @constructor
 * @param {Frame} frame - The frame associated with the controller.
 * @param {String} name - The name of the controller.
 * @param {modelContrExtrusion} modelContrExtrusion - The model to extrude.
 * @param {boolean} possif - Indicate the type of extrusion (positive or 
 * negative).
 * @param {Application} application - the application.
 */
function ControllerExtrusion (frame, name, modelContrExtrusion, possif,
	application)
{
	//console.log ("ControllerExtrusion.constructor");
	// --------------------------------------
	Controller.call(this, frame, name, application);
	
	/**
	 * {KernelExtrusion} 
	 */
	this.kernelextr = new KernelExtrusion();
	
	/**
	 * {KernelAdd} 
	 */
	this.kerneladd = new KernelAdd();
	
	/**
	 * {KernelRemove} 
	 */
	this.kernelremove = new KernelRemove();
	
	/**
	 * {ModelController} 
	 */
	this.modelIntern = modelContrExtrusion;
	
	/**
	 * {int} size of the extrusion.
	 */
	this.nbExtrud = 0;
	
	/**
	 * {int[2]} 
	 */
	this.coordoMouse = [0, 0];
	
	/**
	 * {boolean} 
	 */
	this.mouseLeft = false;
	
	/**
	 * {boolean} 
	 */
	this.possif = true;
	if (typeof possif != 'undefined')
		this.possif = possif;
};


//==============================================================================
/**
 * Press the mouse button.
 * @param {WindowEvent} event - event captured by the window.
 * @param {Facet} face - face overflown by the mouse.
 * @return {void}
 */
ControllerExtrusion.prototype.mouseDown = function (event, face) {
//	console.log ("ControllerExtrusion.mouseDown");
	if (typeof event != "object") {
		console.error ("ERROR - ControllerExtrusion.mouseDown : bad type of"
			+ " parameter");
	}
	// --------------------------------------
	if (this.actif) {
		this.coordoMouse[0] = event.clientX;
		this.coordoMouse[1] = event.clientY;
	}
	this.mouseLeft = true;
};


//==============================================================================
/**
 * Release the mouse button.
 * @param {WindowEvent} event - event captured by the window.
 * @param {Facet} face - face overflown by the mouse.
 * @return {void}
 */
ControllerExtrusion.prototype.mouseUp = function (event, face) {
	//console.log ("ControllerExtrusion.mouseUp");
	if (typeof event != "object") {
		console.error ("ERROR - ControllerExtrusion.mouseUp : bad type of" 
				+ " parameter");
	}
	// --------------------------------------
	var model = this.frame.getCurentModel();
	this.mouseLeft = false;
	var faces = [];
	if (this.actif && model != null) {
		if (this.possif) {
			if (this.nbExtrud == 0) {
				if (!event.ctrlKey&&!event.metaKey) {
					var sign = new Signal (SignalEnum.ADD_REMOVE_CUBES);
					var taille = model.getNbSelectedFacet();
					for (var i=0; i<taille; ++i) {
						var tmpfacet = model.getSelectedFacet(i);
						var direction = tmpfacet.getDirection();
						if (direction != DirectionEnum.ALL 
							|| direction != DirectionEnum.NONE) {
							var coordo = new Vector;
							coordo.m[0] = tmpfacet.getCube().m[0] 
									+ DirectionEnum.properties[direction].x;
							coordo.m[1] = tmpfacet.getCube().m[1] 
									+ DirectionEnum.properties[direction].y;
							coordo.m[2] = tmpfacet.getCube().m[2] 
									+ DirectionEnum.properties[direction].z;
							sign.addCubes(tmpfacet);
							if (model.isIn(coordo.m[0],coordo.m[1],coordo.m[2]))
							{
								sign.addCubes(new Facet(
										coordo,DirectionEnum.NONE));
								faces.push(new Facet (
										coordo,DirectionEnum.NONE));
							}
						}
					}
					this.kerneladd.AddFaceSelected(model);
					if (sign.getCubes().length >0) {
						model.alert (sign);
					}
				}
			}
			else {
				var sign = new Signal (SignalEnum.ADD_REMOVE_CUBES);
				var size = this.modelIntern.getModelController().getSize();
				for (var x=0; x<size.m[0]; ++x) {
					for (var y=0; y<size.m[1]; ++y) {
						for (var z=0; z<size.m[2]; ++z) {
							if (this.modelIntern.getModelController().getCube(
									x,y,z)!=null 
								&& model.getCube(x,y,z)==null) {
								
								sign.addCubes(new Facet (new Vector(x,y,z),
										DirectionEnum.NONE));
								faces.push(new Facet (new Vector(x,y,z),
										DirectionEnum.NONE));
							}
						}
					}
				}
				this.kernelextr.Extrusion(model,
						this.modelIntern.getModelController());
				if (sign.getCubes().length>0) {
					model.alert (sign);
				}
			}
			if (faces.length>0) {
				var object = { model : model, facet : faces, add : true };
				this.appli.addAction(new Action(this.getName(),object));
			}
		} 
		else {
			if (this.nbExtrud == 0) {
				if (!event.ctrlKey&&!event.metaKey) {
					var sign = new Signal (SignalEnum.ADD_REMOVE_CUBES, face);
					for (var i=0; i<model.getNbSelectedFacet(); ++i) {
						sign.addCubes(model.getSelectedFacet(i));
						faces.push(model.getSelectedFacet(i));
					}
					this.kernelremove.RemoveCubeSelected(model);
					if (sign.getCubes().length>0) {
						model.alert (sign);
					}
				}
			}
			else {
				var sign = new Signal (SignalEnum.ADD_REMOVE_CUBES);
				var size = this.modelIntern.getModelController().getSize();
				for (var x=0; x<size.m[0]; ++x) {
					for (var y=0; y<size.m[1]; ++y) {
						for (var z=0; z<size.m[2]; ++z) {
							if (this.modelIntern.getModelController().getCube(
									x,y,z)!=null 
								&& model.getCube(x,y,z)!=null) {
								
								sign.addCubes(new Facet (new Vector(x,y,z),
										DirectionEnum.NONE));
								faces.push(new Facet (new Vector(x,y,z),
										DirectionEnum.NONE));
							}
						}
					}
				}
				this.kernelextr.Extrusion(model,
						this.modelIntern.getModelController());
				if (sign.getCubes().length >0) {
					model.alert (sign);
				}
			}
			if (faces.length>0) {
				var object = { model : model, facet : faces, add : false };
				this.appli.addAction(new Action(this.getName(),object));
			}
		}
		this.nbExtrud = 0;
		this.coordoMouse[0] = event.clientX;
		this.coordoMouse[1] = event.clientY;
	}
};


//==============================================================================
/**
 *	Move the mouse.
 *	@param {WindowEvent} event - event captured by the window.
 *	@param {Facet} face - face overflown by the mouse.
 *	@return {void}
 */
ControllerExtrusion.prototype.mouseMouv = function (event, face) {
	//console.log ("ControllerExtrusion.mouseMouv");
	if (typeof event != "object") {
		console.error ("ERROR - ControllerExtrusion.mouseMouv : bad type of" 
				+ " parameter");
	}
	// --------------------------------------
	var model = this.frame.getCurentModel();
	if (this.actif && model != null && this.mouseLeft) {
		var distance = Math.abs(this.coordoMouse[0]-event.clientX)
				+ Math.abs(this.coordoMouse[1]-event.clientY);
		distance /= this.frame.canvas.height;
		distance *= 25;
		distance = Math.round(distance);
		if (this.possif) {
			if (this.nbExtrud != distance) {
				this.nbExtrud = distance;
				this.kernelextr.PreExtrusion(model,
						this.modelIntern.getModelController(), this.nbExtrud);
				this.modelIntern.positive = this.nbExtrud>0;
				model.alert (new Signal (SignalEnum.MODEL_EXTRUSION));
			}
		} 
		else {
			if (this.nbExtrud != -distance) {
				this.nbExtrud = -distance;
				this.kernelextr.PreExtrusion(model,
						this.modelIntern.getModelController(), this.nbExtrud);
				this.modelIntern.positive = this.nbExtrud>0;
				model.alert (new Signal (SignalEnum.MODEL_EXTRUSION));
			}
		}
	}
};


//==============================================================================
/**
 * Edit the feature activation status (to off).
 * @return {void}
 * sometimes performs processing in certain functionality
 */
ControllerExtrusion.prototype.disactivate = function () {
	//console.log ("ControllerExtrusion.disactivate");
	// --------------------------------------
	var model = this.frame.getCurentModel();
	if (this.actif && model != null) {
		var faces = [];
		var sign = new Signal (SignalEnum.ADD_REMOVE_CUBES);
		var size = this.modelIntern.getModelController().getSize();
		for (var x=0; x<size.m[0]; ++x) {
			for (var y=0; y<size.m[1]; ++y) {
				for (var z=0; z<size.m[2]; ++z) {
					if (this.modelIntern.getModelController().getCube(x,y,z)!=null) {
						sign.addCubes(new Facet (new Vector(x,y,z),DirectionEnum.NONE));
						faces.push(new Facet (new Vector(x,y,z),DirectionEnum.NONE));
					}
				}
			}
		}
		this.kernelextr.Extrusion(model,
				this.modelIntern.getModelController());
		if (faces.length>0) {
			var object = { model : model, facet : faces, add : this.possif };
			this.appli.addAction(new Action(this.getName(),object));
		}
		this.nbExtrud = 0;
		if (sign.getCubes().length >0) {
			model.alert (sign);
		}
	}
	this.setActif (false);
};


//==============================================================================
/**
 * Undo the extrusion action.
 * @param {Action} object - the undo/redo object.
 * @return {void}
 */
ControllerExtrusion.prototype.undo = function (object) {
	//console.log ("ControllerExtrusion.undo");
	if (object.model != null) {
		var sign = new Signal (SignalEnum.ADD_REMOVE_CUBES);
		for (var i = 0; i < object.facet.length; i++) {
			var coordo = object.facet[i].getCube();
			if (!object.add) {
				object.model.addCube(coordo.m[0], coordo.m[1], coordo.m[2]);
			}
			else {
				object.model.removeCube(coordo.m[0], coordo.m[1], coordo.m[2]);
			}
			sign.addCubes(object.facet[i]);
		}
		object.model.clearSelectFacet();
		object.model.setHoverFacet(null);
		object.model.alert (sign);
	}
};


//==============================================================================
/**
 * Redo the extrusion action, after the undo action.
 * @param {Action} object - the undo/redo object.
 * @return {void}
 */
ControllerExtrusion.prototype.redo = function (object) {
	//console.log ("ControllerExtrusion.redo");
	if (object.model != null) {
		var sign = new Signal (SignalEnum.ADD_REMOVE_CUBES);
		for (var i = 0; i < object.facet.length; i++) {
			var coordo = object.facet[i].getCube();
			if (object.add) {
				object.model.addCube(coordo.m[0], coordo.m[1], coordo.m[2]);
			}
			else {
				object.model.removeCube(coordo.m[0], coordo.m[1], coordo.m[2]);
			}
			sign.addCubes(object.facet[i]);
		}
		object.model.clearSelectFacet();
		object.model.setHoverFacet(null);
		object.model.alert (sign);
	}
};


