/// LICENCE ////////////////////////////////////////////////////////////////////


/* Copyright (juin 2015)
 * Auteur : BENOIST Thomas, BISUTTI Adrien, DESPLEBAIN Tanguy, LAURET Karl
 * 
 * benoist.thomas@hotmail.fr
 * biscui_86@hotmail.fr
 * tanguy.desplebain@gmail.com
 * lauret.karl@hotmail.fr
 * 
 * Ce logiciel est un programme informatique servant à modéliser des
 * structures 3D voxellisées.
 * 
 * Ce logiciel est régi par la licence CeCILL soumise au droit français et
 * respectant les principes de diffusion des logiciels libres. Vous pouvez
 * utiliser, modifier et/ou redistribuer ce programme sous les conditions
 * de la licence CeCILL telle que diffusée par le CEA, le CNRS et l'INRIA
 * sur le site "http://www.cecill.info".
 * 
 * En contrepartie de l'accessibilité au code source et des droits de copie,
 * de modification et de redistribution accordés par cette licence, il n'est
 * offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
 * seule une responsabilité restreinte pèse sur l'auteur du programme,  le
 * titulaire des droits patrimoniaux et les concédants successifs.
 * 
 * A cet égard  l'attention de l'utilisateur est attirée sur les risques
 * associés au chargement,  à l'utilisation,  à la modification et/ou au
 * développement et à la reproduction du logiciel par l'utilisateur étant
 * donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
 * manipuler et qui le réserve donc à des développeurs et des professionnels
 * avertis possédant  des  connaissances  informatiques approfondies.  Les
 * utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
 * logiciel à leurs besoins dans des conditions permettant d'assurer la
 * sécurité de leurs systèmes et ou de leurs données et, plus généralement,
 * à l'utiliser et l'exploiter dans les mêmes conditions de sécurité.
 * 
 * Le fait que vous puissiez accéder à cet en-tête signifie que vous avez
 * pris connaissance de la licence CeCILL, et que vous en avez accepté les
 * termes.
 */

/// INDEX //////////////////////////////////////////////////////////////////////


/* kernel : KernelHover
 * face : boolean
 * 
 * constructor (frame : Frame, name : String)
 * 
 * mouseMouv (event : WindowEvent, face : Facet) :void
 * isFace () : boolean
 * setFace (bool : boolean) : void
 */

/// CODE ///////////////////////////////////////////////////////////////////////



ControllerHover.prototype = new Controller ();
ControllerHover.prototype.constructor = ControllerHover;

/**
 * @constructor
 * @param {Frame} frame - The frame associated with the controller.
 * @param {String} name - The name of the controller.
 */
function ControllerHover (frame, name) {
	//console.log ("ControllerHover.constructor");
	// --------------------------------------
	Controller.call (this, frame, name);
	
	/**
	 * {KernelHover} the kernel.
	 */
	this.kernel = new KernelHover();
	
	/**
	 * {boolean} true for facet, false for cube.
	 */
	this.face = true;
};


//==============================================================================
/**
 * Move the mouse.
 * @param {WindowEvent} event - event captured by the window.
 * @param {Facet} face - the pointed facet.
 * @return {void}
 */
ControllerHover.prototype.mouseMouv = function (event, face) {
	//console.log ("ControllerHover.mouseMouv");
	if (typeof event != "object") {
		console.error ("ERROR - ControllerHover.mouseMouv : bad type of" 
				+ " parameter");
	}
	// --------------------------------------
	var model = this.frame.getCurentModel();
	if (this.actif && model != null) {
		var modif;
		if (this.face) {
			modif = this.kernel.hover(model, face);
		} 
		else {
			if (face!=null) {
				modif = this.kernel.hover(model, new Facet (
						face.getCube(), DirectionEnum.ALL));
			} 
			else {
				modif = this.kernel.hover(model, null);
			}
		}
		if (modif) {
			model.alert (new Signal (SignalEnum.HOVER_CHANGE));
		}
	}
};


//==============================================================================
/**
 * @return {boolean} true for facet, false for cube.
 */
ControllerHover.prototype.isFace = function () {
	//console.log ("ControllerHover.isFace");
	// --------------------------------------
	return this.face;
};


//==============================================================================
/**
 * @param {boolean} bool - true for facet, false for cube.
 * @return {void}
 */
ControllerHover.prototype.setFace = function (bool) {
	//console.log ("ControllerHover.isFace");
	if (typeof bool != "boolean") {
		console.error ("ERROR - ControllerHover.setFace : bad type of "
			+ "parameter");
	}
	// --------------------------------------
	this.face = bool;
	var model = this.frame.getCurentModel();
	if (model != null) {
		if (this.face) {
			this.kernel.face (model);
		}
		else {
			this.kernel.cube (model);
		}
	}
};


