/// LICENCE ////////////////////////////////////////////////////////////////////

/* Copyright (juin 2015)
 * Auteur : BENOIST Thomas, BISUTTI Adrien, DESPLEBAIN Tanguy, LAURET Karl
 * 
 * benoist.thomas@hotmail.fr
 * biscui_86@hotmail.fr
 * tanguy.desplebain@gmail.com
 * lauret.karl@hotmail.fr
 * 
 * Ce logiciel est un programme informatique servant à modéliser des
 * structures 3D voxellisées.
 * 
 * Ce logiciel est régi par la licence CeCILL soumise au droit français et
 * respectant les principes de diffusion des logiciels libres. Vous pouvez
 * utiliser, modifier et/ou redistribuer ce programme sous les conditions
 * de la licence CeCILL telle que diffusée par le CEA, le CNRS et l'INRIA
 * sur le site "http://www.cecill.info".
 * 
 * En contrepartie de l'accessibilité au code source et des droits de copie,
 * de modification et de redistribution accordés par cette licence, il n'est
 * offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
 * seule une responsabilité restreinte pèse sur l'auteur du programme,  le
 * titulaire des droits patrimoniaux et les concédants successifs.
 * 
 * A cet égard  l'attention de l'utilisateur est attirée sur les risques
 * associés au chargement,  à l'utilisation,  à la modification et/ou au
 * développement et à la reproduction du logiciel par l'utilisateur étant
 * donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
 * manipuler et qui le réserve donc à des développeurs et des professionnels
 * avertis possédant  des  connaissances  informatiques approfondies.  Les
 * utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
 * logiciel à leurs besoins dans des conditions permettant d'assurer la
 * sécurité de leurs systèmes et ou de leurs données et, plus généralement,
 * à l'utiliser et l'exploiter dans les mêmes conditions de sécurité.
 * 
 * Le fait que vous puissiez accéder à cet en-tête signifie que vous avez
 * pris connaissance de la licence CeCILL, et que vous en avez accepté les
 * termes.
 */

/// INDEX //////////////////////////////////////////////////////////////////////


/* kernel : KernelRotate
 * 
 * ControllerRotate (frame : Frame, name : string, application : Application)
 * 
 * pressKey (event : WindowEvent) : void
 * rotate (axis : AxisEnum,
 *         angle : int,
 *         model : ModelController,
 *         undo : boolean) : void
 * undo (object : Action) : void
 * redo (object : Action) : void
 */

/// CODE ///////////////////////////////////////////////////////////////////////



ControllerRotate.prototype = new Controller ();
ControllerRotate.prototype.constructor = ControllerRotate;

/**
 * @constructor
 * @param {Frame} frame - The frame associated with the controller
 * @param {String} name - The name of the controller
 * @param {Application} application - the application
 */
function ControllerRotate(frame, name, application) {
//	console.log ("ControllerRotate.constructor");
	// --------------------------------------
	Controller.call (this, frame, name, application);
	
	/**
	 * {KernelRotate} the main kernel.
	 */
	this.kernel = new KernelRotate();
};


//==============================================================================
/**
 * Button of the keyboard has been activated
 * @param {WindowEvent} event - event captured by the window
 * @return {void}
 */
ControllerRotate.prototype.pressKey = function (event) {
//	console.log ("ControllerRotate.pressKey actif : " + this.actif);
	if (typeof event != "object") {
		console.error ("ERROR - ControllerRotate.pressKey : bad type of " + 
			"parameter");
	}
	// --------------------------------------
	var model = this.frame.getCurentModel();
	if (this.actif && model != null) {
		if (event.key == '6' || event.key == 'Right' 
				|| event.key == "ArrowRight") {
			this.rotate (AxisEnum.Z, 90, model);
		}
		else if (event.key == '4' || event.key == 'Left' 
				|| event.key == "ArrowLeft") {
			this.rotate (AxisEnum.Z, 270, model);
		}
		else if (event.key == '8' || event.key == 'Up' 
				|| event.key == "ArrowUp") {
			this.rotate (AxisEnum.X, 90, model);
		}
		else if (event.key == '2' || event.key == 'Down' 
				|| event.key == "ArrowDown") {
			this.rotate (AxisEnum.X, 270, model);
		}
		else if (event.key == '3' || event.key == 'PageDown') {
			this.rotate (AxisEnum.Y, 90, model);
		}
		else if (event.key == '9' || event.key == 'PageUp') {
			this.rotate (AxisEnum.Y, 270, model);
		}
	}
};


//==============================================================================
/**
 * Rotate around an axis by an angle.
 * @param {AxisEnum} axis - the axis.
 * @param {int} angle - the angle of rotation (90°, 180° or 270°).
 * @param {ModelController} model - the model has rotate.
 * @param {boolean} undo - save the rotation in the undo (false in function
 * redo or undo).
 * @return {void}
 */
ControllerRotate.prototype.rotate = function (axis, angle, model, undo) {
//	console.log ("ControllerRotate.rotate");
	if (typeof (model) == "undefined") 
		model = this.frame.getCurentModel();
	
	switch (axis) {
	case AxisEnum.X :
		this.kernel.rotateX (model, angle);
		break;
	
	case AxisEnum.Y :
		this.kernel.rotateY (model, angle);
		break;
	
	case AxisEnum.Z :
		this.kernel.rotateZ (model, angle);
		break;
	}
	if (typeof (undo) == "undefined" || undo) {
		var object = {model : model, angle : angle, axis : axis};
		this.appli.addAction (new Action (this.getName(), object));
	}
	model.alert (new Signal (SignalEnum.ADD_REMOVE_CUBES));
};


//==============================================================================
/**
 * Undo the rotate action.
 * @param {Action} object - the undo/redo object.
 * @return {void}
 */
ControllerRotate.prototype.undo = function (object) {
//	console.log ("ControllerRotate.undo");
	if (object.model != null) {
		this.rotate (object.axis, 360 - object.angle, object.model, false);
	}
};


//==============================================================================
/**
 * Redo the rotate action, after the undo action.
 * @param {Action} object - the undo/redo object.
 * @return {void}
 */
ControllerRotate.prototype.redo = function (object) {
//	console.log ("ControllerRotate.redo");
	if (object.model != null) {
		this.rotate (object.axis, object.angle, object.model, false);
	}
};


