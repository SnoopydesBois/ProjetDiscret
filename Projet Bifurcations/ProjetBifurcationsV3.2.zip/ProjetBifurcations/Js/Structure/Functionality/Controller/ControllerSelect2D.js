/// LICENCE ////////////////////////////////////////////////////////////////////

/* Copyright (juin 2015)
 * Auteur : BENOIST Thomas, BISUTTI Adrien, DESPLEBAIN Tanguy, LAURET Karl
 * 
 * benoist.thomas@hotmail.fr
 * biscui_86@hotmail.fr
 * tanguy.desplebain@gmail.com
 * lauret.karl@hotmail.fr
 * 
 * Ce logiciel est un programme informatique servant à modéliser des
 * structures 3D voxellisées.
 * 
 * Ce logiciel est régi par la licence CeCILL soumise au droit français et
 * respectant les principes de diffusion des logiciels libres. Vous pouvez
 * utiliser, modifier et/ou redistribuer ce programme sous les conditions
 * de la licence CeCILL telle que diffusée par le CEA, le CNRS et l'INRIA
 * sur le site "http://www.cecill.info".
 * 
 * En contrepartie de l'accessibilité au code source et des droits de copie,
 * de modification et de redistribution accordés par cette licence, il n'est
 * offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
 * seule une responsabilité restreinte pèse sur l'auteur du programme,  le
 * titulaire des droits patrimoniaux et les concédants successifs.
 * 
 * A cet égard  l'attention de l'utilisateur est attirée sur les risques
 * associés au chargement,  à l'utilisation,  à la modification et/ou au
 * développement et à la reproduction du logiciel par l'utilisateur étant
 * donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
 * manipuler et qui le réserve donc à des développeurs et des professionnels
 * avertis possédant  des  connaissances  informatiques approfondies.  Les
 * utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
 * logiciel à leurs besoins dans des conditions permettant d'assurer la
 * sécurité de leurs systèmes et ou de leurs données et, plus généralement,
 * à l'utiliser et l'exploiter dans les mêmes conditions de sécurité.
 * 
 * Le fait que vous puissiez accéder à cet en-tête signifie que vous avez
 * pris connaissance de la licence CeCILL, et que vous en avez accepté les
 * termes.
 */

/// INDEX //////////////////////////////////////////////////////////////////////


/* kernel : KernelSelect2D
 * kernelRemove : KernelRemove
 * kernelCopy : KernelCopy
 * isDown : boolean
 * lastFaceOnMouveSelected : Facet
 * 
 * constructor (frame : Frame, name : string, application : Application)
 * 
 * mouseDown (event : WindowEvent, face : Facet) : void
 * mouseUp (event : WindowEvent, face : Facet) : void
 * mouseMouv (event : WindowEvent, face : Facet) : void
 * pressKey (event : WindowEvent) : void
 * select (event : WindowEvent, face : Facet) : void
 * selectSlice (axis : AxisEnum, nb : int, event : WindowEvent) : void
 * undo (object : Action) : void
 * redo (object : Action) : void
 */ 

/// CODE ///////////////////////////////////////////////////////////////////////



ControllerSelect2D.prototype = new Controller ();
ControllerSelect2D.prototype.constructor = ControllerSelect2D;

/**
 * @constructor
 * @param {Frame} frame - The frame associated with the controller.
 * @param {String} name - The name of the controller.
 * @param {Application} application - the application.
 */
function ControllerSelect2D (frame, name, application) {
//	console.log ("ControllerSelect2D.constructor");
	Controller.call (this,frame, name, application);
	
	/**
	 * {KernelSelect2D} the main kernel.
	 */
	this.kernel = new KernelSelect2D();
	
	/**
	 * {KernelRemove} the kernel for cubes deletion.
	 */
	this.kernelRemove = new KernelRemove();
	
	/**
	 * {KernelCopy} the kernel to copy cubes.
	 */
	this.kernelCopy = new KernelCopy();
	
	/**
	 * {boolean} True while the mouse is suposed to be pressed, false otherwise.
	 */
	this.isDown = false;
	
	/**
	 * {Facet} 
	 */
	this.lastFaceOnMouveSelected = null;
}


//==============================================================================
/**
 * Down a button of the mouse.
 * @param {WindowEvent} event - event captured by the window.
 * @param {Facet} face - face overflown by the mouse.
 * @return {void}
 */
ControllerSelect2D.prototype.mouseDown = function (event, face) {
	this.isDown = true;
	this.lastFaceOnMouveSelected = face;
	this.select(event, face);
};


//==============================================================================
/**
 * Release the mouse button.
 * @param {WindowEvent} event - event captured by the window.
 * @param {Facet} face - face overflown by the mouse.
 * @return {void}
 */
ControllerSelect2D.prototype.mouseUp = function (event, face) {
	//console.log ("ControllerSelect2D.mouseUp");
	if (typeof event != "object") {
		console.error ("ERROR - Controller.mouseUp : bad type of parameter");
	}
	// --------------------------------------

	this.isDown = false;
	this.lastFaceOnMouveSelected = null;
};


//==============================================================================
/**
 * Move the mouse.
 * @param {WindowEvent} event - event captured by the window.
 * @param {Facet} face - face overflown by the mouse.
 * @return {void}
 */
ControllerSelect2D.prototype.mouseMouv = function (event, face) {
//	console.log ("ControllerSelect2D.mouseMouv");
	if (typeof event != "object") {
		console.error ("ERROR - Controller.mouseMouv : bad type of parameter");
	}
	// --------------------------------------
	if (this.isDown &&
			(this.lastFaceOnMouveSelected == null 
				|| !this.lastFaceOnMouveSelected.egale(face))) {
		this.lastFaceOnMouveSelected = face;
		this.select(event, face);
	}
};


//==============================================================================
/**
 * Button of the keyboard has been activated.
 * @param {WindowEvent} event - event captured by the window.
 * @return {void}
 */
ControllerSelect2D.prototype.pressKey = function (event) {
//	console.log ("ControllerSelect2D.pressKey");
	if (typeof event != "object") {
		console.error ("ERROR - ControllerSelect2D.pressKey : bad type of "
				+ "parameter");
	}
	// --------------------------------------
	var model = this.frame.getCurentModel();
	if (this.actif && model!=null) {
		if (event.keyCode == 8) {
			var sign = new Signal (SignalEnum.ADD_REMOVE_CUBES);
			var faces = [];
			for (var i = 0; i < model.getNbSelectedFacet(); ++i) {
				sign.addCubes(model.getSelectedFacet(i));
				faces.push(model.getSelectedFacet(i));
			}
			if (faces.length > 0) {
				var object = { model : model, facet : faces};
				this.appli.addAction(new Action(this.getName(),object));
			}
			this.kernelRemove.RemoveCubeSelected(model);
			model.alert (sign);
		}
		else if (event.key == 'm') {
			this.kernelCopy.CopyCubeSelected(model);
		}
	}
};


//==============================================================================
/**
 * Action common to multiple event.
 * @param {WindowEvent} event - event captured by the window.
 * @param {Facet} face - face overflown by the mouse.
 * @return {void}
 */
ControllerSelect2D.prototype.select = function (event, face) {
//	console.log ("ControllerSelect2D.select");
	var model = this.frame.getCurentModel();
	if (this.actif && model != null) {
		if (model.getModel().getCube(face.getCube().m[0],
				face.getCube().m[1],face.getCube().m[2])) {
			this.kernel.select(model, face, event.ctrlKey||event.metaKey,
					this.frame);
			model.alert (new Signal (SignalEnum.SELECT_CHANGE));
		}
	}
};


//==============================================================================
/**
 * Select all cube in a slices.
 * @param {AxisEnum} axis - the orthogonal axis.to the slice.
 * @param {int} nb - number of the slice.
 * @param {WindowEvent} event - event captured by the window.
 * @return {void}
 */
ControllerSelect2D.prototype.selectSlice = function (axis, nb, event) {
//	console.log ("ControllerSelect2D.selectSlice");
	var model = this.frame.getCurentModel();
	if (this.actif && model != null) {
		if (!event.ctrlKey&&!event.metaKey) {
			model.clearSelectFacet();
		}
		switch (axis) {
		case AxisEnum.X :
			for (var i=0; i<model.getSize().m[1]; ++i) {
				for (var j=0; j<model.getSize().m[2]; ++j) {
					if (model.getModel().getCube(nb,i,j) != null) {
						this.kernel.select(model,
								new Facet(new Vector(nb,i,j),
								DirectionEnum.ALL), true, this.frame);
					}
				}
			}
			break;
		case AxisEnum.Y :
			for (var i=0; i<model.getSize().m[0]; ++i) {
				for (var j=0; j<model.getSize().m[2]; ++j) {
					if (model.getModel().getCube(i,nb,j) != null) {
						this.kernel.select(model, 
								new Facet(new Vector(i,nb,j),
								DirectionEnum.ALL), true, this.frame);
					}
				}
			}
			break;
		case AxisEnum.Z :
			for (var i = 0; i < model.getSize().m[0]; ++i) {
				for (var j = 0; j < model.getSize().m[1]; ++j) {
					if (model.getModel().getCube(
							i,j,nb) != null) {
						this.kernel.select(model,
								new Facet(new Vector(i, j, nb),
								DirectionEnum.ALL), true, this.frame);
					}
				}
			}
			break;
		}
		model.alert (new Signal (SignalEnum.SELECT_CHANGE));
	}
};


//==============================================================================
/**
 * Undo the remove slice action.
 * @param {Action} object - the undo/redo object.
 * @return {void}
 */
ControllerSelect2D.prototype.undo = function (object) {
//	console.log ("ControllerSelect2D.undo");
	if (object.model != null) {
		var sign = new Signal (SignalEnum.ADD_REMOVE_CUBES);
		for (var i = 0; i < object.facet.length; i++) {
			var coordo = object.facet[i].getCube();
			object.model.addCube(coordo.m[0],coordo.m[1],coordo.m[2]);
			sign.addCubes(object.facet[i]);
		}
		object.model.clearSelectFacet();
		object.model.setHoverFacet(null);
		object.model.alert (sign);
	}
};


//==============================================================================
/**
 * Redo the remove slice action, after the undo action.
 * @param {Action} object - the undo/redo object.
 * @return {void}
 */
ControllerSelect2D.prototype.redo = function (object) {
//	console.log ("ControllerSelect2D.redo");
	if (object.model != null) {
		var sign = new Signal (SignalEnum.ADD_REMOVE_CUBES);
		for (var i = 0; i < object.facet.length; i++) {
			var coordo = object.facet[i].getCube();
			object.model.removeCube(coordo.m[0],coordo.m[1],coordo.m[2]);
			sign.addCubes(object.facet[i]);
		}
		object.model.clearSelectFacet();
		object.model.setHoverFacet(null);
		object.model.alert (sign);
	}
};


