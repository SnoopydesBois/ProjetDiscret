/// LICENCE ////////////////////////////////////////////////////////////////////

/* Copyright (juin 2015)
 * Auteur : BENOIST Thomas, BISUTTI Adrien, DESPLEBAIN Tanguy, LAURET Karl
 * 
 * benoist.thomas@hotmail.fr
 * biscui_86@hotmail.fr
 * tanguy.desplebain@gmail.com
 * lauret.karl@hotmail.fr
 * 
 * Ce logiciel est un programme informatique servant à modéliser des
 * structures 3D voxellisées.
 * 
 * Ce logiciel est régi par la licence CeCILL soumise au droit français et
 * respectant les principes de diffusion des logiciels libres. Vous pouvez
 * utiliser, modifier et/ou redistribuer ce programme sous les conditions
 * de la licence CeCILL telle que diffusée par le CEA, le CNRS et l'INRIA
 * sur le site "http://www.cecill.info".
 * 
 * En contrepartie de l'accessibilité au code source et des droits de copie,
 * de modification et de redistribution accordés par cette licence, il n'est
 * offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
 * seule une responsabilité restreinte pèse sur l'auteur du programme,  le
 * titulaire des droits patrimoniaux et les concédants successifs.
 * 
 * A cet égard  l'attention de l'utilisateur est attirée sur les risques
 * associés au chargement,  à l'utilisation,  à la modification et/ou au
 * développement et à la reproduction du logiciel par l'utilisateur étant
 * donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
 * manipuler et qui le réserve donc à des développeurs et des professionnels
 * avertis possédant  des  connaissances  informatiques approfondies.  Les
 * utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
 * logiciel à leurs besoins dans des conditions permettant d'assurer la
 * sécurité de leurs systèmes et ou de leurs données et, plus généralement,
 * à l'utiliser et l'exploiter dans les mêmes conditions de sécurité.
 * 
 * Le fait que vous puissiez accéder à cet en-tête signifie que vous avez
 * pris connaissance de la licence CeCILL, et que vous en avez accepté les
 * termes.
 */

/// INDEX //////////////////////////////////////////////////////////////////////


/**
 * kernel : KernelTranslate
 * 
 * constructor (frame : Frame, name : string, application : Application)
 * 
 * pressKey (event : WindowEvent) : void
 * undo (object : Action) : void
 * redo (object : Action) : void
 */

/// CODE ///////////////////////////////////////////////////////////////////////

ControllerTranslate.prototype = new Controller ();
ControllerTranslate.prototype.constructor = ControllerTranslate;


/**
 * @constructor
 * @param {Frame} frame - The frame associated with the controller
 * @param {String} name - The name of the controller
 * @param {Application} application - the application
 */
function ControllerTranslate(frame, name, application) {
//	console.log ("ControllerTranslate.constructor");
	// --------------------------------------
	Controller.call (this, frame, name, application);
	
	/**
	 * {KernelTranslate} The main kernel.
	 */
	this.kernel = new KernelTranslate();
};


//==============================================================================
/**
 * Button of the keyboard has been activated
 * @param {WindowEvent} event - event captured by the window
 * @return {void}
 */
ControllerTranslate.prototype.pressKey = function (event) {
//	console.log ("ControllerTranslate.pressKey");
	if (typeof event != "object") {
		console.error ("ERROR - ControllerTranslate.pressKey : bad type of " 
			+ "parameter");
	}
	// --------------------------------------
	var model = this.frame.getCurentModel();
	if (this.actif && model != null) {
		if (event.key == 'Up' || event.key == "ArrowUp" || event.key == '8') {
			if (this.kernel.translate(model, DirectionEnum.BACK)) {
				var object = { model : model, axis : DirectionEnum.BACK};
				this.appli.addAction(new Action(this.getName(),object));
				model.alert (new Signal (SignalEnum.ADD_REMOVE_CUBES));
			}
		}
		else if (event.key == 'Down' || event.key == "ArrowDown"
				|| event.key == '2') {
			if (this.kernel.translate(model, DirectionEnum.FRONT)) {
				var object = { model : model, axis : DirectionEnum.FRONT};
				this.appli.addAction(new Action(this.getName(),object));
				model.alert (new Signal (SignalEnum.ADD_REMOVE_CUBES));
			}
		}
		else if (event.key == 'Left' || event.key == "ArrowLeft" 
				|| event.key == '4') {
			if (this.kernel.translate(model, DirectionEnum.LEFT)) {
				var object = { model : model, axis : DirectionEnum.LEFT};
				this.appli.addAction(new Action(this.getName(),object));
				model.alert (new Signal (SignalEnum.ADD_REMOVE_CUBES));
			}
		}
		else if (event.key == 'Right' || event.key == "ArrowRight" 
				|| event.key == '6') {
			if (this.kernel.translate(model, DirectionEnum.RIGHT)) {
				var object = { model : model, axis : DirectionEnum.RIGHT};
				this.appli.addAction(new Action(this.getName(),object));
				model.alert (new Signal (SignalEnum.ADD_REMOVE_CUBES));
			}
		}
		else if (event.key == 'PageUp' || event.key == '9') {
			if (this.kernel.translate(model, DirectionEnum.TOP)) {
				var object = { model : model, axis : DirectionEnum.TOP};
				this.appli.addAction(new Action(this.getName(),object));
				model.alert (new Signal (SignalEnum.ADD_REMOVE_CUBES));
			}
		}
		else if (event.key == 'PageDown' || event.key == '3') {
			if (this.kernel.translate(model, DirectionEnum.BOTTOM)) {
				var object = { model : model, axis : DirectionEnum.BOTTOM};
				this.appli.addAction(new Action(this.getName(),object));
				model.alert (new Signal (SignalEnum.ADD_REMOVE_CUBES));
			}
		}
	}
};


//==============================================================================
/**
 * Undo the translate action
 * @param {Action} object - the undo/redo object
 * @return {void}
 */
ControllerTranslate.prototype.undo = function (object) {
//	console.log ("ControllerTranslate.undo");
	if (object.model != null) {
		if (this.kernel.translate(object.model, DirectionEnum.properties[object.axis].oppose)) {
			object.model.alert (new Signal (SignalEnum.ADD_REMOVE_CUBES));
		}
	}
};


//==============================================================================
/**
 * Redo the translate action, after the undo action
 * @param {Action} object - the undo/redo object
 * @return {void}
 */
ControllerTranslate.prototype.redo = function (object) {
//	console.log ("ControllerTranslate.redo");
	if (object.model != null) {
		if (this.kernel.translate(object.model, object.axis)) {
			object.model.alert (new Signal (SignalEnum.ADD_REMOVE_CUBES));
		}
	}
};


