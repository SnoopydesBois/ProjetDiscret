/// LICENCE ////////////////////////////////////////////////////////////////////


/* Copyright (juin 2015)
 * Auteur : BENOIST Thomas, BISUTTI Adrien, DESPLEBAIN Tanguy, LAURET Karl
 * 
 * benoist.thomas@hotmail.fr
 * biscui_86@hotmail.fr
 * tanguy.desplebain@gmail.com
 * lauret.karl@hotmail.fr
 * 
 * Ce logiciel est un programme informatique servant à modéliser des
 * structures 3D voxellisées.
 * 
 * Ce logiciel est régi par la licence CeCILL soumise au droit français et
 * respectant les principes de diffusion des logiciels libres. Vous pouvez
 * utiliser, modifier et/ou redistribuer ce programme sous les conditions
 * de la licence CeCILL telle que diffusée par le CEA, le CNRS et l'INRIA
 * sur le site "http://www.cecill.info".
 * 
 * En contrepartie de l'accessibilité au code source et des droits de copie,
 * de modification et de redistribution accordés par cette licence, il n'est
 * offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
 * seule une responsabilité restreinte pèse sur l'auteur du programme,  le
 * titulaire des droits patrimoniaux et les concédants successifs.
 * 
 * A cet égard  l'attention de l'utilisateur est attirée sur les risques
 * associés au chargement,  à l'utilisation,  à la modification et/ou au
 * développement et à la reproduction du logiciel par l'utilisateur étant
 * donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
 * manipuler et qui le réserve donc à des développeurs et des professionnels
 * avertis possédant  des  connaissances  informatiques approfondies.  Les
 * utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
 * logiciel à leurs besoins dans des conditions permettant d'assurer la
 * sécurité de leurs systèmes et ou de leurs données et, plus généralement,
 * à l'utiliser et l'exploiter dans les mêmes conditions de sécurité.
 * 
 * Le fait que vous puissiez accéder à cet en-tête signifie que vous avez
 * pris connaissance de la licence CeCILL, et que vous en avez accepté les
 * termes.
 */

/// INDEX //////////////////////////////////////////////////////////////////////


/* constructor ()
 * 
 * rotateX (modelContr : ModelController, degree : float) : void
 * rotateY (modelContr : ModelController, degree : float) : void
 * rotateZ (modelContr : ModelController, degree : float) : void
 * prepareMatBool (size : Vector) : boolean[][][]
 * remplieModel (size : Vector,
 *               modelContr : ModelController,
 *               tmp : boolean[][][]) : void
 */

/// CODE ///////////////////////////////////////////////////////////////////////



KernelRotate.prototype.constructor = KernelTranslate;

/**
 * @constructor Do nothing.
 */
function KernelRotate() {
//	console.log ("KernelRotate.constructor");
}


//==============================================================================
/**
 * @param {ModelController} modelContr - The ModelController of the model to 
 * modify
 * @param {float} degree - The number of degree to rotate around the x axis
 * @return {void}
 */
KernelRotate.prototype.rotateX = function (modelContr, degree) {
	//console.log ("KernelRotate.rotateX");
	// --------------------------------------
	modelContr.clearSelectFacet();
	modelContr.setHoverFacet(null);
	var size = modelContr.getModel().getSize();
	var tmp = this.prepareMatBool (size);
	for (var x = 0; x < size.m[0]; ++x) {
		for (var y = 0; y < size.m[1]; ++y) {
			for (var z = 0; z < size.m[2]; ++z) {
				var cube = modelContr.getModel().getCube (x,y,z);
				var coordo;
				switch (degree) {
					case 90 :
						coordo = new Vector (x, z, size.m[2] - 1 - y);
						break;
					case 180 :
						coordo = new Vector (x, size.m[1] - 1 - y,
							size.m[2] - 1 - z);
						break;
					case 270 :
						coordo = new Vector (x, size.m[1] - 1 - z, y);
						break;
					default :
						coordo = new Vector (x, y, z);
						break;
				}
				if (modelContr.getModel().isIn(
						coordo.m[0], coordo.m[1], coordo.m[2])) {
					tmp[coordo.m[0]][coordo.m[1]][coordo.m[2]] = (cube!=null);
				} 
				else if (cube != null) {
					// No rotation outside of the space.
					return; 
				}
			}
		}
	}
	this.remplieModel(size, modelContr, tmp);
};

//==============================================================================
/**
 * @param {ModelController} modelContr - The ModelController of the model to 
 * modify
 * @param {float} degree - The number of degree to rotate around the y axis
 * @return {void}
 */
KernelRotate.prototype.rotateY = function (modelContr, degree) {
	//console.log ("KernelRotate.rotateY");
	// --------------------------------------
	modelContr.clearSelectFacet();
	modelContr.setHoverFacet(null);
	var size = modelContr.getModel().getSize();
	var tmp = this.prepareMatBool (size);
	for (var x = 0; x < size.m[0]; ++x) {
		for (var y = 0; y < size.m[1]; ++y) {
			for (var z = 0; z < size.m[2]; ++z) {
				var cube = modelContr.getModel().getCube(x,y,z);
				var coordo;
				switch (degree) {
					case 90 :
						coordo = new Vector (z, y, size.m[2] - 1-x);
						break;
					case 180 :
						coordo = new Vector (size.m[0] - 1 - x, y,
							size.m[2] - 1 - z);
						break;
					case 270 :
						coordo = new Vector (size.m[0] - 1 - z, y, x);
						break;
					default :
						coordo = new Vector (x, y, z);
						break;
				}
				if (modelContr.getModel().isIn(
						coordo.m[0], coordo.m[1], coordo.m[2])) {
					tmp[coordo.m[0]][coordo.m[1]][coordo.m[2]] = (cube != null);
				} 
				else if (cube!=null) {
					 // No rotation outside of the space
					return;
				}
			}
		}
	}
	this.remplieModel(size, modelContr, tmp);
};


//==============================================================================
/**
 * @param {ModelController} modelContr - The ModelController of the model to 
 * modify.
 * @param {float} degree - The number of degree to rotate around the z axis.
 * @return {void}
 */
KernelRotate.prototype.rotateZ = function (modelContr, degree) {
	//console.log ("KernelRotate.rotateZ");
	// --------------------------------------
	modelContr.clearSelectFacet();
	modelContr.setHoverFacet(null);
	var size = modelContr.getModel().getSize();
	var tmp = this.prepareMatBool (size);
	for (var x = 0; x < size.m[0]; ++x) {
		for (var y = 0; y < size.m[1]; ++y) {
			for (var z = 0; z < size.m[2]; ++z) {
				var cube = modelContr.getModel().getCube (x, y, z);
				var coordo;
				switch (degree) {
					case 90 :
						coordo = new Vector (size.m[0] - 1 - y, x, z);
						break;
					case 180 :
						coordo = new Vector (size.m[0] - 1 - x,
							size.m[1] - 1 - y, z);
						break;
					case 270 :
						coordo = new Vector (y, size.m[1]-1-x, z);
						break;
					default :
						coordo = new Vector (x, y, z);
						break;
				}
				if (modelContr.getModel().isIn(
						coordo.m[0], coordo.m[1], coordo.m[2])) {
					tmp[coordo.m[0]][coordo.m[1]][coordo.m[2]] = (cube != null);
				} 
				else if (cube != null) {
					// No rotation outside the space
					return;
				}
			}
		}
	}
	this.remplieModel (size, modelContr, tmp);
};


//==============================================================================
/**
 * Create the matrix that will represent the model.
 * @param {Vector} size - The maximum length for each axis.
 * @return {boolean[][][]}
 */
KernelRotate.prototype.prepareMatBool = function (size) {
//	console.log ("KernelRotate.prepareMatBool");
	var tmp = new Array();
	for (var x = 0; x < size.m[0]; ++x) {
		tmp.push (new Array());
		for (var y = 0; y < size.m[1]; ++y) {
			tmp[x].push (new Array());
			for (var z = 0; z < size.m[2]; ++z) {
				tmp[x][y].push (false);
			}
		}
	}
	return tmp;
};


//==============================================================================
/**
 * Fill the model with cubes.
 * @param {Vector} size - the maximum length for each axis.
 * @param {ModelController} modelContr - the controller of the model to
 * modify.
 * @param {boolean[][][]} tmp - a matrix which describe the model after the
 * rotation.
 * @return {void}
 */
KernelRotate.prototype.remplieModel = function (size, modelContr, tmp) {
//	console.log ("KernelRotate.remplieModel");
	for (var x = 0; x < size.m[0]; ++x) {
		for (var y = 0; y < size.m[1]; ++y) {
			for (var z = 0; z < size.m[2]; ++z) {
				if (tmp[x][y][z])
					modelContr.getModel().addCube (x, y, z);
				else
					modelContr.getModel().removeCube (x, y, z);
			} // end for z
		} // end for y
	} // end for x
};


