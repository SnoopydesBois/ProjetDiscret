/// LICENCE ////////////////////////////////////////////////////////////////////

/* Copyright (juin 2015)
 * Auteur : BENOIST Thomas, BISUTTI Adrien, DESPLEBAIN Tanguy, LAURET Karl
 * 
 * benoist.thomas@hotmail.fr
 * biscui_86@hotmail.fr
 * tanguy.desplebain@gmail.com
 * lauret.karl@hotmail.fr
 * 
 * Ce logiciel est un programme informatique servant à modéliser des
 * structures 3D voxellisées.
 * 
 * Ce logiciel est régi par la licence CeCILL soumise au droit français et
 * respectant les principes de diffusion des logiciels libres. Vous pouvez
 * utiliser, modifier et/ou redistribuer ce programme sous les conditions
 * de la licence CeCILL telle que diffusée par le CEA, le CNRS et l'INRIA
 * sur le site "http://www.cecill.info".
 * 
 * En contrepartie de l'accessibilité au code source et des droits de copie,
 * de modification et de redistribution accordés par cette licence, il n'est
 * offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
 * seule une responsabilité restreinte pèse sur l'auteur du programme,  le
 * titulaire des droits patrimoniaux et les concédants successifs.
 * 
 * A cet égard  l'attention de l'utilisateur est attirée sur les risques
 * associés au chargement,  à l'utilisation,  à la modification et/ou au
 * développement et à la reproduction du logiciel par l'utilisateur étant
 * donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
 * manipuler et qui le réserve donc à des développeurs et des professionnels
 * avertis possédant  des  connaissances  informatiques approfondies.  Les
 * utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
 * logiciel à leurs besoins dans des conditions permettant d'assurer la
 * sécurité de leurs systèmes et ou de leurs données et, plus généralement,
 * à l'utiliser et l'exploiter dans les mêmes conditions de sécurité.
 * 
 * Le fait que vous puissiez accéder à cet en-tête signifie que vous avez
 * pris connaissance de la licence CeCILL, et que vous en avez accepté les
 * termes.
 */

/// INDEX //////////////////////////////////////////////////////////////////////


/* constructor ()
 * 
 * select (modelContr : ModelController,
 *         face : Facet,
 *         multiple : boolean,
 *         frame2D : Frame2D) : void
 */

/// CODE ///////////////////////////////////////////////////////////////////////



KernelSelect2D.prototype.constructor = KernelSelect2D;

/**
 * @constructor
 */
function KernelSelect2D() {
//	console.log ("KernelSelect.constructor");
};


//==============================================================================
/**
 * Select in a model face or cube.
 * @param {ModelController} modelContr - the current model.
 * @param {Facet} face - the current face on the model.
 * @param {boolean} multiple - is it a multiple selection.
 * @param {Frame2D} frame2D - the frame which must be update.
 * @return {void}
 */
KernelSelect2D.prototype.select = function (modelContr, face, multiple, frame2D)
{
//	console.log ("KernelSelect2D.select");
	if (multiple) {
		if (modelContr.isSelectedFacet(face)) {
			modelContr.removeSelectedFacet(face);
		} 
		else {
			modelContr.addSelectedFacet(face);
		}
	} 
	else {
		for (var i = modelContr.getNbSelectedFacet() - 1; i >= 0; --i) {
			var tmpFace = modelContr.getSelectedFacet(i);
			modelContr.removeSelectedFacet(tmpFace);
			frame2D.update(tmpFace.getCube().m[0],
				tmpFace.getCube().m[1],
				tmpFace.getCube().m[2]);
		}
		modelContr.setSelectedFacet (face);
	}
};


