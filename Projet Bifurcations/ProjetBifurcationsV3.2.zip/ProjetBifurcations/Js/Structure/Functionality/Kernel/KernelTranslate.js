/// LICENCE ////////////////////////////////////////////////////////////////////

/*
 * Copyright BENOIST Thomas, BISUTTI Adrien, DESPLEBAIN Tanguy,
 * LAURET Karl, (juin 2015) 
 *
 * benoist.thomas@hotmail.fr
 * biscui_86@hotmail.fr
 * tanguy.desplebain@gmail.com
 * lauret.karl@hotmail.fr
 *
 * Ce logiciel est un programme informatique servant à modéliser des
 * structures 3D voxellisées. 
 *
 * Ce logiciel est régi par la licence CeCILL soumise au droit français et
 * respectant les principes de diffusion des logiciels libres. Vous pouvez
 * utiliser, modifier et/ou redistribuer ce programme sous les conditions
 * de la licence CeCILL telle que diffusée par le CEA, le CNRS et l'INRIA 
 * sur le site "http://www.cecill.info".
 *
 * En contrepartie de l'accessibilité au code source et des droits de copie,
 * de modification et de redistribution accordés par cette licence, il n'est
 * offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
 * seule une responsabilité restreinte pèse sur l'auteur du programme,  le
 * titulaire des droits patrimoniaux et les concédants successifs.
 *
 * A cet égard  l'attention de l'utilisateur est attirée sur les risques
 * associés au chargement,  à l'utilisation,  à la modification et/ou au
 * développement et à la reproduction du logiciel par l'utilisateur étant 
 * donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
 * manipuler et qui le réserve donc à des développeurs et des professionnels
 * avertis possédant  des  connaissances  informatiques approfondies.  Les
 * utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
 * logiciel à leurs besoins dans des conditions permettant d'assurer la
 * sécurité de leurs systèmes et ou de leurs données et, plus généralement, 
 * à l'utiliser et l'exploiter dans les mêmes conditions de sécurité. 
 *
 * Le fait que vous puissiez accéder à cet en-tête signifie que vous avez 
 * pris connaissance de la licence CeCILL, et que vous en avez accepté les
 * termes
 */

/// INDEX //////////////////////////////////////////////////////////////////////


/* constructor ()
 * 
 * translate (modelContr : ModelController, direction : DirectionEnum) : boolean
 */

/// CODE ///////////////////////////////////////////////////////////////////////



KernelTranslate.prototype.constructor = KernelTranslate;

/**
 * @constructor Do nothing.
 */
function KernelTranslate () {
//	console.log ("KernelTranslate.constructor");
}


//==============================================================================
/**
 * Translate a model in a direction.
 * @param {ModelController} modelContr - the model.
 * @param {DirectionEnum} direction - the direction.
 * @return {boolean} true if the translation have been sucessfull, false
 * otherwise.
 */
KernelTranslate.prototype.translate = function (modelContr, direction) {
//	console.log ("KernelTranslate.translate");
	// --------------------------------------
	appli.showMessage ("Translation en cours");
	modelContr.clearSelectFacet();
	modelContr.setHoverFacet(null);
	var size = modelContr.getModel().getSize();
	var tmp = new Array ();
	for (var x = 0; x < size.m[0]; ++x) {
		tmp.push (new Array ());
		for (var y = 0; y < size.m[1]; ++y) {
			tmp[x].push (new Array ());
			for (var z = 0; z < size.m[2]; ++z) {
				tmp[x][y].push (false);
			}
		}
	}
	for (var x = 0; x < size.m[0]; ++x) {
		for (var y = 0; y < size.m[1]; ++y) {
			for (var z = 0; z < size.m[2]; ++z) {
				var cube = modelContr.getModel().getCube (x, y, z);
				var coordo = new Vector (
						x + DirectionEnum.properties[direction].x,
						y + DirectionEnum.properties[direction].y,
						z + DirectionEnum.properties[direction].z);
				if (modelContr.getModel().isIn(
						coordo.m[0], coordo.m[1], coordo.m[2])) {
					tmp[coordo.m[0]][coordo.m[1]][coordo.m[2]] = (cube != null);
				} 
				else if (cube != null) {
					// No translation outside of the space
					appli.alertMessage ("Pas de Translation en dehors " 
							+ " de l'espace", 10000);
					return false;
				} // end if
			} // end for z
		} // end for y
	} // end for x
	for (var x = 0; x < size.m[0]; ++x) {
		for (var y = 0; y < size.m[1]; ++y) {
			for (var z = 0; z < size.m[2]; ++z) {
				if (tmp[x][y][z]) {
					modelContr.getModel().addCube (x, y, z);
				} 
				else {
					modelContr.getModel().removeCube (x, y, z);
				} // end if
			} // end for z
		} // end for y
	} // end for x
	appli.showMessage ("Translation effectuée", 10000);
	return true;
};


