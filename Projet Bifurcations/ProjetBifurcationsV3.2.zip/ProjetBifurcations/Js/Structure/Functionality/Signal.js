/// LICENCE ////////////////////////////////////////////////////////////////////


/* Copyright (juin 2015)
 * Auteur : BENOIST Thomas, BISUTTI Adrien, DESPLEBAIN Tanguy, LAURET Karl
 * 
 * benoist.thomas@hotmail.fr
 * biscui_86@hotmail.fr
 * tanguy.desplebain@gmail.com
 * lauret.karl@hotmail.fr
 * 
 * Ce logiciel est un programme informatique servant à modéliser des
 * structures 3D voxellisées.
 * 
 * Ce logiciel est régi par la licence CeCILL soumise au droit français et
 * respectant les principes de diffusion des logiciels libres. Vous pouvez
 * utiliser, modifier et/ou redistribuer ce programme sous les conditions
 * de la licence CeCILL telle que diffusée par le CEA, le CNRS et l'INRIA
 * sur le site "http://www.cecill.info".
 * 
 * En contrepartie de l'accessibilité au code source et des droits de copie,
 * de modification et de redistribution accordés par cette licence, il n'est
 * offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
 * seule une responsabilité restreinte pèse sur l'auteur du programme,  le
 * titulaire des droits patrimoniaux et les concédants successifs.
 * 
 * A cet égard  l'attention de l'utilisateur est attirée sur les risques
 * associés au chargement,  à l'utilisation,  à la modification et/ou au
 * développement et à la reproduction du logiciel par l'utilisateur étant
 * donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
 * manipuler et qui le réserve donc à des développeurs et des professionnels
 * avertis possédant  des  connaissances  informatiques approfondies.  Les
 * utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
 * logiciel à leurs besoins dans des conditions permettant d'assurer la
 * sécurité de leurs systèmes et ou de leurs données et, plus généralement,
 * à l'utiliser et l'exploiter dans les mêmes conditions de sécurité.
 * 
 * Le fait que vous puissiez accéder à cet en-tête signifie que vous avez
 * pris connaissance de la licence CeCILL, et que vous en avez accepté les
 * termes.
 */

/// INDEX //////////////////////////////////////////////////////////////////////


/* type : SignalEnum
 * axis : AxisEnum
 * offset : Number
 * cubes : Facet[]
 * 
 * Signal (type : SignalEnum, info : mixed)
 * getType () : SignalEnum
 * getAxis () : AxisEnum
 * setAxis (axis : AxisEnum) : void
 * getOffset () : Number
 * setOffset (offset : Number) : void
 * getCubes () : Facet[]
 * addCubes (cubes : Facet) : void
 */

/// CODE ///////////////////////////////////////////////////////////////////////



/**
 * A signal is a polymorphic object. Depending on the type of the message we
 * want to send, the class create the objects/assessors/mutators necessary to
 * add information.
 */


	  ///////////////////
	 /// Constructor ///
	///////////////////


Signal.prototype.constructor = Signal;


/**
 * @constructor
 * @param {SignalEnum} type - the signal type.
 * @param {mixed} info - an information.
 */
function Signal (type, info) {
//	console.log ("Signal.constructor");
	if (type == undefined) {
		console.error ("Signal.constructor : You MUST specify a type !");
	}
	
	/**
	 * {SignalEnum} The type of the signal.
	 */
	this.type = type;
	
	switch (this.type) {
	case SignalEnum.HOVER_CHANGE :
		break;
		
	case SignalEnum.SELECT_CHANGE :
		break;
		
	case SignalEnum.HIGHLIGHT_CHANGE :
		/**
		 * {AxisEnum} The perpendicular axis to the current slice plan (X by 
		 * default).
		 */
		this.axis = info || AxisEnum.X;
		
		/**
		 * {Number} The number of the slice.
		 */
		this.offset;
		break;
		
	case SignalEnum.ADD_REMOVE_CUBES :
		/**
		 * {Facet[]} List of added/removed cubes.
		 */
		this.cubes = [];
		if (info != undefined && info != null)
			this.cubes.push (info);
		break;
		
	case SignalEnum.LIST_MODEL_2D_CHANGE :
	case SignalEnum.LIST_MODEL_3D_CHANGE :
	case SignalEnum.MODEL_EXTRUSION :
		break;
	
	default :
		console.error ("Signal.constructor : invalid signal type");
		break;
	}
}


	  //////////////////////////////
	 /// Accessors and Mutators ///
	//////////////////////////////


/**
 * @return {SignalEnum} the signal type.
 */
Signal.prototype.getType = function () {
//	console.log ("Signal.getType");
	return this.type;
};


//==============================================================================
/**
 * For HIGHLIGHT_CHANGE.
 * @return {AxisEnum} The axis perpendicular to the current slice plan.
 */
Signal.prototype.getAxis = function () {
//	console.log ("Signal.getAxis");
	return this.axis;
};


//==============================================================================
/**
 * For HIGHLIGHT_CHANGE. Set the axis perpendicular to the current slice plan.
 * @param {AxisEnum} axis - the axis.
 * @return {void}
 */
Signal.prototype.setAxis = function (axis) {
//	console.log ("Signal.setAxis");
	this.axis = axis;
};


//==============================================================================
/**
 * For HIGHLIGHT_CHANGE.
 * @return {Number} the number of the slice.
 */
Signal.prototype.getOffset = function () {
//	console.log ("Signal.getOffset");
	return this.offset;
};


//==============================================================================
/**
 * For HIGHLIGHT_CHANGE. Set the number of the slice.
 * @param {Number} offset - the number.
 * @return {void}
 */
Signal.prototype.setOffset = function (offset) {
//	console.log ("Signal.setOffset");
	this.offset = offset;
};


//==============================================================================
/**
 * For ADD_CUBES and REMOVE_CUBES. 
 * @return {Facet[]} the list of modified cubes. 
 */
Signal.prototype.getCubes = function () {
//	console.log ("Signal.getCubes");
	return this.cubes;
};


//==============================================================================
/**
 * For ADD_CUBES and REMOVE_CUBES. Add a modified cube.
 * @param {Facet} cubes - a modified cube.
 * @return {void}
 */
Signal.prototype.addCubes = function (cubes) {
//	console.log ("Signal.addCubes");
	this.cubes.push (cubes);
};


