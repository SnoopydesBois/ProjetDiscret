/// LICENCE ////////////////////////////////////////////////////////////////////

/* Copyright (juin 2015)
 * Auteur : BENOIST Thomas, BISUTTI Adrien, DESPLEBAIN Tanguy, LAURET Karl
 * 
 * benoist.thomas@hotmail.fr
 * biscui_86@hotmail.fr
 * tanguy.desplebain@gmail.com
 * lauret.karl@hotmail.fr
 * 
 * Ce logiciel est un programme informatique servant à modéliser des
 * structures 3D voxellisées.
 * 
 * Ce logiciel est régi par la licence CeCILL soumise au droit français et
 * respectant les principes de diffusion des logiciels libres. Vous pouvez
 * utiliser, modifier et/ou redistribuer ce programme sous les conditions
 * de la licence CeCILL telle que diffusée par le CEA, le CNRS et l'INRIA
 * sur le site "http://www.cecill.info".
 * 
 * En contrepartie de l'accessibilité au code source et des droits de copie,
 * de modification et de redistribution accordés par cette licence, il n'est
 * offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
 * seule une responsabilité restreinte pèse sur l'auteur du programme,  le
 * titulaire des droits patrimoniaux et les concédants successifs.
 * 
 * A cet égard  l'attention de l'utilisateur est attirée sur les risques
 * associés au chargement,  à l'utilisation,  à la modification et/ou au
 * développement et à la reproduction du logiciel par l'utilisateur étant
 * donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
 * manipuler et qui le réserve donc à des développeurs et des professionnels
 * avertis possédant  des  connaissances  informatiques approfondies.  Les
 * utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
 * logiciel à leurs besoins dans des conditions permettant d'assurer la
 * sécurité de leurs systèmes et ou de leurs données et, plus généralement,
 * à l'utiliser et l'exploiter dans les mêmes conditions de sécurité.
 * 
 * Le fait que vous puissiez accéder à cet en-tête signifie que vous avez
 * pris connaissance de la licence CeCILL, et que vous en avez accepté les
 * termes.
 */

/// INDEX //////////////////////////////////////////////////////////////////////


/* matCube : Cube[][][]
 * size : Vector
 * nbCube : int
 *
 * Model(size : Vector)
 * getCube(x : int, y : int, z : int) : Cube
 * addCube(x : int, y : int, z : int) : bool
 * removeCube(x : int, y : int, z : int) : bool
 * isIn(x : int, y : int, z : int) : bool
 * getSize() : Vector
 * andModel(other : Model) : void
 * orModel(other : Model) : void
 * xorModel(other : Model) : void
 * clear() : void
 * copy() : Model
 * getNbNeighbor(x : int, y : int, z : int) : int
 * getNbCube() : int
 */

/// CODE ///////////////////////////////////////////////////////////////////////



Model.prototype.constructor = Model;

/**
 * @constructor
 * @param {Vector} size - vector to define the size of the model.
 */
function Model (size) {
	/*console.log ("Model.constructor"
			+ " size = [" + size.m[0] + ", " + size.m[1] + ", "
			+ size.m[2] + "]");*/
	if (typeof size != "object") {
		console.error ("ERROR - Model.constructor : bad type of parameter");
	}
	// --------------------------------------
	this.size = size;
	this.matCube = new Array();
	for (var x = 0; x < this.size.m[0]; ++x) {
		this.matCube[x] = new Array();
		for (var y = 0; y < this.size.m[1]; ++y) {
			this.matCube[x][y] = new Array();
			for (var z = 0; z < this.size.m[2]; ++z) {
				this.matCube[x][y][z] = null;
			}
		}
	}
	this.nbCube = 0;
}


//==============================================================================
/**
 * @param {int} x - x-coordinates of the cube in the matrix.
 * @param {int} y - y-coordinates of the cube in the matrix.
 * @param {int} z - z-coordinates of the cube in the matrix.
 * @return {Cube} cube at the specified coordinates.
 */
Model.prototype.getCube = function (x, y, z) {
	//console.log ("Model.getCube x= "+x+" y= "+y+" z= "+z);
	if (typeof x != "number"
			|| typeof y != "number"
			|| typeof z != "number") {
		console.error ("ERROR - Cube.getCube : bad type of parameter");
	}
	// --------------------------------------
	return (this.isIn(x,y,z))? this.matCube[x][y][z] : null;
};


//==============================================================================
/**
 * Add a cube to the model.
 * @param {int} x - x-coordinates of the cube in the matrix.
 * @param {int} y - y-coordinates of the cube in the matrix.
 * @param {int} z - z-coordinates of the cube in the matrix.
 * @return {boolean} true if there is no error, false otherwise.
 */
Model.prototype.addCube = function (x, y, z) {
	//console.log ("Model.getCube x= "+x+" y= "+y+" z= "+z);
	if (typeof x != "number"
			|| typeof y != "number"
			|| typeof z != "number") {
		console.error ("ERROR - Cube.addCube : bad type of parameter");
	}
	// --------------------------------------
	if (this.isIn (x, y, z)) {
		if (this.matCube[x][y][z] == null) {
			this.matCube[x][y][z] = new Cube(new Vector(x,y,z));
			for (var i=0; i<DirectionEnum.size; ++i) {
				if (this.isIn(x+DirectionEnum.properties[i].x,
								y+DirectionEnum.properties[i].y,
								z+DirectionEnum.properties[i].z)) {
					if (this.matCube[x+DirectionEnum.properties[i].x]
									[y+DirectionEnum.properties[i].y]
									[z+DirectionEnum.properties[i].z] != null) {
						this.matCube[x][y][z].removeFacet(i);
						this.matCube[x+DirectionEnum.properties[i].x]
									[y+DirectionEnum.properties[i].y]
									[z+DirectionEnum.properties[i].z]
							.removeFacet(DirectionEnum.properties[i].oppose);
					}
				}
			}
			this.nbCube++;
		}
		return true;
	} 
	else {
		console.log ("hors limite : " + x + " " + y + " " + z);
		return false;
	}
};


//==============================================================================
/**
 * Remove a cube from the model.
 * @param {int} x - x-coordinates of the cube in the matrix.
 * @param {int} y - y-coordinates of the cube in the matrix.
 * @param {int} z - z-coordinates of the cube in the matrix.
 * @return {boolean} true if there is no error, false otherwise.
 */
Model.prototype.removeCube = function (x, y, z) {
	//console.log ("Model.getCube x= "+x+" y= "+y+" z= "+z);
	if (typeof x != "number"
			|| typeof y != "number"
			|| typeof z != "number") {
		console.error ("ERROR - Cube.removeCube : bad type of parameter");
	}
	// --------------------------------------
	if (this.isIn(x,y,z)) {
		if (this.matCube[x][y][z] != null) {
			this.matCube[x][y][z] = null;
			for (var i=0; i<DirectionEnum.size; ++i) {
				if (this.isIn(x+DirectionEnum.properties[i].x,
								y+DirectionEnum.properties[i].y,
								z+DirectionEnum.properties[i].z)) {
					if (this.matCube[x+DirectionEnum.properties[i].x]
									[y+DirectionEnum.properties[i].y]
									[z+DirectionEnum.properties[i].z] != null) {
						this.matCube[x+DirectionEnum.properties[i].x]
									[y+DirectionEnum.properties[i].y]
									[z+DirectionEnum.properties[i].z]
								.addFacet(DirectionEnum.properties[i].oppose);
					}
				}
			}
			this.nbCube--;
		}
		return true;
	} 
	else {
//		console.log ("hors limite : " + x + " " + y + " " + z);
		return false;
	}
	
};


//==============================================================================
/**
 * @param {int} x - x-coordinates.
 * @param {int} y - y-coordinates.
 * @param {int} z - z-coordinates.
 * @return {boolean} true if the coordinates are in the matrix, false otherwise.
 */
Model.prototype.isIn = function (x, y, z) {
	//console.log ("Model.isIn");
	if (typeof x != "number"
			|| typeof y != "number"
			|| typeof z != "number")
	{
		console.error ("ERROR - Cube.isIn : bad type of parameter");
	}
	// --------------------------------------
	return (x >= 0 && x < this.size.m[0] && y >= 0 && y < this.size.m[1]
			&& z >= 0 && z < this.size.m[2]);
};


//==============================================================================
/**
 * @return {Vector} the size of the matrix.
 */
Model.prototype.getSize = function () {
	//console.log ("Model.getSize");
	// --------------------------------------
	return this.size;
};


//==============================================================================
/**
 * Boolean operation "AND" (interseciton) on the matrix.
 * @param {Model} other - another matrix.
 * @return {void}
 */
Model.prototype.andModel = function (other) {
	//console.log ("Model.andModel");
	if (typeof other != "object") {
		console.error ("ERROR - Cube.andModel : bad type of parameter");
	}
	// --------------------------------------
	var tmpX = Math.min(this.size.m[0], other.size.m[0]);
	var tmpY = Math.min(this.size.m[1], other.size.m[1]);
	var tmpZ = Math.min(this.size.m[2], other.size.m[2]);
	for (var x = 0; x<tmpX; ++x) {
		for (var y = 0; y<tmpY; ++y) {
			for (var z = 0; z<tmpZ; ++z) {
				if (!(other.matCube[x][y][z] != null
						&& this.matCube[x][y][z] != null)) {
					this.removeCube(x,y,z);
				}
			}
		}
	}
};


//==============================================================================
/**
 * Boolean operation "OR" (union) on the matrix.
 * @param {Model} other - another matrix.
 * @return {void}
 */
Model.prototype.orModel = function (other) {
	//console.log ("Model.orModel");
	if (typeof other != "object") {
		console.error ("ERROR - Cube.orModel : bad type of parameter");
	}
	// --------------------------------------
	var tmpX = Math.min(this.size.m[0], other.size.m[0]);
	var tmpY = Math.min(this.size.m[1], other.size.m[1]);
	var tmpZ = Math.min(this.size.m[2], other.size.m[2]);
	for (var x = 0; x < tmpX; ++x) {
		for (var y = 0; y < tmpY; ++y) {
			for (var z = 0; z < tmpZ; ++z) {
				if (other.matCube[x][y][z] != null) {
					this.addCube (x, y, z);
				}
			}
		}
	}
};


//==============================================================================
/**
 * Boolean operation "ANDNOT" (exclusion) on the matrix.
 * @param {Model} other - another matrix.
 * @return {void}
 */
Model.prototype.andNotModel = function (other) {
	//console.log ("Model.andNotModel");
	if (typeof other != "object") {
		console.error ("ERROR - Cube.andNotModel : bad type of parameter");
	}
	// --------------------------------------
	var tmpX = Math.min(this.size.m[0], other.size.m[0]);
	var tmpY = Math.min(this.size.m[1], other.size.m[1]);
	var tmpZ = Math.min(this.size.m[2], other.size.m[2]);
	for (var x=0; x<tmpX; ++x) {
		for (var y=0; y<tmpY; ++y) {
			for (var z=0; z<tmpZ; ++z) {
				if (other.matCube[x][y][z] != null) {
					this.removeCube(x,y,z);
				}
			}
		}
	}
};


//==============================================================================
/**
 * Boolean operation "XOR" on the matrix.
 * @param {Model} other - another matrix.
 * @return {void}
 */
Model.prototype.xorModel = function (other) {
	//console.log ("Model.xorModel");
	if (typeof other != "object") {
		console.error ("ERROR - Cube.xorModel : bad type of parameter");
	}
	// --------------------------------------
	var tmpX = Math.min(this.size.m[0], other.size.m[0]);
	var tmpY = Math.min(this.size.m[1], other.size.m[1]);
	var tmpZ = Math.min(this.size.m[2], other.size.m[2]);
	for (var x = 0; x < tmpX; ++x) {
		for (var y = 0; y < tmpY; ++y) {
			for (var z = 0; z < tmpZ; ++z) {
				if (other.matCube[x][y][z] != null) {
					if (this.matCube[x][y][z] != null) {
						this.removeCube (x, y, z);
					} else {
						this.addCube (x, y, z);
					}
				}
			}
		}
	}
};


//==============================================================================
/**
 * Empty the matrix.
 * @return {void}
 */
Model.prototype.clear = function () {
	//console.log ("Model.clear");
	// --------------------------------------
	for (var x = 0; x < this.size.m[0]; ++x) {
		for (var y = 0; y < this.size.m[1]; ++y) {
			for (var z = 0; z < this.size.m[2]; ++z) {
				this.matCube[x][y][z] = null;
			}
		}
	}
	this.nbCube = 0;
};


//==============================================================================
/**
 * @return {Model} a copy of the model.
 */
Model.prototype.copy = function () {
	//console.log ("Model.copy");
	// --------------------------------------
	var result = new Model (this.size);
	for (var x = 0; x < result.size.m[0]; ++x) {
		for (var y = 0; y < result.size.m[1]; ++y) {
			for (var z = 0; z < result.size.m[2]; ++z) {
				result.matCube[x][y][z] = this.matCube[x][y][z];
			}
		}
	}
	result.nbCube = this.nbCube;
	return result;
};


//==============================================================================
/**
 * @param {int} x - x-coordinates of the cube in the matrix.
 * @param {int} y - y-coordinates of the cube in the matrix.
 * @param {int} z - z-coordinates of the cube in the matrix.
 * @return {int} number of neighboring cubes.
 */
Model.prototype.getNbNeighbor = function (x, y, z) {
	//console.log ("Model.getNbNeighbor x= " + x + " y= " + y + " z= " + z);
	if (typeof x != "number"
			|| typeof y != "number"
			|| typeof z != "number") {
		console.error ("ERROR - Cube.getNbNeighbor : bad type of parameter");
	}
	// --------------------------------------
	var nb = 0;
	for (var i = 0; i < DirectionEnum.size; ++i) {
		if (this.isIn (x+DirectionEnum.properties[i].x,
						y+DirectionEnum.properties[i].y,
						z+DirectionEnum.properties[i].z)) {
			if (this.matCube[x+DirectionEnum.properties[i].x]
							[y+DirectionEnum.properties[i].y]
							[z+DirectionEnum.properties[i].z] != null) {
				nb++;
			}
		}
	}
	return nb;
};


//==============================================================================
/**
 * @return {int} the number of cubes of the model.
 */
Model.prototype.getNbCube = function () {
	//console.log ("Model.getNbCube");
	// --------------------------------------
	return this.nbCube;
};


