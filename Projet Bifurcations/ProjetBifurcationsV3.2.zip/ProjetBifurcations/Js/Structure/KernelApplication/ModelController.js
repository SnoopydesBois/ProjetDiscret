/// LICENCE ////////////////////////////////////////////////////////////////////

/* Copyright (juin 2015)
 * Auteur : BENOIST Thomas, BISUTTI Adrien, DESPLEBAIN Tanguy, LAURET Karl
 * 
 * benoist.thomas@hotmail.fr
 * biscui_86@hotmail.fr
 * tanguy.desplebain@gmail.com
 * lauret.karl@hotmail.fr
 * 
 * Ce logiciel est un programme informatique servant à modéliser des
 * structures 3D voxellisées.
 * 
 * Ce logiciel est régi par la licence CeCILL soumise au droit français et
 * respectant les principes de diffusion des logiciels libres. Vous pouvez
 * utiliser, modifier et/ou redistribuer ce programme sous les conditions
 * de la licence CeCILL telle que diffusée par le CEA, le CNRS et l'INRIA
 * sur le site "http://www.cecill.info".
 * 
 * En contrepartie de l'accessibilité au code source et des droits de copie,
 * de modification et de redistribution accordés par cette licence, il n'est
 * offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
 * seule une responsabilité restreinte pèse sur l'auteur du programme,  le
 * titulaire des droits patrimoniaux et les concédants successifs.
 * 
 * A cet égard  l'attention de l'utilisateur est attirée sur les risques
 * associés au chargement,  à l'utilisation,  à la modification et/ou au
 * développement et à la reproduction du logiciel par l'utilisateur étant
 * donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
 * manipuler et qui le réserve donc à des développeurs et des professionnels
 * avertis possédant  des  connaissances  informatiques approfondies.  Les
 * utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
 * logiciel à leurs besoins dans des conditions permettant d'assurer la
 * sécurité de leurs systèmes et ou de leurs données et, plus généralement,
 * à l'utiliser et l'exploiter dans les mêmes conditions de sécurité.
 * 
 * Le fait que vous puissiez accéder à cet en-tête signifie que vous avez
 * pris connaissance de la licence CeCILL, et que vous en avez accepté les
 * termes.
 */

/// INDEX //////////////////////////////////////////////////////////////////////


/* model : Model
 * selectedFacets : Facet[]
 * hoverFacet : Facet
 *
 * ModelController(size : Vector, name : String)
 * getModel() : Model
 * getName() : String
 * isSelectedFacet(facet : Facet) : bool
 * getSelectedFacet(index : int) : Facet
 * addSelectedFacet(facet : Facet) : void
 * removeSelectedFacet(facet : Facet) : void
 * clearSelectFacet() : void
 * setSelectedFacet(facet : Facet) : void
 * getNbSelectedFacet() : int
 * getHoverFacet() : Facet
 * setHoverFacet(facet : Facet) : void
 * isHoverFacet() : bool
 * copy() : ModelController
 */

/// CODE ///////////////////////////////////////////////////////////////////////



ModelController.prototype.constructor = ModelController;

/**
 * @constructor 
 * @param {Vector} size - Vector to define the size of the model.
 * @param {String} name - The name of the ModelController.
 * @param {String} [_modelCreator] - The name of the creator of the model.
 * @param {String} [_modelCreationDate] - The date of the creation of the model.
 * @param {String} [_modelDescription] - The description of the model.
 */ 
function ModelController (size, name,_modelCreator,
		_modelCreationDate,_modelDescription)
{
//	console.log ("ModelController.constructor");
	if (typeof size != "object") {
		console.error ("ERROR - ModelController.constructor : "
				+ "bad type of parameter");
	}
	// --------------------------------------
	
	/**
	 * {Model} The model.
	 */
	this.model = new Model (size);
	
	/**
	 * {Facet[]} List of selected face.
	 */
	this.selectedFacets = [];
	
	/**
	 * {Facet} The horeved face.
	 */
	this.hoverFacet = null;
	
	
	/**
	 * {String} The name of this model.
	 */
	this.name = name;
	
	/**
	 * {String} The id of this model.
	 */
	this.id = "";
	
	/**
	 * {String} The creator of this model.
	 */
	this.creator = "";
	if (_modelCreator != undefined) {
		this.creator = _modelCreator;
	}
	
	/**
	 * {String} The creation date.
	 */
	this.creationDate = "";
	if (_modelCreationDate != undefined) {
		this.creationDate = _modelCreationDate;
	}
	
	/**
	 * {String} A description of this model.
	 */
	this.description = "";
	if (_modelDescription != undefined) {
		this.description = _modelDescription;
	}
	
	/**
	 * {Application} A listener to which every changement.
	 */
	this.listener = appli;
}


//==============================================================================
/**
 * @return {Model} the model.
 */
ModelController.prototype.getModel = function () {
//	console.log ("ModelController.getModel");
	// --------------------------------------
	return this.model;
};


//==============================================================================
/**
 * @param {int} x - the x coordinate of the cube to get
 * @param {int} y - the y coordinate of the cube to get
 * @param {int} z - the z coordinate of the cube to get
 * @return {Cube} the cube
 */
ModelController.prototype.getCube = function (x, y, z) {
//	console.log ("ModelController.getCube");
	// --------------------------------------
	return this.model.getCube (x, y, z);
};


//==============================================================================
/**
 * Assessor on name of the model
 * @return {String} name of the model
 */
ModelController.prototype.getName = function () {
//	console.log ("ModelController.getName");
	// --------------------------------------
	return this.name;
};


//==============================================================================
/**
 * Assessor on creator of the model
 * @return {String} creator of the model
 */
ModelController.prototype.getCreator = function () {
//	console.log ("ModelController.getCreator");
	// --------------------------------------
	return this.creator;
};


//==============================================================================
/**
 * @return {String} the date of creation of the model.
 */
ModelController.prototype.getCreationDate = function () {
	//console.log ("ModelController.getDate");
	// --------------------------------------
	return this.creationDate;
};


//==============================================================================
/**
 * @return {String} the description of the model.
 */
ModelController.prototype.getDescription = function () {
	//console.log ("ModelController.getDescription");
	// --------------------------------------
	return this.description;
};


//==============================================================================
/**
 * @return {Vector} the size of the model.
 */
ModelController.prototype.getSize = function () {
//	console.log ("ModelController.getSize");
	// --------------------------------------
	return this.model.getSize();
};


//==============================================================================
/**
 * Get the number of neighbor of a cube at the x, y, z coordinates
 * @param {int} x - the x coordinate of the cube to look
 * @param {int} y - the y coordinate of the cube to look
 * @param {int} z - the z coordinate of the cube to look
 * @return {int} the number of neighbors.
 */
ModelController.prototype.getNbNeighbor = function (x, y, z) {
	//console.log ("ModelController.getNbNeighbor");
	// --------------------------------------
	return this.model.getNbNeighbor (x, y, z);
};


//==============================================================================
/**
 * @return {int} the number of cubes in the model.
 */
ModelController.prototype.getNbCube = function () {
//	console.log ("ModelController.getNbCube");
	// --------------------------------------
	return this.model.getNbCube();
};


//==============================================================================
/**
 * @return {int} the id of the model.
 */
ModelController.prototype.getId = function () {
//	console.log ("ModelController.getId");
	// --------------------------------------
	return this.id;
};


//==============================================================================
/**
 * @param {int} id - the id of the model.
 * @return {void}
 */
ModelController.prototype.setId = function (id) {
//	console.log ("ModelController.getNbCube");
	// --------------------------------------
	this.id = id;
};


//==============================================================================
/**
 * Test if coordonates is in the model.
 * @param {int} x - the x coordinate to test.
 * @param {int} y - the y coordinate to test.
 * @param {int} z - the z coordinate to test.
 * @return {boolean} true if the coordinates are valid, false otherwise.
 */
ModelController.prototype.isIn = function (x, y, z) {
//	console.log ("ModelController.isIn");
	// --------------------------------------
	return this.model.isIn (x, y, z);
};


//==============================================================================
/**
 * Is this facet selected.
 * @param {Facet} facet - facet to test.
 * @return {boolean} true if the facet is selected, false otherwise.
 */
ModelController.prototype.isSelectedFacet = function (facet) {
	/*console.log ("ModelController.isSelectedFacet"
			+ "facet.cubeCoor = [" + facet.cubeCoor.m[0] + ", "
			+ facet.cubeCoor.m[1] + ", " + facet.cubeCoor.m[2] 
			+ " facet.direction= " + facet.direction);*/
	if (typeof facet != "object") {
		console.error ("ERROR - ModelController.isSelectedFacet :"
				+ "bad type of parameter");
	}
	// --------------------------------------
	for (var i = 0; i < this.selectedFacets.length; ++i) {
		if (this.selectedFacets[i].egale(facet)) {
			return true;
		}
	}
	return false;
};


//==============================================================================
/**
 * Get the nth selected face.
 * @param {int} index - the nth face.
 * @return {Facet} the selected facet.
 */
ModelController.prototype.getSelectedFacet = function (index) {
//	console.log ("ModelController.getSelectedFacet");
	if (typeof index != "number") {
		console.error ("ERROR - ModelController.getSelectedFacet :"
				+ "bad type of parameter");
	}
	// --------------------------------------
	return this.selectedFacets[index];
};


//==============================================================================
/**
 * Add this facet to the selection list.
 * @param {Facet} facet - facet to add.
 * @return {void}
 */
ModelController.prototype.addSelectedFacet = function (facet) {
//	console.log ("ModelController.addSelectedFacet");
	if (typeof facet != "object") {
		console.error ("ERROR - ModelController.addSelectedFacet :"
						+ "bad type of parameter");
	}
	// --------------------------------------
	if (this.selectedFacets.indexOf (facet) == -1) {
		this.selectedFacets.push (facet);
	}
};


//==============================================================================
/**
 * Removes this facet of the selection list 
 * @param {Facet} facet - facet to remove.
 * @return {void}
 */
ModelController.prototype.removeSelectedFacet = function (facet) {
//	console.log ("ModelController.removeSelectedFacet");
	if (typeof facet != "object") {
		console.error ("ERROR - ModelController.removeSelectedFacet :"
						+ "bad type of parameter");
	}
	// --------------------------------------
	for (var i=this.selectedFacets.length-1; i>=0; --i) {
		if (this.selectedFacets[i].egale(facet)) {
			this.selectedFacets.splice(i, 1);
		}
	}
	if (facet.direction == DirectionEnum.ALL) {
		for (var j = 0; j < DirectionEnum.size; ++j) {
			var tmp = new Facet (facet.cubeCoor, j);
			for (var i = this.selectedFacets.length-1; i >= 0; --i) {
				if (this.selectedFacets[i].egale(tmp)) {
					this.selectedFacets.splice(i, 1);
				}
			}
		}
	}
};


//==============================================================================
/**
 * Removes a facet from the selection list given it's index.
 * @param {int} index - The index of the facet to remove.
 * @return {void}
 */
ModelController.prototype.removeSelectedFacetByIndex = function (index) {
	//console.log ("ModelController.removeSelectedFacetByIndex");
	this.selectedFacets.splice (index, 1);
};


//==============================================================================
/**
 * Removes all facet of the selection list.
 * @return {void}
 */
ModelController.prototype.clearSelectFacet = function () {
	//console.log ("ModelController.clearSelectFacet");
	// --------------------------------------
	this.selectedFacets = [];
};


//==============================================================================
/**
 * Removes all facet and adds a facet to the selection list.
 * @param {Facet} facet - facet to add.
 * @return {void}
 */
ModelController.prototype.setSelectedFacet = function (facet) {
//	console.log ("ModelController.setSelectedFacet");
	if (typeof facet != "object") {
		console.error ("ERROR - ModelController.setSelectedFacet : "
				+ "bad type of parameter");
	}
	// --------------------------------------
	this.clearSelectFacet ();
	this.addSelectedFacet (facet);
};


//==============================================================================
/**
 * @return {int} the number of selected facet.
 */
ModelController.prototype.getNbSelectedFacet = function () {
//	console.log ("ModelController.getNbSelectedFacet");
	// --------------------------------------
	return this.selectedFacets.length;
};


//==============================================================================
/**
 * @return {Facet} the hover facet.
 */
ModelController.prototype.getHoverFacet = function () {
//	console.log ("ModelController.getHoverFacet");
	// --------------------------------------
	return this.hoverFacet;
};


//==============================================================================
/**
 * Set the hovered facet.
 * @param {Facet} facet - facet to hover.
 * @return {void}
 */
ModelController.prototype.setHoverFacet = function (facet) {
//	console.log ("ModelController.setHoverFacet");
	if (typeof facet != "object") {
		console.error ("ERROR - ModelController.setHoverFacet : "
						+ "bad type of parameter");
	}
	// --------------------------------------
	this.hoverFacet = facet;
};


//==============================================================================
/**
 * @return {boolean} true if a facet is hovered, false otherwise.
 */
ModelController.prototype.isHoverFacet = function () {
//	console.log ("ModelController.isHoverFacet");
	// --------------------------------------
	return this.hoverFacet != null;
};


//==============================================================================
/**
 * @return {ModelController} a deep copy of this model controller.
 */
ModelController.prototype.copy = function () {
//	console.log ("ModelController.copy");
	// --------------------------------------
	var result = this.model.copy();
	result.selectedFacets = this.selectedFacets;
	result.hoverFacet = this.hoverFacet;
	return result;
};


//==============================================================================
/**
 * Empty the modelController. Remove all the cubes in the model 
 * and remove the selectedFacets and hoverFacet.
 * Keep name, id, creator, creation date and description.
 * @return {void}
 */
ModelController.prototype.clear = function () {
//	console.log ("ModelController.clear");
	// --------------------------------------
	this.model.clear();
	this.selectedFacets = [];
	this.hoverFacet = null;
};


//==============================================================================
/**
 * Add a cube at the x, y, z coordinates.
 * @param {int} x - the x coordinate where to add the cube.
 * @param {int} y - the y coordinate where to add the cube.
 * @param {int} z - the z coordinate where to add the cube.
 * @return {boolean} true if no error, flase otherwise.
 */
ModelController.prototype.addCube = function (x, y, z) {
//	console.log ("ModelController.addCube");
	// --------------------------------------
	return this.model.addCube (x, y, z);
};


//==============================================================================
/**
 * Remove a cube at the x, y, z coordinates.
 * @param {int} x - the x coordinate where to remove the cube.
 * @param {int} y - the y coordinate where to remove the cube.
 * @param {int} z - the z coordinate where to remove the cube.
 * @return {boolean} true if no error, else false
 */
ModelController.prototype.removeCube = function (x, y, z) {
//	console.log ("ModelController.removeCube");
	// --------------------------------------
	return this.model.removeCube (x, y, z);
};


//==============================================================================
/**
 * Boolean operation "AND" (intersection) on the matrix.
 * @param {Model} model - an other model.
 * @return {void}
 */
ModelController.prototype.andModel = function (model) {
//	console.log ("ModelController.andModel");
	// --------------------------------------
	this.model.andModel(model);
};


//==============================================================================
/**
 * Boolean operation "OR" (union) on the matrix.
 * @param {Model} model - an other model.
 * @return {void}
 */
ModelController.prototype.orModel = function (model) {
//	console.log ("ModelController.orModel");
	// --------------------------------------
	this.model.orModel(model);
};


//==============================================================================
/**
 * Boolean operation "XOR" on the matrix.
 * @param {Model} model - an other model.
 * @return {void}
 */
ModelController.prototype.xorModel = function (model) {
//	console.log ("ModelController.xorModel");
	// --------------------------------------
	this.model.xorModel(model);
};


//==============================================================================
/**
 * Boolean operation "ANDNOT" (exclusion) on the matrix.
 * the matrix is changed, but not the parameter
 * @param {Model} model - an other model.
 * @return {void}
 */
ModelController.prototype.andNotModel = function (model) {
	//console.log ("ModelController.andNotModel");
	// --------------------------------------
	this.model.andNotModel(model);
};


//==============================================================================
/**
 * Send a signal to the application depending on the type of operation.
 * @param {Signal} signal - The signal to send to the application.
 * @return {void}
 */
ModelController.prototype.alert = function (signal) {
//	console.log ("ModelController.alert");
	this.listener.alertChange (signal);
};


//==============================================================================
/**
 * Add a listener.
 * @param {Object} listener - the object to communicate with.
 */
ModelController.prototype.setListener = function (listener) {
//	console.log ("ModelController.setListener");
	this.listener = listener;
};


//==============================================================================
/**
 * Verify if a cube exist in this a given slice.
 * @param {AxisEnum} axis - the orthogonal axis to the slice.
 * @param {int} nb - the slice's number.
 * @return {boolean} true if there is at least one cube in the slice,
 * false otherwise.
 */
ModelController.prototype.isCubeInSlice = function (axis, nb) {
	switch (axis) {
		case AxisEnum.X :
			for (var i=0; i<this.getSize().m[1]; ++i) {
				for (var j=0; j<this.getSize().m[2]; ++j) {
					if (this.getModel().getCube(nb,i,j) != null) {
						return true;
					}
				}
			}
			break;
		case AxisEnum.Y :
			for (var i=0; i<this.getSize().m[0]; ++i) {
				for (var j=0; j<this.getSize().m[2]; ++j) {
					if (this.getModel().getCube(i,nb,j) != null) {
						return true;
					}
				}
			}
			break;
		case AxisEnum.Z :
			for (var i=0; i<this.getSize().m[0]; ++i) {
				for (var j=0; j<this.getSize().m[1]; ++j) {
					if (this.getModel().getCube(i,j,nb) != null) {
						return true;
					}
				}
			}
			break;
	}
	return false;
};


//==============================================================================
/**
 * @return {boolean} true if the model is connex, false otherwise.
 */
ModelController.prototype.isConnex = function () {
	var tmp = new Array();
	var cube = null;
	for (var x=0; x<this.getSize().m[0]; ++x) {
		tmp.push(new Array());
		for (var y=0; y<this.getSize().m[1]; ++y) {
			tmp[x].push(new Array());
			for (var z=0; z<this.getSize().m[2]; ++z) {
				if (this.getCube(x,y,z) != null) {
					tmp[x][y].push(1);
					cube = new Vector (x,y,z);
				}
				else {
					tmp[x][y].push(0);
				}
			}
		}
	}
	if (cube==null) {
		return true;
	}
	this.propagation(tmp,cube.m[0],cube.m[1],cube.m[2]);
	for (var x=0; x<this.getSize().m[0]; ++x) {
		for (var y=0; y<this.getSize().m[1]; ++y) {
			for (var z=0; z<this.getSize().m[2]; ++z) {
				if (tmp[x][y][z]==1) {
					return false;
				}
			}
		}
	}
	return true;
}


//==============================================================================
/**
 * Replace all the 1 in the matrix by 2 if the cube at this position is connex
 * to another cube.
 * @param {int[][][]} mat - the model cubes represented by ones.
 * @param {int} x - the x coordinate of the first cube.
 * @param {int} y - the y coordinate of the first cube.
 * @param {int} z - the z coordinate of the first cube.
 * @return {void}
 */
ModelController.prototype.propagation = function (mat,x,y,z) {
	var listeCoord = new Array();
	listeCoord.push([x,y,z]);
	while(listeCoord.length>0) {
		var x = listeCoord[0][0];
		var y = listeCoord[0][1]
		var z = listeCoord[0][2];
		listeCoord.splice(0,1);
		if (this.isIn(x,y,z) && mat[x][y][z]==1) {
			mat[x][y][z] = 2;
			for (var i=0; i<DirectionEnum.size; ++i) {
				var newX = x + DirectionEnum.properties[i].x;
				var newY = y + DirectionEnum.properties[i].y;
				var newZ = z + DirectionEnum.properties[i].z;
				listeCoord.push([newX,newY,newZ]);
			}
		}
	}
};


//==============================================================================
/**
 * @return {boolean} true if the model possess 25 cubes along an axis,
 * false otherwise.
 */
ModelController.prototype.dimensionVerification = function () {
	for (var i=0; i<3; ++i) {
		if (this.isCubeInSlice(AxisEnum.toAxis(i),0)) {
			if (this.isCubeInSlice(AxisEnum.toAxis(i),this.getSize().m[i]-1)) {
				return true;
			}
		}
	}
	return false;
};


//==============================================================================
/**
 * @return {boolean} true if a model is valid, false otherwise.
 */
ModelController.prototype.isValid = function () {
	return this.dimensionVerification() && this.isConnex();
};


