/// LICENCE ////////////////////////////////////////////////////////////////////

/* Copyright (juin 2015)
 * Auteur : BENOIST Thomas, BISUTTI Adrien, DESPLEBAIN Tanguy, LAURET Karl
 * 
 * benoist.thomas@hotmail.fr
 * biscui_86@hotmail.fr
 * tanguy.desplebain@gmail.com
 * lauret.karl@hotmail.fr
 * 
 * Ce logiciel est un programme informatique servant à modéliser des
 * structures 3D voxellisées.
 * 
 * Ce logiciel est régi par la licence CeCILL soumise au droit français et
 * respectant les principes de diffusion des logiciels libres. Vous pouvez
 * utiliser, modifier et/ou redistribuer ce programme sous les conditions
 * de la licence CeCILL telle que diffusée par le CEA, le CNRS et l'INRIA
 * sur le site "http://www.cecill.info".
 * 
 * En contrepartie de l'accessibilité au code source et des droits de copie,
 * de modification et de redistribution accordés par cette licence, il n'est
 * offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
 * seule une responsabilité restreinte pèse sur l'auteur du programme,  le
 * titulaire des droits patrimoniaux et les concédants successifs.
 * 
 * A cet égard  l'attention de l'utilisateur est attirée sur les risques
 * associés au chargement,  à l'utilisation,  à la modification et/ou au
 * développement et à la reproduction du logiciel par l'utilisateur étant
 * donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
 * manipuler et qui le réserve donc à des développeurs et des professionnels
 * avertis possédant  des  connaissances  informatiques approfondies.  Les
 * utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
 * logiciel à leurs besoins dans des conditions permettant d'assurer la
 * sécurité de leurs systèmes et ou de leurs données et, plus généralement,
 * à l'utiliser et l'exploiter dans les mêmes conditions de sécurité.
 * 
 * Le fait que vous puissiez accéder à cet en-tête signifie que vous avez
 * pris connaissance de la licence CeCILL, et que vous en avez accepté les
 * termes.
 */

/// INDEX //////////////////////////////////////////////////////////////////////

/* nbBuffer : int
 * vbo : Array(Buffer)
 * bbo : Array(Buffer)
 * ibo : Array(Buffer)
 * selectvbo : Array(Buffer)
 * selectibo : Array(Buffer)
 * hovervbo : Buffer
 * hoveribo : Buffer
 *
 * constructor (modelController : ModelController, name : String, 
 * shader : Shader)
 *
 * prepare(gl : GLContext) : void
 * draw(gl : GLContext) : void
 * prepareSelection(gl : GLContext) : void
 * prepareHover(gl : GLContext) : void
 * backBufferDraw(gl : GLContext) : void
 * prepareCubeNormal(cube : Cube, vertices : Array, indices : Array,
 * color : Array, backColor : Array, normal : Array) : void
 * addVertices(dataVertices : Array, x : int, y : int, z : int,
 * size : Vector) : void
 * prepareFaceHover(face : Facet, vertices : Array, indices : Array,
 * color : Array, normal : Array) : void
 * prepareFaceSelect(face : Facet, vertices : Array, indices : Array, 
 * color : Array, normal : Array) : void
 * clearHover() : void
 * clearSelect() : void
 */

/// CODE ///////////////////////////////////////////////////////////////////////



ModelView3DExtrud.prototype = new ModelView();
ModelView3DExtrud.prototype.constructor = ModelView3DExtrud;

/**
 * @constructor
 * @param {ModelController} modelController - the model to display.
 * @param {String} name - the name of the model.
 * @param {Shader} shader - shader for display.
 */
function ModelView3DExtrud(modelController, name, shader) {
	//console.log ("ModelView3DExtrud.constructor");
	if (typeof modelController != "object"
			|| typeof name != "string"
			|| typeof shader != "object") {
		console.error ("ERROR - ModelView3DExtrud.constructor : bad type of "
				+"parameter");
	}
	// --------------------------------------
	ModelView.call(this, modelController, name, shader);
	this.positive = true;
}


//==============================================================================
/**
 * Prepare the model (create the triangles).
 * @param {GLContext} gl - the gl context.
 * @param {int} nb - number of buffer to prepare (if undefined then 
 * all buffer are prepared).
 * @return {void}
 */
ModelView3DExtrud.prototype.prepare = function (gl) {
	//console.log ("ModelView3DExtrud.prepare");
	if (typeof gl != "object") {
		console.error ("ERROR - ModelView3DExtrud.prepare : bad type of"
			+" parameter");
	}
	// --------------------------------------
	var size = this.modelController.getModel().getSize();
	this.nbBuffer = size.m[0]/5;

	var vertices = [];
	var indices = [];
	var color = [];
	var normal = [];
	var backColor = [];
	var data = [];
	var bdata = [];

	this.vbo = [];
	this.bbo = [];
	this.ibo = [];

	for (var tmp=0; tmp<this.nbBuffer; ++tmp) {
		/* On large models, the indices are > a 2^16 bits and the display 
		 won't work correctly.
		 To fix that, we cut in 5 the buffer along the X axis.
		 There are optimization possible for the rendering*/
		vertices.push([]);
		indices.push([]);
		color.push([]);
		normal.push([]);
		backColor.push([]);
		data.push([]);
		bdata.push([]);
		this.vbo.push([]);
		this.bbo.push([]);
		this.ibo.push([]);
	}
	// 2 triangles per faces
	// No triangles strips because there are not a lot of degenerated triangles
	for (var x = 0; x < size.m[0]; ++x) {
		for (var y = 0; y < size.m[1]; ++y) {
			for (var z = 0; z < size.m[2]; ++z) {
				if (this.modelController.getModel().getCube(x,y,z) != null) {
					this.prepareCubeNormal(
							this.modelController.getModel().getCube(x,y,z),
							vertices[Math.floor(x/this.nbBuffer)], 
							indices[Math.floor(x/this.nbBuffer)], 
							color[Math.floor(x/this.nbBuffer)],
							backColor[Math.floor(x/this.nbBuffer)], 
							normal[Math.floor(x/this.nbBuffer)]);
				}
			}
		}
	}

	// Create vertex buffer
	for (var tmp=0; tmp<this.nbBuffer; ++tmp) {
		this.vbo[tmp] = gl.createBuffer();
		this.vbo[tmp].numItems = vertices[tmp].length / 3.0;
		for (var i = 0; i < color[tmp].length; ++i) {
			for (var j = 0; j < 4; ++j) {
				var offset = i * 12 + j * 3;
				this.addAPoint(data[tmp], vertices[tmp][offset],
							vertices[tmp][offset + 1],
							vertices[tmp][offset + 2]);
				this.addAColor(data[tmp], this.positive?
							appli.getColor(CubeStateEnum.VALID,
							DirectionEnum.properties[DirectionEnum.TOP].axis)
							:
							appli.getColor(CubeStateEnum.ILLEGAL, 
							DirectionEnum.properties[DirectionEnum.TOP].axis));
				this.addANormal(data[tmp], normal[tmp][i]);
			}
		}
		gl.bindBuffer(gl.ARRAY_BUFFER, this.vbo[tmp]);
		gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(data[tmp]),
				gl.STATIC_DRAW);
	}

	for (var tmp=0; tmp<this.nbBuffer; ++tmp) {
		this.bbo[tmp] = gl.createBuffer();
		this.bbo[tmp].numItems = vertices[tmp].length / 3.0;
		for (var i = 0; i < color[tmp].length; ++i) {
			for (var j = 0; j < 4; ++j) {
				var offset = i * 12 + j * 3;
				this.addAPoint(bdata[tmp], vertices[tmp][offset],
						vertices[tmp][offset + 1], vertices[tmp][offset + 2]);
				this.addAColor(bdata[tmp], backColor[tmp][i]);
				this.addANormal(bdata[tmp], normal[tmp][i]);
			}
		}
		gl.bindBuffer(gl.ARRAY_BUFFER, this.bbo[tmp]);
		gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(bdata[tmp]),
				gl.STATIC_DRAW);
	}

	// Create index buffer
	for (var tmp=0; tmp<this.nbBuffer; ++tmp) {
		this.ibo[tmp] = gl.createBuffer();
		gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.ibo[tmp]);
		gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(indices[tmp]), 
		gl.STATIC_DRAW);
		this.ibo[tmp].numItems = indices[tmp].length;
	}
};


//==============================================================================
/**
 * Draw the model (draw the triangles).
 * @param {GLContext} gl - the gl context.
 * @return {void}
 */
ModelView3DExtrud.prototype.draw = function (gl) {
	//console.log ("ModelView3DExtrud.draw");
	if (typeof gl != "object") {
		console.error ("ERROR - ModelView3DExtrud.draw : bad type of parameter");
	}
	// --------------------------------------
	this.shader.setMode(2);
	for (var tmp=0; tmp<this.nbBuffer; ++tmp) {
		// Let's the shader prepare its attributes
		this.shader.setAttributes(gl, this.vbo[tmp]);
		// Let's render !
		gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.ibo[tmp]);
		gl.drawElements(gl.TRIANGLES, this.ibo[tmp].numItems, 
				gl.UNSIGNED_SHORT, 0);
	}
};


//==============================================================================
/**
 * Override : do nothing.
 * @param {GLContext} gl - the gl context.
 * @return {void}
 */
ModelView3DExtrud.prototype.prepareSelection = function (gl) {
	//console.log ("ModelView3DExtrud.prepareSelection");
	if (typeof gl != "object") {
		console.error ("ERROR - ModelView3DExtrud.prepareSelection : bad type of" 
				+" parameter");
	}
};


//==============================================================================
/**
 * Override : do nothing.
 * @param {GLContext} gl - the gl context
 * @return {void}
 */
ModelView3DExtrud.prototype.prepareHover = function (gl) {
	//console.log ("ModelView3DExtrud.prepareHover");
	if (typeof gl != "object") {
		console.error ("ERROR - ModelView3DExtrud.prepareHover : bad type of" 
				+ " parameter");
	}
};


//==============================================================================
/**
 * Override : do nothing.
 * @param {GLContext} gl - the gl context.
 * @return {void}
 */
ModelView3DExtrud.prototype.backBufferDraw = function (gl) {
	//console.log ("ModelView3DExtrud.backBufferDraw");
	if (typeof gl != "object") {
		console.error ("ERROR - ModelView3DExtrud.backBufferDraw : bad type of" 
				+ " parameter");
	}
};


//==============================================================================
/**
 * Prepare each face of the cube for rendering.
 * @param {Array} vertices - Array to fill with vertex position.
 * @param {Array} indices - Array to fill with indices for the drawing.
 * @param {Array} color - Array to with color depending of the face.
 * @param {Array} backColor - Array to with color of each vertex for picking.
 * @param {Array} normal - Array to fill with the normal of each face.
 * @return {void}
 */
ModelView3DExtrud.prototype.prepareCubeNormal = function (cube, vertices,
		indices, color, backColor, normal)
{
	//console.log (ModelView3DExtrud.prepareCubeNormal);
	if (typeof cube != "object"
			|| typeof vertices != "object"
			|| typeof indices != "object"
			|| typeof color != "object"
			|| typeof backColor != "object"
			|| typeof normal != "object") {
		console.error ("ERROR - ModelView3DExtrud.prepareCubeNormal : bad type of" 
				+ " parameter");
	}
	// --------------------------------------
	var size = this.modelController.getModel().getSize();
	var offset = 0.005;
	// Preparation of each face
	for (var i = 0; i < DirectionEnum.size; i++) {
		var verticeSize = vertices.length/3; // 3 points per vertices	
		if (cube.hasFacet(i)) { // If the cube got a facet in this direction
			switch (i) {
				case DirectionEnum.TOP : // TOP
					// Creation of the 4 points of the face
					this.addVertices(vertices, cube.getPosition().m[0],
							 cube.getPosition().m[1], 
							 cube.getPosition().m[2] + 1.0 + offset, size);
					this.addVertices(vertices, cube.getPosition().m[0] + 1.0, 
							cube.getPosition().m[1]		, 
							cube.getPosition().m[2] + 1.0 + offset, size);
					this.addVertices(vertices, cube.getPosition().m[0],
							cube.getPosition().m[1] + 1.0	,
							cube.getPosition().m[2] + 1.0 + offset, size);
					this.addVertices(vertices, cube.getPosition().m[0] + 1.0,
							cube.getPosition().m[1] + 1.0	,
							cube.getPosition().m[2] + 1.0 + offset, size);
					
					// To draw the 2 triangles
					indices.push(verticeSize, verticeSize+3, verticeSize+1);
					indices.push(verticeSize, verticeSize+2, verticeSize+3);
				break;
				case DirectionEnum.BOTTOM : // BOTTOM
					this.addVertices(vertices, cube.getPosition().m[0],
							 cube.getPosition().m[1],
							 cube.getPosition().m[2] - offset, size);
					this.addVertices(vertices, cube.getPosition().m[0] + 1.0,
							cube.getPosition().m[1],
							cube.getPosition().m[2] - offset, size);
					this.addVertices(vertices, cube.getPosition().m[0],
							cube.getPosition().m[1] + 1.0,
							cube.getPosition().m[2] - offset, size);
					this.addVertices(vertices, cube.getPosition().m[0] + 1.0,
							cube.getPosition().m[1] + 1.0,
							cube.getPosition().m[2] - offset, size);

					indices.push(verticeSize, verticeSize+1, verticeSize+3);
					indices.push(verticeSize, verticeSize+3, verticeSize+2);
				break;
				case DirectionEnum.RIGHT : // RIGHT
					this.addVertices(vertices, 
							cube.getPosition().m[0] + 1.0 + offset,
							 cube.getPosition().m[1],
							 cube.getPosition().m[2], size);
					this.addVertices(vertices, 
							cube.getPosition().m[0] + 1.0 + offset,
							cube.getPosition().m[1] + 1.0,
							cube.getPosition().m[2]	, size);
					this.addVertices(vertices,
							cube.getPosition().m[0] + 1.0 + offset,
							cube.getPosition().m[1]	,
							cube.getPosition().m[2] + 1.0, size);
					this.addVertices(vertices,
							cube.getPosition().m[0] + 1.0 + offset,
							cube.getPosition().m[1] + 1.0,
							cube.getPosition().m[2] + 1.0, size);
					
					indices.push(verticeSize, verticeSize+3, verticeSize+1);
					indices.push(verticeSize, verticeSize+2, verticeSize+3);
				break;
				case DirectionEnum.LEFT : // LEFT
					this.addVertices(vertices, cube.getPosition().m[0] - offset,
							 cube.getPosition().m[1],
							 cube.getPosition().m[2], size);
					this.addVertices(vertices, cube.getPosition().m[0] - offset,
							cube.getPosition().m[1] + 1.0,
							cube.getPosition().m[2], size);
					this.addVertices(vertices, cube.getPosition().m[0] - offset,
							cube.getPosition().m[1],
							cube.getPosition().m[2] + 1.0, size);
					this.addVertices(vertices, cube.getPosition().m[0] - offset,
							cube.getPosition().m[1] + 1.0,
							cube.getPosition().m[2] + 1.0, size);
					
					indices.push(verticeSize, verticeSize+1, verticeSize+3);
					indices.push(verticeSize, verticeSize+3, verticeSize+2);
				break;
				case DirectionEnum.FRONT : // FRONT
					this.addVertices(vertices, cube.getPosition().m[0],
							 cube.getPosition().m[1] - offset,
							 cube.getPosition().m[2], size);
					this.addVertices(vertices, cube.getPosition().m[0] + 1.0,
							cube.getPosition().m[1] - offset,
							cube.getPosition().m[2], size);
					this.addVertices(vertices, cube.getPosition().m[0],
							cube.getPosition().m[1] - offset,
							cube.getPosition().m[2] + 1.0, size);
					this.addVertices(vertices, cube.getPosition().m[0] + 1.0,
							cube.getPosition().m[1] - offset,
							cube.getPosition().m[2] + 1.0, size);
					
					indices.push(verticeSize, verticeSize+3, verticeSize+1);
					indices.push(verticeSize, verticeSize+2, verticeSize+3);
				break;
				case DirectionEnum.BACK : // BACK
					this.addVertices(vertices, cube.getPosition().m[0],
							cube.getPosition().m[1] + 1.0 + offset,
							cube.getPosition().m[2], size);
					this.addVertices(vertices, cube.getPosition().m[0] + 1.0,
							cube.getPosition().m[1] + 1.0 + offset,
							cube.getPosition().m[2], size);
					this.addVertices(vertices, cube.getPosition().m[0],
							cube.getPosition().m[1] + 1.0 + offset,
							cube.getPosition().m[2] + 1.0, size);
					this.addVertices(vertices, cube.getPosition().m[0] + 1.0,
							cube.getPosition().m[1] + 1.0 + offset,
							cube.getPosition().m[2] + 1.0, size);

					indices.push(verticeSize, verticeSize+1, verticeSize+3);
					indices.push(verticeSize, verticeSize+3, verticeSize+2);
				break;
				
			} // end switch facet
			color.push(appli.getColor(CubeStateEnum.NORMAL,
					DirectionEnum.properties[i].axis));
			normal.push([DirectionEnum.properties[i].x,
					DirectionEnum.properties[i].y,
					DirectionEnum.properties[i].z]);
			// The color used by the picking according to the facet position
			backColor.push([((cube.getPosition().m[0]+1.0)*10+i) / 255,
					((cube.getPosition().m[1]+1.0)*10) / 255,
					((cube.getPosition().m[2]+1.0)*10) / 255, 1]);
		} // end if facet exist
	}
};


//==============================================================================
/**
 * Add a vertex to an array.
 * Allows to calculate the coordinate from the matrix to a [-1..1] cube.
 * @param {Array} dataVertices - Array to fill with the vertex position.
 * @param {int} x - the x coordinate of the vertex.
 * @param {int} y - the y coordinate of the vertex.
 * @param {int} z - the z coordinate of the vertex.
 * @param {Vector} size - maximum quantity of cube on each dimension.
 * @return {void}
 */
ModelView3DExtrud.prototype.addVertices = function (dataVertices, x, y, z, size)
{
	//console.log ("ModelView3DExtrud.addVertices x= "+x+" y= "+y+" z= "+z);
	if (typeof dataVertices != "object"
			|| typeof x != "number"
			|| typeof y != "number"
			|| typeof z != "number"
			|| typeof size != "object") {
		console.error ("ERROR - ModelView3DExtrud.addVertices : bad type of "
				+ "parameter");
	}
	// --------------------------------------
	dataVertices.push((x / size.m[0]) * 2.0 - 1.0,
			(y / size.m[1]) * 2.0 - 1.0,
			(z / size.m[2]) * 2.0 - 1.0);
};


//==============================================================================
/**
 * Override : do nothing.
 * @param {Array} vertices - Array to fill with vertex position.
 * @param {Array} indices - Array to fill with indices for the drawing.
 * @param {Array} color - Array to with color depending of the face.
 * @param {Array} normal - Array to fill with the normal of each face.
 * @return {void}
 */
ModelView3DExtrud.prototype.prepareFaceHover = function (face, vertices,
		indices, color, normal)
{
	//console.log ("ModelView3DExtrud.prepareFaceHover");
	if (typeof face != "object"
			|| typeof vertices != "object"
			|| typeof indices != "object"
			|| typeof color != "object"
			|| typeof normal != "object") {
		console.error ("ERROR - ModelView3DExtrud.prepareFaceHover : bad type" +
			"of parameter");
	}
};


//==============================================================================
/**
 * Override : do nothing.
 * @param {Array} vertices - Array to fill with vertex position.
 * @param {Array} indices - Array to fill with indices for the drawing.
 * @param {Array} color - Array to with color depending of the face.
 * @param {Array} normal - Array to fill with the normal of each face.
 * @return {void}
 */
ModelView3DExtrud.prototype.prepareFaceSelect = function (face, vertices,
		indices, color, normal)
{
	//console.log ("ModelView3DExtrud.prepareFaceSelect face=");
	if (typeof face != "object"
			|| typeof vertices != "object"
			|| typeof indices != "object"
			|| typeof color != "object"
			|| typeof normal != "object") {
		console.error ("ERROR - ModelView3DExtrud.prepareFaceHover : bad type"
				+ " of parameter");
	}
};


//==============================================================================
/**
 * Override : do nothing.
 * @param {glContext} gl - The gl context.
 * @return {void}
 */
ModelView3DExtrud.prototype.clearHover = function (gl) {};


//==============================================================================
/**
 * Override : do nothing.
 * @param {glContext} gl - The gl context.
 * @return {void}
 */
ModelView3DExtrud.prototype.clearSelect = function (gl) {};


