precision mediump float;

uniform int uMode;
 
varying vec4 vColor;
varying vec3 vNormal;

void main(void) {
  if (uMode == 0) {
    gl_FragColor = vColor;
  }
  else if (uMode == 1) {
    gl_FragColor = vec4(abs(normalize(vNormal)), 1.0);
  }
}


