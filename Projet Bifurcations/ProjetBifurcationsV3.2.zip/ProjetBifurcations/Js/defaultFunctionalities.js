/// LICENCE ////////////////////////////////////////////////////////////////////

/* Copyright (juin 2015)
 * Auteur : BENOIST Thomas, BISUTTI Adrien, DESPLEBAIN Tanguy, LAURET Karl
 * 
 * benoist.thomas@hotmail.fr
 * biscui_86@hotmail.fr
 * tanguy.desplebain@gmail.com
 * lauret.karl@hotmail.fr
 * 
 * Ce logiciel est un programme informatique servant à modéliser des
 * structures 3D voxellisées. 
 * 
 * Ce logiciel est régi par la licence CeCILL soumise au droit français et
 * respectant les principes de diffusion des logiciels libres. Vous pouvez
 * utiliser, modifier et/ou redistribuer ce programme sous les conditions
 * de la licence CeCILL telle que diffusée par le CEA, le CNRS et l'INRIA
 * sur le site "http://www.cecill.info".
 * 
 * En contrepartie de l'accessibilité au code source et des droits de copie,
 * de modification et de redistribution accordés par cette licence, il n'est
 * offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
 * seule une responsabilité restreinte pèse sur l'auteur du programme,  le
 * titulaire des droits patrimoniaux et les concédants successifs.
 * 
 * A cet égard  l'attention de l'utilisateur est attirée sur les risques
 * associés au chargement,  à l'utilisation,  à la modification et/ou au
 * développement et à la reproduction du logiciel par l'utilisateur étant
 * donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
 * manipuler et qui le réserve donc à des développeurs et des professionnels
 * avertis possédant  des  connaissances  informatiques approfondies.  Les
 * utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
 * logiciel à leurs besoins dans des conditions permettant d'assurer la
 * sécurité de leurs systèmes et ou de leurs données et, plus généralement,
 * à l'utiliser et l'exploiter dans les mêmes conditions de sécurité.
 * 
 * Le fait que vous puissiez accéder à cet en-tête signifie que vous avez
 * pris connaissance de la licence CeCILL, et que vous en avez accepté les
 * termes.
 */

/// CODE ///////////////////////////////////////////////////////////////////////

/*
 * Contain the default functionnalities of the application.
 */
var defaultFunctionalities = [];

	  ////////////
	 /// File ///
	////////////


	/// New ///


	/// Open ///


	/// Save ///



	/// Save As ///


	/// Close ///



	  ////////////
	 /// View ///
	////////////


	/// All Modeling View ///



	/// 3D ///



	/// Slices ///



	  ////////////
	 /// Tool ///
	////////////



	/// Undo ///


var undo = new EntryData ("Annuler",
	"Annule la dernière action effectuée",
	"appli.alertMessage ('undo not implemented !', 4000)",
	"ToolStateEnum.ACCESSIBLE");

undo.setInitMessage ("");
undo.setValidMessage ("??? annulé");
//undo.setWarningMessage ("undo : warning !");
undo.setErrorMessage ("Rien a annuler");

undo.setMenu (MenuEntryEnum.TOOLS);
undo.setIndexMenu (0);

undo.setImgPath ("Img/undo.png");
undo.setImgAlternateText ("Anul.");
undo.setIndexTool (8);

defaultFunctionalities.push (undo);



	/// Redo ///


var redo = new EntryData ("Refaire",
	"Refaire la dernière action annulée",
	"appli.alertMessage ('redo not implemented !', 4000)",
	"ToolStateEnum.INACCESSIBLE");

redo.setInitMessage ("");
redo.setValidMessage ("??? refait");
//redo.setWarningMessage ("redo : warning !");
redo.setErrorMessage ("Rien à refaire");

redo.setMenu (MenuEntryEnum.TOOLS);
redo.setIndexMenu (1);

redo.setImgPath ("Img/redo.png");
redo.setImgAlternateText ("Ref.");
redo.setIndexTool (9);

defaultFunctionalities.push (redo);



	/// Add ///


var add = new EntryData ("Ajouter un cube", 
	"Outils d'ajout de cube",
	"alert('On ajoute un cube')");

add.setInitMessage ("Cliqué sur une facette pour ajouter un cube à \
cet endroit.");

add.setMenu (MenuEntryEnum.TOOLS);
add.setIndexMenu (2);

//add.setImgPath ("Img/addCube.png");
//add.setImgAlternateText ("+")
//add.setIndexTool (0);

//defaultFunctionalities.push (add);



	/// Remove ///


var remove = new EntryData ("Supprimer un cube",
	"Outils de suppression de cube",
	"appli.alertMessage ('remove not implemented !', 4000)",
	"ToolStateEnum.ACCESSIBLE");

remove.setInitMessage ("Cliquez sur la face d\\\'un cube pour le supprimer");
//remove.setValidMessage ("remove : valid");
//remove.setWarningMessage ("remove : warning !");
//remove.setErrorMessage ("remove : error !!!");

remove.setMenu (MenuEntryEnum.TOOLS);
remove.setIndexMenu (3);

//remove.setImgPath ("Img/removeCube.png");
//remove.setImgAlternateText ("-");
//remove.setIndexTool (1);

//defaultFunctionalities.push (remove);



	/// Extrusion Add ///


var extrusionAdd = new EntryData ("Ajouter des cubes",
	"Outils pour ajouter des cubes",
	"appli.alertMessage ('extrusionAdd not implemented !', 4000)",
	"ToolStateEnum.ACCESSIBLE");

extrusionAdd.setInitMessage ("Cliquez pour ajouter un cube, faites un \
cliqué-glissé pour en ajouter plusieurs.");
//extrusionAdd.setValidMessage ("extrusionAdd : valid");
//extrusionAdd.setWarningMessage ("extrusionAdd : warning !");
extrusionAdd.setErrorMessage ("Impossible d\\\'ajouter un cube à cet endroit");

extrusionAdd.setMenu (MenuEntryEnum.TOOLS);
extrusionAdd.setIndexMenu (2);

extrusionAdd.setImgPath ("Img/addCube.png");
extrusionAdd.setImgAlternateText ("++");
extrusionAdd.setIndexTool (0); // At the end

defaultFunctionalities.push (extrusionAdd);



	/// Extrusion Remove ///


var extrusionRemove = new EntryData ("Supprimer des cubes",
	"Outils pour supprimer des cubes",
	"appli.alertMessage ('extrusionRemove not implemented !', 4000)",
	"ToolStateEnum.ACCESSIBLE");

extrusionRemove.setInitMessage ("Cliquez pour supprimer un cube, faites un \
cliqué-glissé pour en supprimer plusieurs.");
//extrusionRemove.setValidMessage ("extrusionRemove : valid");
//extrusionRemove.setWarningMessage ("extrusionRemove : warning !");
//extrusionRemove.setErrorMessage ("extrusionRemove : error !!!");

extrusionRemove.setMenu (MenuEntryEnum.TOOLS);
extrusionRemove.setIndexMenu (3);

extrusionRemove.setImgPath ("Img/removeCube.png");
extrusionRemove.setImgAlternateText ("--");
extrusionRemove.setIndexTool (1);

defaultFunctionalities.push (extrusionRemove);



	/// Remove Selection ///


var removeSelect = new EntryData ("Supprimer les cubes selectionnés",
	"Supprime tous les cubes selectionnés",
	"appli.alertMessage ('removeSelect not implemented !', 4000)",
	"ToolStateEnum.ACCESSIBLE");

removeSelect.setInitMessage ("removeSelect is active");
removeSelect.setValidMessage ("Cube(s) supprimé(s) !");
//removeSelect.setWarningMessage ("removeSelect : warning !");
//removeSelect.setErrorMessage ("removeSelect : error !!!");

removeSelect.setMenu (MenuEntryEnum.TOOLS);
removeSelect.setIndexMenu (4);

removeSelect.setImgPath ("");
removeSelect.setImgAlternateText ("");
removeSelect.setIndexTool (-1);

defaultFunctionalities.push (removeSelect);



	/// Translate ///


var translate = new EntryData ("Déplacer",
	"Déplacer la forme",
	"appli.alertMessage ('translate not implemented !', 4000)",
	"ToolStateEnum.ACCESSIBLE");

translate.setInitMessage ("Selectionnez un objet puis déplacez le avec les \
touches directionnelles, la touche Page Haut et la touche Page Bas.");
//translate.setValidMessage ("translate : valid");
translate.setWarningMessage ("Limites de l'univers atteinte ! La forme a été \
tronquée.");
translate.setErrorMessage ("Limites de l'univers atteinte ! Vous ne pouvez pas \
aller plus loin.");

translate.setMenu (MenuEntryEnum.TOOLS);
translate.setIndexMenu (5);

translate.setImgPath ("Img/translate.png");
translate.setImgAlternateText ("<->");
translate.setIndexTool (2);

defaultFunctionalities.push (translate);



	/// Rotate ///

// XXX a découper
var rotate = new EntryData ("Tourner",
	"Tourner la forme selon un axe",
	"appli.alertMessage ('rotate not implemented !', 4000)",
	"ToolStateEnum.ACCESSIBLE");

rotate.setInitMessage ("rotate is active");
//rotate.setValidMessage ("rotate : valid");
//rotate.setWarningMessage ("rotate : warning !");
//rotate.setErrorMessage ("rotate : error !!!");

rotate.setMenu (MenuEntryEnum.TOOLS);
rotate.setIndexMenu (6);

rotate.setImgPath ("Img/rotate.png");
rotate.setImgAlternateText ("Tour.");
rotate.setIndexTool (3);

defaultFunctionalities.push (rotate);



	/// Join ///


var joinModel = new EntryData ("Fusionner",
	"Fusionner les modèles selectionnés",
	"appli.alertMessage ('joinModel not implemented !', 4000)",
	"ToolStateEnum.INACCESSIBLE");

joinModel.setInitMessage ("Modèles fusionnés");
//joinModel.setValidMessage ("joinModel : valid");
//joinModel.setWarningMessage ("joinModel : warning !");
//joinModel.setErrorMessage ("joinModel : error !!!");

joinModel.setMenu (MenuEntryEnum.TOOLS);
joinModel.setIndexMenu (7); // At the end

joinModel.setImgPath ("Img/join.png");
joinModel.setImgAlternateText ("->+<-");
joinModel.setIndexTool (7);

defaultFunctionalities.push (joinModel);



	  /////////////
	 /// Model ///
	/////////////


	/// Description ///


	/// Validation ///


	/// Properties ///


	  ////////////
	 /// Help ///
	////////////


	/// Print Help ///



	/// About ///

