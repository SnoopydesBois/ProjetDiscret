=============================================================
=============================================================
						READ ME
						

INSTALLATION
============

	The application can be found in the ZIP archive : "ProjetBifurcationsV3.zip"
	
	1. Windows
	----------
		Right-click in the arcguve and select the extraction command of your 
		archive manager.
		 
	2. Linux
	--------
		If you can, right-click on the archive and select the extraction 
		command.
		Else, write one of the following command line :
			* Extraction in the current directory :
				$ unzip [-q] ProjetBifurcationsV2.zip
				-q put the extraction in silent mode
			* Extraction in target directory :
				$ unzip [-q] ProjetBifurcationsV2.zip -d <DirectoryName>
					 
	3. MacOSX
	---------
		Double-click on the archive.
		
			
START THE APPLICATION
=====================

	After the extraction you should find a directory named Application.

	In this directory are located the files mandatory for the application to run
	correctly	
	
	To start the application, you must double-clic on "bifurcation.html"
	
	If a text editor is open, start your browser and drag the file into the 
	newly opened window. 
		
	The application works only with Firefox (30+ version is prefered, some 
	features don't work with lower version).
	You also need to have a graphic card with up-to-date drivers.
	
	If the application is not working, try the following manipulation :
		In your brower search bar, write about:config
		A warning will be displayed to warn that modifications can be dangerous.
		Click on "Je ferai attention, promis !" button.
		Next is displayed a list of option. There is a search bar on top of the 
		list. In this list, search for "webgl.force-enabled".
		The value of the option should be false.
		If it is the case, double-click on the option.
		Else, do nothing.
		
	If the application is still not working after the manipulation, it is 
	possible that your drivers are not up to date.  
		

USE OF THE APPLICATION
======================

	To select a model, you must check the box on the left of the name of the 
	model in the list on the left of the window.
	
	When you click on the name of the model, it is then displayed on both 3D 
	space and 2D slices.
	
	It is possible to only display the model in 2D or 3D by clicking on the 
	corresponding icons.
	
	You can select multiple models by checking the boxes on the left of their 
	names.
	This functionality is used to merge models.
	
	You can rotate the camera around the object by keeping the alt key/right
	mouse button down and moving the mouse.
	
	You can zoom by using the scroll wheel of the mouse or the - + key. 
	They 0 key reset the camera at the origin.
	
	The 2D slices represent the model as slices. It is then possible to see all 
	the cubes a model possess for a given slice along a given axis.
	
	By clicking on the XY, XZ or YZ button in the toolbar, it is possible to 
	display the slices of the model on the XY, XZ or YZ plan.
	
	It is possible to switch from the default view (3D space and 2D slices 
	displayed) to 3D space displayed only by clicking on the button represented 
	by a cube
	
	Same way, it is possible to switch to a 2D view by clicking on the button 
	represented by a grid.
	
	To come back to the default view, you must click on the button represented 
	by both a cube and a grid.
	
	The tools available are :
	
		* Cube(s) selection : 
				It is the default tool of the application. 
				When it is selected, no other tools are actives.
				A cube selected in 3D space or on 2D slices is painted in blue.
				The corresponding cube on the other view is also paint in blue 
				if visible.
			
		* Add cubes : 
				This tool allows you to add cubes to the model.
				On a simple left click, a cube is added next to the face highlighted.
				If you move the souris while keeping the left mouse button down, 
				you will add multiple cubes along the normal of the cube.
				The button for this tool is the one with a +
				
		* Remove cubes : 
				This tool allows you to remove cubes from the model.
				On a simble left click, the cube with the highlighted face is 
				removed.
				If you move the mouse while keeping the left mouse button down, 
				you will remove multiple cubes along the normal of the cube.
				The button for this tool is the one with a -.
				
		* Add/Remove models :
				It is possible to add a new empty model by using the "Nouveau" 
				functionality (Fichier->Nouveau) in the menu.
				
				It is possible to remove a model by using the "Enlever modèle" 
				functionality (Bibliothèque->Enlever modèle) in the menu
				You need to write the name of the model (the names are displayed 
				in the model list)
				You can also remove a model by clicking on the red cross in the 
				model list.
		
		* Translate model :
				To translate a model, you can use the directionnal arrows to 
				move the model along the x or y axis. To move the model along 
				the z axis, you can use the page up/page down key.
				The translation does not allow the model to move outside of the 
				3D space.
				The button for this tool is the one represented by a cube 
				with arrows
	
		* Rotate model :
				To rotate a model, you can use the 8,4,6,2,9,3 keys.
				8 and 2 rotate the model around the Z axis.
				4 and 6 rotate the model around the Y axis.
				9 and 3 rotate the model around the X axis.
				The button for this tool is the one represented by a cube and 
				a curved arrow.
	
		* Save/Load a file :
				To save a model, you must use the "Enregistrer" functionality 
				(Fichier->Enregistrer) in the menu.
				You will then have to fill the Id, Description and Créateur 
				fields.
				Once you clicked on the "Enregistrer" button of the page, a zip 
				will be available for download.
				This zip will contain a folder with 3 files.
				This files are :
						- the model data
						- the model preview
						- the model information
				The model preview is a png of the 3D view displayed during the 
				saving.
				During the saving, the 3D view displayed is working as the usual
				3D view.
				
				To load a model, you must use the "Ouvrir" functionality 
				(Fichier->Ouvrir) in the menu.
				A window will open for you to select the model to load.	
	
	
KEYBOARD SHORTCUT
=================
	
		Selection : R
		Add cubes : T
		Remove cubes : Y
		Translation : U
		Rotation : I
		3D View : F
		2D View : H
		2D/3D View : G
		XY Plan : J
		XZ Plan : K
		YZ Plan : L
		Copy in a new model : M
		
KNOWN BUGS
==========

	We are currently aware of the following bugs :
			
		* 2D slices :
			There is a high latency during a rotation or a translation of a
			model
						
		* CSS not taken:
			During the extraction of the archive, the architecture of the 
			application might not be correct (some files are not in their 
			directory for example).
			
			Try to reextract the archive. If you still have the problem here is 
			the structure of the application :
			
			Application_v2
			|	- bifurcation.html
			|	- CeCILL
			|	- general.css
			|	- Frame			
			|	|	- iFrame2D.css			
			|	|	- iFrame2D.html			
			|	|	- iFrame3D.css			
			|	|	- iFrame3D.html			
			|	|	- iFrameForm.css			
			|	|	- iFrameForm.html			
			|	|	- iFrameList.css			
			|	|	- iFrameList.html
			|	- img
			|	|	- coupeXY.png			
			|	|	- coupeXZ.png			
			|	|	- coupeYZ.png			
			|	|	- curseur.png			
			|	|	- curseur_Select.png			
			|	|	- cursor.png			
			|	|	- deplacement.png			
			|	|	- deplacement_Select.png			
			|	|	- extrusionMoins.png			
			|	|	- extrusionMoins_Select.png			
			|	|	- extrusionPlus.png			
			|	|	- extrusionPlus_Select.png			
			|	|	- favicon.png			
			|	|	- flecheBas.png			
			|	|	- flecheHaut.png
			|	|	- fourchette.png			
			|	|	- fusion.png			
			|	|	- iconmonstr-x-mark-2-icon-256.png			
			|	|	- images.png			
			|	|	- modeles_inivisible.png			
			|	|	- modeles_visible.png			
			|	|	- repere.png			
			|	|	- rotation.png			
			|	|	- rotation_Select.png			
			|	|	- vue2D.png			
			|	|	- vue2D_Invisible.png			
			|	|	- vue2D_Visible.png			
			|	|	- vue3D.png			
			|	|	- vue3D_Invisible.png			
			|	|	- vue3D_Visible.png			
			|	|	- vue2D3D.png
			|	- Js
			|	|	- defaultFunctionalities.js
			|	|	- FileSaver.js
			|	|	- fonction.js
			|	|	- init.js
			|	|	- jquery.js
			|	|	- jquery-ui.js
			|	|	- jszip.js
			|	|	- webgl.js
			|	|	- Application
			|	|	|	- Application.js
			|	|	|	- Application_Colors.js
			|	|	|	- Application_Controller.js
			|	|	|	- Application_Initialisation.js
			|	|	|	- Application_Interface.js
			|	|	|	- Application_Messages.js
			|	|	|	- Application_Tools.js
			|	|	|	- Frame.js
			|	|	|	- Frame2D.js
			|	|	|	- Frame3D.js
			|	|	|	- FrameForm.js
			|	|	|	- FrameList.js
			|	|	|	- MenuEntryEnum.js
			|	|	|	- ToolStateEnum.js
			|	|	|	- WorkspaceEnum.js
			|	|	- Data
			|	|	|	- confortModerne.js
			|	|	|	- cubeMenger.js
			|	|	|	- fourchette.js
			|	|	|	- herbierArbre4.js
			|	|	|	- lapin.js
			|	|	|	- microscope.js
			|	|	|	- modelCommunautaire.js
			|	|	|	- orange.js
			|	|	|	- sphere.js
			|	|	- Structure
			|	|	|	- Common
			|	|	|	|	- AttributeEnum.js
			|	|	|	|	- AxisEnum.js
			|	|	|	|	- Camera.js
			|	|	|	|	- CubeStateEnum.js
			|	|	|	|	- DirectionEnum.js
			|	|	|	|	- GenericObject.js
			|	|	|	|	- RenderingTarget.js
			|	|	|	|	- Scene.js
			|	|	|	|	- SignalEnum.js
			|	|	|	|	- Util.js
			|	|	|	|	- webgl-debug.js
			|	|	|	- Functionality
			|	|	|	|	- EntryData.js
			|	|	|	|	- Signal.js
			|	|	|	|	- Controller
			|	|	|	|	|	- Controller.js
			|	|	|	|	|	- ControllerAdd.js
			|	|	|	|	|	- ControllerAdd2D.js
			|	|	|	|	|	- ControllerCamera.js
			|	|	|	|	|	- ControllerExtrusion.js
			|	|	|	|	|	- ControllerHover.js
			|	|	|	|	|	- ControllerHover2D.js
			|	|	|	|	|	- ControllerRemove.js
			|	|	|	|	|	- ControllerRemove2D.js
			|	|	|	|	|	- ControllerRotate.js
			|	|	|	|	|	- ControllerSelect.js
			|	|	|	|	|	- ControllerSelect2D.js
			|	|	|	|	|	- ControllerTranslate.js
			|	|	|	|	- Kernel
			|	|	|	|	|	- Kernel.js
			|	|	|	|	|	- KernelAdd.js
			|	|	|	|	|	- KernelAdd2D.js
			|	|	|	|	|	- KernelExtrusion.js
			|	|	|	|	|	- KernelHover.js
			|	|	|	|	|	- KernelHover2D.js
			|	|	|	|	|	- KernelRemove.js
			|	|	|	|	|	- KernelRemove2D.js
			|	|	|	|	|	- KernelRotate.js
			|	|	|	|	|	- KernelSelect.js
			|	|	|	|	|	- KernelSelect2D.js
			|	|	|	|	|	- KernelTranslate.js
			|	|	|	- KernelApplication
			|	|	|	|	- Cube.js
			|	|	|	|	- Facet.js
			|	|	|	|	- Model.js
			|	|	|	|	- ModelController.js
			|	|	|	- Objects
			|	|	|	|	- GenericStructure.js
			|	|	|	|	- Matrix.js
			|	|	|	|	- ModelView.js
			|	|	|	|	- ModelView2D.js
			|	|	|	|	- ModelView3D.js
			|	|	|	|	- ModelView3DExtrud.js
			|	|	|	|	- Repere.js
			|	|	|	|	- Vector.js
			|	|	|	- Shaders
			|	|	|	|	- default.vs
			|	|	|	|	- default.fs
			|	|	|	|	- DefaultShader.js
			|	|	|	|	- FragmentShader.js
			|	|	|	|	- multiple.fs
			|	|	|	|	- multiple.vs
			|	|	|	|	- MultipleShader.js
			|	|	|	|	- Shader.js
			|	- styles
			|	|	- grid.css
			|	|	- jquery-ui.css
			|	|	- jquery-ui.structure.css
			|	|	- jquery-ui.theme.css
			|	|	- menus.css
			|	|	- onglet.css
			|	|	- tools.css
		
		
