=============================================================
=============================================================
						READ ME
						

INSTALLATION
============

	L'application se trouve dans l'archive ZIP : "ProjetBifurcationsV3.zip"
	
	1. Windows
	----------
		Faite un clic-droit sur l'archive et sélectionnez l'option d'extraction 
		selon votre logiciel de décompression.
		 
	2. Linux
	--------
		Si vous en avez la possibilité, faite un clic-droit sur l'archive 
		et sélectionnez l'option d'extraction.
		Sinon, rentrez l'une des commandes suivantes :
			* Extraction dans le dossier courant :
				$ unzip [-q] ProjetBifurcationsV2.zip
				l'option -q permet de passer l'extraction en mode silencieux
			* Extraction dans le dossier de votre choix :
				$ unzip [-q] ProjetBifurcationsV2.zip -d <NomDossier>
					 
	3. MacOSX
	---------
		Double-cliquez simplement sur l'archive.
			
			
LANCEMENT DE L'APPLICATION
==========================

	Après extraction, vous devriez obtenir un dossier nommé Application. 
	
	Dans ce dossier se trouve tous les fichiers permettant le bon fonctionnement
	de l'application.
	
	Pour lancer l'application, il faut double-cliquer sur le fichier 
	"bifurcation.html"
	
	Si cela ouvre un éditeur de texte, ouvrez votre navigateur et faite glisser 
	ce fichier dans la fenêtre alors ouverte.
	
	L'application ne fonctionne que sous firefox 
	(version 4+, préférez cependant une version 30+)
	Il faut cependant que les pilotes de votre carte graphique soient à jour.
	
	Si l'application ne fonctionne pas, essayez la manipulation suivante :
		Dans la barre d'adresse de votre navigateur, tapez about:config
		Vous verrez alors un warning vous indiquant que des modifications 
		peuvent être dangereuse.
		Cliquez sur le bouton "Je ferai attention, promis !"
		Vous verrez alors une liste d'options avec une barre de recherche
		au dessus.
		Recherchez l'option "webgl.force-enabled".
		Sa valeur devrait être à fausse.
		Si c'est le cas, double cliquez sur l'option.
		Sinon ne faites rien.
	
	Si l'application ne fonctionne toujours pas après cette manipulation,
	c'est que vos drivers de carte graphique ne sont pas à jour.
	

UTILISATION DE L'APPLICATION
============================
	
	Pour sélectionner un modèle, il faut cliquer sur la case à cocher se trouvant à gauche
	du nom du modèle dans la liste se trouvant sur la gauche de la fenêtre.
	
	Lorsqu'un modèle est sélectionné, il est affiché dans l'espace 3D et sur 
	les coupes 2D.
	
	Il est possible d'afficher le modèle seulement en 3D ou en 2D en cliquant sur les
	icônes correspondantes
	
	Il est possible de sélectionner plusieurs modèles en même temps en 
	cochant les cases se trouvant à gauche des nom des modèles.
	Cette fonctionnalité est utilisée pour la fusion.
	
	Il est possible de faire tourner la caméra autour de l'objet en maintenant 
	alt ou le bouton droit de la souris enfoncé et de bouger la souris.
	
	Il est possible de zoomer en utilisant la molette de la souris ou bien en
	utilisant les touches - + . Il est possible de repositionner la caméra à l'origine en 
	appuyant sur la touche 0.
		
	Les coupes 2D représentent l'objet sous forme de tranches. On peut alors 
	voir les cubes que possède un objet pour une tranche donnée selon un axe.
	
	En cliquant sur les boutons XY, XZ ou YZ de la barre d'outils, il est possible 
	d'afficher les tranches de l'objet selon les plans XY, XZ ou YZ.
	
	Il est possible de passer de la fenêtre de base (espace 3D et vues 2D 
	affichés) à une fenêtre ne contenant seulement que l'espace 3D en cliquant 
	sur le bouton représenté par un cube.
	
	De même, il est possible de passer à une fenêtre ne contenant que les vues 
	2D en cliquant sur le bouton représenté par une grille.
	
	Pour revenir à la fenêtre de base, il faut cliquer sur le bouton représenté par un 
	cube et une grille.
	
	Les outils disponibles sont :

		* Sélection de cubes : 
				C'est l'outil de base de l'application. 
				Lorsqu'il est sélectionné, aucun autre outil n'est actif.
				Un cube sélectionné respectivement dans l'espace 3D ou dans 
				l'espace 2D est paint en bleu. le cube correspondant 
				respectivement sur les coupes 2D ou dans l'espace 3D est alors 
				aussi paint en bleu si il est visible.
		
		* Ajout de cubes : 
				Cet outil permet d'ajouter des cubes au modèle. Lors d'un simple
				clic gauche, un cube est ajouté sur la face en surbrillance. Si vous 
				bougez la souris en maintenant le clic gauche enfoncé, il est 
				possible d'extruder (ajout de cubes seulement).
				Le bouton pour activer cet outil est celui comportant un +
		
		* Suppression de cubes : 
				Cet outil permet de supprimer des cubes au modèle. Lors d'un simple
				clic, le cube dont la face est en surbrillance est supprimé. Si vous 
				bougez la souris en maintenant le clic gauche enfoncé, il est 
				possible d'extruder (suppression de cubes seulement).
		
		* Ajout/Suppression de modèles
				Il est possible d'ajouter un modèle vide en utilisant la 
				fonctionnalité "Nouveau" (Fichier->Nouveau) qui se trouve dans 
				la barre des menus.
				
				Il est possible de supprimer un modèle en utilisant la
				fonctionnalité "Enlever modèle" (Bibliothèque->Enlever modèle) 
				qui se trouve dans la barre des menus. 
				Il faut alors sélectionner le modèle à supprimer
				Il est également possible de supprimer un modèle à partir de la
				liste des modèles.
				Il faut pour cela cliquer sur la croix en bout de ligne.
	
		* Translation d'un modèle :
				Pour réaliser la translation d'un modèle selon l'axe X ou Y, il est 
				possible d'utiliser les flèches directionnelles. 
				Pour une translation selon l'axe Z, il faut utiliser les touches 
				page up/page down.
				Il est aussi possible d'utiliser les touches de la rotation d'un modèle.
				
				La translation n'autorise pas qu'une modèle sorte de l'espace 3D.
				Le bouton pour utiliser cet outil est représenté par un cube avec des 
				flèches.
				
		* Rotation d'un modèle
				Pour effectuer une rotation d'un modèle, il est possible d'utiliser 
				les touches 8, 4, 6, 2, 9, 3.
				8 et 2 effectuent une rotation selon l'axe Z.
				4 et 6 effectuent une rotation selon l'axe Y.
				9 et 3 effectuent une rotation selon l'axe X.
				
				Le bouton pour utiliser cet outil est représenté par un cube avec 
				une flèche incurvée
		
		* Sauvegarder/Charger un fichier
				Sauvegarder un modèle se fait via la fonctionnalité "Enregistrer" 
				(Fichier->Enregistrer) dans le menu.
				Vous devrez alors remplir les champs Id, Description et Créateur.
				Une fois que vous avez cliqué sur le bouton "Enregistrer", un zip sera 
				proposé au téléchargement.
				Cette archive contient un dossier contenant 3 fichiers. 		
				Les fichiers sont :
						- Les données du modèle
						- Un aperçu du modèle
						- Les informations du modèle
					
				L'aperçu du modèle est une image au format png représentant la vue 3D 
				affichée pendant l'enregistrement.			
				Durant l'enregistrement, la vue 3D affichée fonctionne comme la vue 3D
				habituelle.
				
				Charger un modèle se fait via la fonctionnalité "Ouvrir" (Fichier->Ouvrir)
				dans le menu.
				Une fenêtre va s'ouvrir pour sélectionner le modèle à charger.

RACCOURCIS CLAVIER
==================
	
		Sélection : R
		Ajout de cubes : T
		Suppression de cubes : Y
		Translation : U
		Rotation : I
		Vue 3D : F
		Vue 2D : H
		Vue 2D/3D : G
		Coupe XY : J
		Coupe XZ : K
		Coupe YZ : L
		Copier dans un nouveau modèle : M
		
BUG CONNUS
==========

	Nous avons recensé les bugs suivant :
					
		* Coupes 2D :
			Temps de latence long lors de la rotation de l'objet ou de la
			translation
			
		* CSS non pris en compte :
			Lors de l'extraction de l'archive, l'architecture de l'application 
			n'est pas respectée (des fichiers ne sont pas dans leur dossiers par
			exemple).
			Réessayez d'extraire l'archive, si le problème persiste, 
			vous trouverez ci-dessous l'architecture de l'application
			
			Application_v2
			|	- bifurcation.html
			|	- CeCILL
			|	- general.css
			|	- Frame			
			|	|	- iFrame2D.css			
			|	|	- iFrame2D.html			
			|	|	- iFrame3D.css			
			|	|	- iFrame3D.html			
			|	|	- iFrameForm.css			
			|	|	- iFrameForm.html			
			|	|	- iFrameList.css			
			|	|	- iFrameList.html
			|	- img
			|	|	- coupeXY.png			
			|	|	- coupeXZ.png			
			|	|	- coupeYZ.png			
			|	|	- curseur.png			
			|	|	- curseur_Select.png			
			|	|	- cursor.png			
			|	|	- deplacement.png			
			|	|	- deplacement_Select.png			
			|	|	- extrusionMoins.png			
			|	|	- extrusionMoins_Select.png			
			|	|	- extrusionPlus.png			
			|	|	- extrusionPlus_Select.png			
			|	|	- favicon.png			
			|	|	- flecheBas.png			
			|	|	- flecheHaut.png
			|	|	- fourchette.png			
			|	|	- fusion.png			
			|	|	- iconmonstr-x-mark-2-icon-256.png			
			|	|	- images.png			
			|	|	- modeles_inivisible.png			
			|	|	- modeles_visible.png			
			|	|	- repere.png			
			|	|	- rotation.png			
			|	|	- rotation_Select.png			
			|	|	- vue2D.png			
			|	|	- vue2D_Invisible.png			
			|	|	- vue2D_Visible.png			
			|	|	- vue3D.png			
			|	|	- vue3D_Invisible.png			
			|	|	- vue3D_Visible.png			
			|	|	- vue2D3D.png
			|	- Js
			|	|	- defaultFunctionalities.js
			|	|	- FileSaver.js
			|	|	- fonction.js
			|	|	- init.js
			|	|	- jquery.js
			|	|	- jquery-ui.js
			|	|	- jszip.js
			|	|	- webgl.js
			|	|	- Application
			|	|	|	- Application.js
			|	|	|	- Application_Colors.js
			|	|	|	- Application_Controller.js
			|	|	|	- Application_Initialisation.js
			|	|	|	- Application_Interface.js
			|	|	|	- Application_Messages.js
			|	|	|	- Application_Tools.js
			|	|	|	- Frame.js
			|	|	|	- Frame2D.js
			|	|	|	- Frame3D.js
			|	|	|	- FrameForm.js
			|	|	|	- FrameList.js
			|	|	|	- MenuEntryEnum.js
			|	|	|	- ToolStateEnum.js
			|	|	|	- WorkspaceEnum.js
			|	|	- Data
			|	|	|	- confortModerne.js
			|	|	|	- cubeMenger.js
			|	|	|	- fourchette.js
			|	|	|	- herbierArbre4.js
			|	|	|	- lapin.js
			|	|	|	- microscope.js
			|	|	|	- modelCommunautaire.js
			|	|	|	- orange.js
			|	|	|	- sphere.js
			|	|	- Structure
			|	|	|	- Common
			|	|	|	|	- AttributeEnum.js
			|	|	|	|	- AxisEnum.js
			|	|	|	|	- Camera.js
			|	|	|	|	- CubeStateEnum.js
			|	|	|	|	- DirectionEnum.js
			|	|	|	|	- GenericObject.js
			|	|	|	|	- RenderingTarget.js
			|	|	|	|	- Scene.js
			|	|	|	|	- SignalEnum.js
			|	|	|	|	- Util.js
			|	|	|	|	- webgl-debug.js
			|	|	|	- Functionality
			|	|	|	|	- EntryData.js
			|	|	|	|	- Signal.js
			|	|	|	|	- Controller
			|	|	|	|	|	- Controller.js
			|	|	|	|	|	- ControllerAdd.js
			|	|	|	|	|	- ControllerAdd2D.js
			|	|	|	|	|	- ControllerCamera.js
			|	|	|	|	|	- ControllerExtrusion.js
			|	|	|	|	|	- ControllerHover.js
			|	|	|	|	|	- ControllerHover2D.js
			|	|	|	|	|	- ControllerRemove.js
			|	|	|	|	|	- ControllerRemove2D.js
			|	|	|	|	|	- ControllerRotate.js
			|	|	|	|	|	- ControllerSelect.js
			|	|	|	|	|	- ControllerSelect2D.js
			|	|	|	|	|	- ControllerTranslate.js
			|	|	|	|	- Kernel
			|	|	|	|	|	- Kernel.js
			|	|	|	|	|	- KernelAdd.js
			|	|	|	|	|	- KernelAdd2D.js
			|	|	|	|	|	- KernelExtrusion.js
			|	|	|	|	|	- KernelHover.js
			|	|	|	|	|	- KernelHover2D.js
			|	|	|	|	|	- KernelRemove.js
			|	|	|	|	|	- KernelRemove2D.js
			|	|	|	|	|	- KernelRotate.js
			|	|	|	|	|	- KernelSelect.js
			|	|	|	|	|	- KernelSelect2D.js
			|	|	|	|	|	- KernelTranslate.js
			|	|	|	- KernelApplication
			|	|	|	|	- Cube.js
			|	|	|	|	- Facet.js
			|	|	|	|	- Model.js
			|	|	|	|	- ModelController.js
			|	|	|	- Objects
			|	|	|	|	- GenericStructure.js
			|	|	|	|	- Matrix.js
			|	|	|	|	- ModelView.js
			|	|	|	|	- ModelView2D.js
			|	|	|	|	- ModelView3D.js
			|	|	|	|	- ModelView3DExtrud.js
			|	|	|	|	- Repere.js
			|	|	|	|	- Vector.js
			|	|	|	- Shaders
			|	|	|	|	- default.vs
			|	|	|	|	- default.fs
			|	|	|	|	- DefaultShader.js
			|	|	|	|	- FragmentShader.js
			|	|	|	|	- multiple.fs
			|	|	|	|	- multiple.vs
			|	|	|	|	- MultipleShader.js
			|	|	|	|	- Shader.js
			|	- styles
			|	|	- grid.css
			|	|	- jquery-ui.css
			|	|	- jquery-ui.structure.css
			|	|	- jquery-ui.theme.css
			|	|	- menus.css
			|	|	- onglet.css
			|	|	- tools.css
		
		
